document.addEventListener('DOMContentLoaded', async () => {
  try {
    const me = await api('/api/me');
    if (me?.user?.role === 'admin') {
      window.location.href = '/admin.html';
      return;
    }
  } catch (_) {}

  const form = document.getElementById('adminLoginForm');
  const error = document.getElementById('adminLoginError');
  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    error?.classList.add('hidden');
    try {
      await api('/api/admin/login', {
        method: 'POST',
        body: {
          username: document.getElementById('adminUsername').value.trim(),
          password: document.getElementById('adminPassword').value
        }
      });
      window.location.href = '/admin.html';
    } catch (err) {
      if (error) {
        error.textContent = err.message || 'Credenziali non valide';
        error.classList.remove('hidden');
      }
    }
  });
});
