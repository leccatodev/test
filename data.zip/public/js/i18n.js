const I18N_DICT = {
  it: {
    'common.loading': 'Caricamento…',
    'common.confirm': 'Conferma',
    'common.cancel': 'Annulla',
    'common.save': 'Salva',
    'common.close': 'Chiudi',
    'common.error.unknown': 'Errore sconosciuto',
    'common.logout': 'Esci',
    'common.admin': 'Admin',
    'common.user': 'Utente',
    'common.active': 'Attivo',
    'common.suspended': 'Sospeso',
    'common.verified': 'Verificata',
    'common.notVerified': 'Non verificata',
    'common.modify': 'Modifica',
    'common.password': 'Password',
    'common.suspend': 'Sospendi',
    'common.reactivate': 'Riattiva',
    'common.delete': 'Elimina',
    'common.yes': 'Sì',
    'common.no': 'No',

    'index.title': 'QubiqoHost — Accedi',
    'index.overline': 'Hosting control center',
    'index.heroTitle1': 'Ogni server.',
    'index.heroTitle2': 'Sotto controllo.',
    'index.heroDesc': 'Un pannello operativo progettato per gestire bot, risorse e deployment con chiarezza, velocità e sicurezza.',
    'index.feature1Title': 'Gestione centralizzata',
    'index.feature1Desc': "Tutto il tuo stack in un'unica dashboard.",
    'index.feature2Title': 'Monitoraggio live',
    'index.feature2Desc': 'Risorse e stato sempre visibili.',
    'index.feature3Title': 'Accesso protetto',
    'index.feature3Desc': 'Autenticazione sicura e affidabile.',
    'index.footAllSystems': 'Tutti i sistemi operativi',
    'index.footPlatform': 'QubiqoHost / Control platform',
    'index.step': 'Area cliente',
    'index.loginHeading': 'Accedi al tuo workspace',
    'index.loginDesc': 'Inserisci le tue credenziali o usa uno dei provider disponibili.',
    'index.registerHeading': 'Crea il tuo account',
    'index.registerDesc': 'Configura il tuo profilo e inizia a gestire i server.',
    'index.tabLogin': 'Accedi',
    'index.tabRegister': 'Registrati',
    'index.discordLogin': 'Continua con Discord',
    'index.googleLogin': 'Continua con Google',
    'index.orDivider': 'oppure usa le credenziali',
    'index.username': 'Username',
    'index.usernamePlaceholder': 'Il tuo username',
    'index.password': 'Password',
    'index.passwordPlaceholder': 'La tua password',
    'index.loginSubmit': 'Accedi al pannello',
    'index.regUsernamePlaceholder': 'Scegli uno username',
    'index.email': 'Email',
    'index.emailPlaceholder': 'nome@esempio.it',
    'index.regPasswordPlaceholder': 'Crea una password sicura',
    'index.registerSubmit': 'Crea account',
    'index.legal': "Accedendo accetti i termini di servizio e l'informativa sulla privacy di QubiqoHost.",
    'index.toast.accountCreated': "Account creato! Ti è arrivata un'email di verifica per verificare il tuo account.",
    'index.toast.discordCancelled': 'Accesso Discord annullato.',
    'index.toast.googleCancelled': 'Accesso Google annullato.',

    'nav.dashboard': 'Dashboard',
    'nav.server': 'Server',
    'nav.fileManager': 'File Manager',
    'nav.backup': 'Backup',
    'nav.nodes': 'Nodi',
    'nav.collaborators': 'Collaboratori',
    'nav.databases': 'Database',
    'nav.network': 'Network',
    'nav.billing': 'Fatturazione',
    'nav.settings': 'Impostazioni',
    'nav.support': 'Supporto',
    'nav.workspace': 'WORKSPACE',
    'nav.account': 'ACCOUNT',
    'nav.systemsOk': 'Tutti i servizi sono online',
    'nav.clientArea': 'Area cliente',
    'nav.mainNavigation': 'Navigazione principale',

    'admin.title': 'Utenti',
    'admin.subtitle': 'Gestione completa degli account, slot, crediti e accessi',
    'admin.searchPlaceholder': 'Cerca username, email o PIN…',
    'admin.newUser': '+ Nuovo utente',
    'admin.filter.all': 'Tutti',
    'admin.filter.discord': 'Discord',
    'admin.filter.google': 'Google',
    'admin.filter.manual': 'Manuale',
    'admin.filter.double': 'Possibili doppi account',
    'admin.col.user': 'UTENTE',
    'admin.col.email': 'EMAIL',
    'admin.col.access': 'ACCESSO',
    'admin.col.linkedIp': 'IP / ACCOUNT COLLEGATI',
    'admin.col.slots': 'SLOT',
    'admin.col.credits': 'CREDITI',
    'admin.col.role': 'RUOLO',
    'admin.col.status': 'STATO',
    'admin.col.registered': 'REGISTRATO',
    'admin.col.actions': 'AZIONI',
    'admin.noUsers': 'Nessun utente.',
    'admin.pageTitle': 'QubiqoHost — Admin',
    'admin.view.overview.title': 'Panoramica',
    'admin.view.overview.subtitle': 'Panoramica della piattaforma',
    'admin.view.users.title': 'Utenti',
    'admin.view.users.subtitle': 'Gestione completa degli account, slot, crediti e accessi',
    'admin.view.servers.title': 'Server',
    'admin.view.servers.subtitle': 'Controllo completo di tutti i server della piattaforma',
    'admin.view.files.title': 'File Manager',
    'admin.view.files.subtitle': 'Gestione dei file di ogni server',
    'admin.view.backups.title': 'Backup',
    'admin.view.backups.subtitle': 'Backup, download, ripristino ed eliminazione',
    'admin.view.databases.title': 'Database',
    'admin.view.databases.subtitle': 'Gestione dei database assegnati agli utenti',
    'admin.view.network.title': 'Network',
    'admin.view.network.subtitle': 'Porte e regole network della piattaforma',
    'admin.view.support.title': 'Supporto / Ticket',
    'admin.view.support.subtitle': 'Gestione completa delle richieste degli utenti',
    'admin.view.billing.title': 'Billing',
    'admin.view.billing.subtitle': 'Piani crediti, costo slot e transazioni',
    'admin.view.nodes.title': 'Nodi',
    'admin.view.nodes.subtitle': 'Gestione VPS, collegamenti SSH e assegnazione utenti',

    'dash.title': 'QubiqoHost — Dashboard',
    'dash.systemsOperational': 'Sistemi operativi',
    'dash.openMenu': 'Apri menu',
    'dash.searchPanel': 'Cerca nel pannello',
    'dash.notifications': 'Notifiche',
    'dash.controlCenter': 'Control center',
    'dash.welcomeBack': 'Bentornato,',
    'dash.heroDesc': 'Controlla server, risorse e attività da un unico spazio operativo.',
    'dash.activeServers': 'Server attivi',
    'dash.online': 'online',
    'dash.allocatedCpu': 'CPU allocata',
    'dash.assignedCapacity': 'Capacità assegnata',
    'dash.memory': 'Memoria',
    'dash.allocatedRam': 'RAM allocata',
    'dash.storage': 'Archiviazione',
    'dash.usedSpace': 'Spazio utilizzato',

    'lang.switch': 'Lingua',
    'lang.it': 'Italiano',
    'lang.en': 'Inglese',
  },

  en: {
    'common.loading': 'Loading…',
    'common.confirm': 'Confirm',
    'common.cancel': 'Cancel',
    'common.save': 'Save',
    'common.close': 'Close',
    'common.error.unknown': 'Unknown error',
    'common.logout': 'Log out',
    'common.admin': 'Admin',
    'common.user': 'User',
    'common.active': 'Active',
    'common.suspended': 'Suspended',
    'common.verified': 'Verified',
    'common.notVerified': 'Not verified',
    'common.modify': 'Edit',
    'common.password': 'Password',
    'common.suspend': 'Suspend',
    'common.reactivate': 'Reactivate',
    'common.delete': 'Delete',
    'common.yes': 'Yes',
    'common.no': 'No',

    'index.title': 'QubiqoHost — Sign in',
    'index.overline': 'Hosting control center',
    'index.heroTitle1': 'Every server.',
    'index.heroTitle2': 'Under control.',
    'index.heroDesc': 'An operations panel designed to manage bots, resources and deployments with clarity, speed and security.',
    'index.feature1Title': 'Centralized management',
    'index.feature1Desc': 'Your entire stack in a single dashboard.',
    'index.feature2Title': 'Live monitoring',
    'index.feature2Desc': 'Resources and status always visible.',
    'index.feature3Title': 'Protected access',
    'index.feature3Desc': 'Secure, reliable authentication.',
    'index.footAllSystems': 'All systems operational',
    'index.footPlatform': 'QubiqoHost / Control platform',
    'index.step': 'Client area',
    'index.loginHeading': 'Sign in to your workspace',
    'index.loginDesc': 'Enter your credentials or use one of the available providers.',
    'index.registerHeading': 'Create your account',
    'index.registerDesc': 'Set up your profile and start managing servers.',
    'index.tabLogin': 'Sign in',
    'index.tabRegister': 'Sign up',
    'index.discordLogin': 'Continue with Discord',
    'index.googleLogin': 'Continue with Google',
    'index.orDivider': 'or use your credentials',
    'index.username': 'Username',
    'index.usernamePlaceholder': 'Your username',
    'index.password': 'Password',
    'index.passwordPlaceholder': 'Your password',
    'index.loginSubmit': 'Sign in to panel',
    'index.regUsernamePlaceholder': 'Choose a username',
    'index.email': 'Email',
    'index.emailPlaceholder': 'name@example.com',
    'index.regPasswordPlaceholder': 'Create a strong password',
    'index.registerSubmit': 'Create account',
    'index.legal': "By signing in you accept QubiqoHost's terms of service and privacy policy.",
    'index.toast.accountCreated': 'Account created. You can now sign in.',
    'index.toast.discordCancelled': 'Discord sign-in cancelled.',
    'index.toast.googleCancelled': 'Google sign-in cancelled.',

    'nav.dashboard': 'Dashboard',
    'nav.server': 'Server',
    'nav.fileManager': 'File Manager',
    'nav.backup': 'Backup',
    'nav.nodes': 'Nodes',
    'nav.collaborators': 'Collaborators',
    'nav.databases': 'Databases',
    'nav.network': 'Network',
    'nav.billing': 'Billing',
    'nav.settings': 'Settings',
    'nav.support': 'Support',
    'nav.workspace': 'WORKSPACE',
    'nav.account': 'ACCOUNT',
    'nav.systemsOk': 'All services online',
    'nav.clientArea': 'Client area',
    'nav.mainNavigation': 'Main navigation',

    'admin.title': 'Users',
    'admin.subtitle': 'Full management of accounts, slots, credits and access',
    'admin.searchPlaceholder': 'Search username, email or PIN…',
    'admin.newUser': '+ New user',
    'admin.filter.all': 'All',
    'admin.filter.discord': 'Discord',
    'admin.filter.google': 'Google',
    'admin.filter.manual': 'Manual',
    'admin.filter.double': 'Possible duplicate accounts',
    'admin.col.user': 'USER',
    'admin.col.email': 'EMAIL',
    'admin.col.access': 'ACCESS',
    'admin.col.linkedIp': 'IP / LINKED ACCOUNTS',
    'admin.col.slots': 'SLOTS',
    'admin.col.credits': 'CREDITS',
    'admin.col.role': 'ROLE',
    'admin.col.status': 'STATUS',
    'admin.col.registered': 'REGISTERED',
    'admin.col.actions': 'ACTIONS',
    'admin.noUsers': 'No users.',
    'admin.pageTitle': 'QubiqoHost — Admin',
    'admin.view.overview.title': 'Overview',
    'admin.view.overview.subtitle': 'Platform overview',
    'admin.view.users.title': 'Users',
    'admin.view.users.subtitle': 'Full management of accounts, slots, credits and access',
    'admin.view.servers.title': 'Server',
    'admin.view.servers.subtitle': 'Full control of all platform servers',
    'admin.view.files.title': 'File Manager',
    'admin.view.files.subtitle': 'Manage files for every server',
    'admin.view.backups.title': 'Backups',
    'admin.view.backups.subtitle': 'Backup, download, restore and deletion',
    'admin.view.databases.title': 'Databases',
    'admin.view.databases.subtitle': 'Manage databases assigned to users',
    'admin.view.network.title': 'Network',
    'admin.view.network.subtitle': 'Platform ports and network rules',
    'admin.view.support.title': 'Support / Tickets',
    'admin.view.support.subtitle': 'Manage all user requests',
    'admin.view.billing.title': 'Billing',
    'admin.view.billing.subtitle': 'Credit plans, slot cost and transactions',
    'admin.view.nodes.title': 'Nodes',
    'admin.view.nodes.subtitle': 'Manage VPS nodes, SSH connections and user assignments',

    'dash.title': 'QubiqoHost — Dashboard',
    'dash.systemsOperational': 'Systems operational',
    'dash.openMenu': 'Open menu',
    'dash.searchPanel': 'Search the panel',
    'dash.notifications': 'Notifications',
    'dash.controlCenter': 'Control center',
    'dash.welcomeBack': 'Welcome back,',
    'dash.heroDesc': 'Monitor servers, resources and activity from a single workspace.',
    'dash.activeServers': 'Active servers',
    'dash.online': 'online',
    'dash.allocatedCpu': 'Allocated CPU',
    'dash.assignedCapacity': 'Assigned capacity',
    'dash.memory': 'Memory',
    'dash.allocatedRam': 'Allocated RAM',
    'dash.storage': 'Storage',
    'dash.usedSpace': 'Used space',

    'lang.switch': 'Language',
    'lang.it': 'Italian',
    'lang.en': 'English',
  }
};

const ADMIN_LITERAL_EN = {
  'Panoramica': 'Overview',
  'Panoramica della piattaforma': 'Platform overview',
  'Utenti': 'Users',
  'Gestione completa degli account, slot, crediti e accessi': 'Full management of accounts, slots, credits and access',
  'Server': 'Server',
  'Controllo completo di tutti i server della piattaforma': 'Full control of all platform servers',
  'File Manager': 'File Manager',
  'Gestione dei file di ogni server': 'Manage files for every server',
  'Backup': 'Backups',
  'Backup, download, ripristino ed eliminazione': 'Backup, download, restore and deletion',
  'Database': 'Databases',
  'Gestione dei database assegnati agli utenti': 'Manage databases assigned to users',
  'Network': 'Network',
  'Porte e regole network della piattaforma': 'Platform ports and network rules',
  'Supporto / Ticket': 'Support / Tickets',
  'Gestione completa delle richieste degli utenti': 'Manage all user requests',
  'Billing': 'Billing',
  'Piani crediti, costo slot e transazioni': 'Credit plans, slot cost and transactions',
  'Nodi': 'Nodes',
  'Gestione VPS, collegamenti SSH e assegnazione utenti': 'Manage VPS nodes, SSH connections and user assignments',
  'Gestione utenti, bot e risorse della piattaforma': 'Manage users, bots and platform resources',
  'Utenti totali': 'Total users',
  'Nuovi utenti · 7 giorni': 'New users · 7 days',
  'registrazioni': 'registrations',
  'Utenti attivi': 'Active users',
  'sospesi': 'suspended',
  'Server totali': 'Total servers',
  'Server online': 'Online servers',
  'CPU allocata': 'Allocated CPU',
  'RAM allocata': 'Allocated RAM',
  'Slot disponibili': 'Available slots',
  'Slot utilizzati': 'Used slots',
  'Crediti emessi': 'Credits issued',
  'Costo di 1 slot': 'Cost of 1 slot',
  'Piani disponibili': 'Available plans',
  'Coupon attivi': 'Active coupons',
  'Transazioni': 'Transactions',
  'Tutti': 'All',
  'Discord': 'Discord',
  'Google': 'Google',
  'Manuale': 'Manual',
  'Possibili doppi account': 'Possible duplicate accounts',
  'Azioni': 'Actions',
  'UTENTE': 'USER',
  'EMAIL': 'EMAIL',
  'ACCESSO': 'ACCESS',
  'IP / Account collegati': 'IP / Linked accounts',
  'SLOT': 'SLOTS',
  'CREDITI': 'CREDITS',
  'RUOLO': 'ROLE',
  'STATO': 'STATUS',
  'REGISTRATO': 'REGISTERED',
  'Nome': 'Name',
  'Email': 'Email',
  'Ruolo': 'Role',
  'Stato': 'Status',
  'Registrato': 'Registered',
  'Account': 'Account',
  'Admin': 'Admin',
  'Utente': 'User',
  'Area cliente': 'Client area',
  'Sistemi operativi': 'Systems operational',
  'Tutti i servizi sono online': 'All services online',
  'Aggiungi piano': 'Add plan',
  'Crea coupon': 'Create coupon',
  'Nuovo coupon': 'New coupon',
  'Nuovo piano crediti': 'New credit plan',
  'Nuovo utente': 'New user',
  '＋ Nuovo utente': '＋ New user',
  '＋ Aggiungi nodo': '＋ Add node',
  '＋ Crea server': '＋ Create server',
  '＋ Crea backup': '＋ Create backup',
  '＋ Nuovo database': '＋ New database',
  '＋ Nuova regola': '＋ New rule',
  '＋ File': '＋ File',
  '＋ Cartella': '＋ Folder',
  'Salva': 'Save',
  'Salva configurazione': 'Save configuration',
  'Annulla': 'Cancel',
  'Chiudi': 'Close',
  'Modifica': 'Edit',
  'Elimina': 'Delete',
  'Sospendi': 'Suspend',
  'Riattiva': 'Reactivate',
  'Attivo': 'Active',
  'Sospeso': 'Suspended',
  'Online': 'Online',
  'Offline': 'Offline',
  'Aggiornato': 'Updated',
  'Apri': 'Open',
  'Indietro': 'Back',
  'Aggiorna': 'Refresh',
  'Upload': 'Upload',
  'Risorse piattaforma': 'Platform resources',
  'Seleziona un server.': 'Select a server.',
  'Cartella vuota.': 'Empty folder.',
  'Nessun utente.': 'No users.',
  'Nessun ticket.': 'No tickets.',
  'Nessun piano': 'No plans',
  'Nessun coupon': 'No coupons',
  'Crea server': 'Create server',
  'Proprietario': 'Owner',
  'Nome server': 'Server name',
  'Runtime': 'Runtime',
  'Token Discord': 'Discord token',
  'Nuovo token': 'New token',
  'Stato attuale': 'Current status',
  'Tipo': 'Type',
  'Quantità': 'Quantity',
  'Utilizzi': 'Uses',
  'Codice': 'Code',
  'Categoria': 'Category',
  'Oggetto': 'Subject',
  'Data': 'Date',
  'Dimensione': 'Size',
  'Porta': 'Port',
  'Protocollo': 'Protocol',
  'Servizio': 'Service',
  'Nodo': 'Node',
  'ID': 'ID',
  'Host': 'Host',
  'SSH': 'SSH',
  'VPS': 'VPS',
  'Username DB': 'DB username',
  'Valuta': 'Currency',
  'Prezzo': 'Price',
  'Prezzo EUR': 'Price EUR',
  'Costo slot': 'Slot cost',
  'Limite utilizzi': 'Usage limit',
  'Crediti o slot': 'Credits or slots',
  'offerte PayPal': 'PayPal offers',
  'ultime registrate': 'latest registrations',
  'Ultimi 7 giorni': 'Last 7 days',
  'Ultimi 30 giorni': 'Last 30 days',
  'Report utenti': 'User report',
  'Report server': 'Server report',
  'Distribuzione server': 'Server distribution',
  'Controllo completo dei server di tutti gli utenti: avvio, stop, restart, console, file, risorse, sospensione ed eliminazione.': 'Full control of all user servers: start, stop, restart, console, files, resources, suspension and deletion.',
  'Tutti i backup di tutti gli utenti.': 'All backups from all users.',
  'Gestione globale delle porte e regole network.': 'Global management of ports and network rules.',
  'Gestisci tutti i ticket, rispondi agli utenti e cambia lo stato.': 'Manage all tickets, reply to users and change their status.',
  'Gestione delle VPS, collegamento SSH, stato dei nodi e assegnazione degli utenti.': 'Manage VPS nodes, SSH connections, node status and user assignments.',
  'Gestione database assegnati agli utenti.': 'Manage databases assigned to users.',
  'Configurazione slot': 'Slot configuration',
  'Piani crediti': 'Credit plans',
  'Modifica o rimuovi': 'Edit or remove',
  'Tutti i sistemi operativi': 'All systems operational',
  'QubiqoHost / Control platform': 'QubiqoHost / Control platform',
  '← Indietro': '← Back',
  '↑ Upload': '↑ Upload',
};

const ADMIN_LITERAL_IT = Object.fromEntries(
  Object.entries(ADMIN_LITERAL_EN).map(([it, en]) => [en, it])
);

const USER_LITERAL_EN = {
  'Crediti e Slot': 'Credits and Slots',
  'Crediti e slot': 'Credits and slots',
  'Workspace': 'Workspace',
  'Dashboard': 'Dashboard',
  'Server': 'Server',
  'File Manager': 'File Manager',
  'Backup': 'Backups',
  'Account': 'Account',
  'Collaboratori': 'Collaborators',
  'Fatturazione': 'Billing',
  'Impostazioni': 'Settings',
  'Supporto': 'Support',
  'Sistemi operativi': 'Systems operational',
  'Tutti i servizi sono online': 'All services online',
  'Utente': 'User',
  'Area cliente': 'Client area',
  'Bentornato,': 'Welcome back,',
  'Controlla server, risorse e attività da un unico spazio operativo.': 'Monitor servers, resources and activity from a single workspace.',
  'Oggi': 'Today',
  'Server attivi': 'Active servers',
  'CPU allocata': 'Allocated CPU',
  'Capacità assegnata': 'Assigned capacity',
  'Memoria': 'Memory',
  'RAM allocata': 'Allocated RAM',
  'Archiviazione': 'Storage',
  'Spazio utilizzato': 'Used space',
  'Performance': 'Performance',
  'Utilizzo risorse': 'Resource usage',
  'Aggiornamento live': 'Live update',
  'Ultimi 7 giorni': 'Last 7 days',
  'Infrastruttura': 'Infrastructure',
  'Stato dei servizi': 'Service status',
  'Operativo': 'Operational',
  'Disponibilità ultimi 30 giorni': 'Availability over the last 30 days',
  'Registro': 'Log',
  'Attività recenti': 'Recent activity',
  'Ultimi eventi': 'Latest events',
  'Allocazione': 'Allocation',
  'Consumo risorse': 'Resource usage',
  'In tempo reale': 'Real time',
  'Disco': 'Disk',
  'Scorciatoie': 'Shortcuts',
  'Azioni rapide': 'Quick actions',
  'Crea un server': 'Create a server',
  'Configura un nuovo ambiente in pochi passaggi.': 'Set up a new environment in a few steps.',
  'Apri': 'Open',
  'Gestisci i file': 'Manage files',
  'Modifica il contenuto dei tuoi server.': 'Edit your server files.',
  'Crea un backup': 'Create a backup',
  'Proteggi i dati con una copia aggiornata.': 'Protect your data with an up-to-date copy.',
  'I tuoi server': 'Your servers',
  'Gestisci, avvia, riavvia e monitora tutti i tuoi bot in tempo reale.': 'Manage, start, restart and monitor all your bots in real time.',
  'Nuovo server': 'New server',
  'Ogni riquadro corrisponde a uno slot': 'Each card corresponds to one slot',
  'Aggiorna': 'Refresh',
  'Modifica, crea, rinomina, carica e scarica i file dei tuoi bot.': 'Edit, create, rename, upload and download your bot files.',
  'File': 'File',
  'Cartella': 'Folder',
  'Chiudi': 'Close',
  'Salva': 'Save',
  'I tuoi database': 'Your databases',
  'Gestisci le risorse MySQL associate al tuo account.': 'Manage the MySQL resources associated with your account.',
  'Nuovo database': 'New database',
  'Nome': 'Name',
  'Tipo': 'Type',
  'Dimensione': 'Size',
  'Creato': 'Created',
  'Proteggi i tuoi dati': 'Protect your data',
  'Crea, scarica e ripristina backup completi dei tuoi bot.': 'Create, download and restore complete backups of your bots.',
  'Nuovo backup': 'New backup',
  'Stato': 'Status',
  'Azioni': 'Actions',
  'Rete e porte': 'Network and ports',
  'Gestisci le porte assegnate ai tuoi servizi.': 'Manage the ports assigned to your services.',
  'Nuova regola': 'New rule',
  'Servizio': 'Service',
  'Protocollo': 'Protocol',
  'Porta': 'Port',
  'Accessi condivisi': 'Shared access',
  "Condividi l'accesso ai server con permessi controllati.": 'Share server access with controlled permissions.',
  'Nuovo collaboratore': 'New collaborator',
  'Username': 'Username',
  'Permessi': 'Permissions',
  'Acquista crediti tramite PayPal e usali per aumentare i tuoi slot.': 'Buy credits through PayPal and use them to increase your slots.',
  'Crediti': 'Credits',
  'Disponibili': 'Available',
  'Slot': 'Slots',
  'Assegnati': 'Assigned',
  'Costo slot': 'Slot cost',
  'Acquista slot': 'Buy slots',
  'Usa i crediti disponibili per aumentare il limite dei server.': 'Use your available credits to increase your server limit.',
  'Acquista uno slot': 'Buy one slot',
  'Hai un codice coupon?': 'Have a coupon code?',
  'Riscattalo per ottenere crediti o slot gratuiti.': 'Redeem it to get free credits or slots.',
  'Riscatta': 'Redeem',
  'Pacchetti crediti': 'Credit packages',
  'Pagamento sicuro con PayPal': 'Secure payment with PayPal',
  'Transazioni': 'Transactions',
  'Descrizione': 'Description',
  'Importo': 'Amount',
  'Data': 'Date',
  'Il tuo account': 'Your account',
  'Modifica profilo, credenziali e preferenze.': 'Edit your profile, credentials and preferences.',
  'Profilo': 'Profile',
  'Non disponibile': 'Unavailable',
  'Email': 'Email',
  'Discord': 'Discord',
  'Password attuale': 'Current password',
  'Necessaria per modificare username o email': 'Required to change your username or email',
  'Salva profilo': 'Save profile',
  'Nuova password': 'New password',
  'Conferma nuova password': 'Confirm new password',
  'Cambia password': 'Change password',
  'Preferenze': 'Preferences',
  'Tema': 'Theme',
  'Scuro': 'Dark',
  'Chiaro': 'Light',
  'Lingua': 'Language',
  'Italiano': 'Italian',
  'English': 'English',
  'Autenticazione a due fattori': 'Two-factor authentication',
  'Salva impostazioni': 'Save settings',
  'Centro assistenza': 'Support center',
  'Apri un ticket e parla con il nostro team.': 'Open a ticket and talk to our team.',
  'Apri un ticket': 'Open a ticket',
  'Ticket': 'Ticket',
  'Categoria': 'Category',
  'Ultimo aggiornamento': 'Last updated',
  'Impossibile caricare la sezione': 'Unable to load section',
  'Nessuna attività recente.': 'No recent activity.',
  'Nessun server. Crea il tuo primo bot.': 'No servers. Create your first bot.',
  'Crea il tuo bot': 'Create your bot',
  'Nome server': 'Server name',
  'Crea server': 'Create server',
  'Server creato': 'Server created',
  'Server avviato': 'Server started',
  'Server arrestato': 'Server stopped',
  'Server riavviato': 'Server restarted',
  'Avvia': 'Start',
  'Riavvia': 'Restart',
  'Arresta': 'Stop',
  'Console': 'Console',
  'Nessun log disponibile.': 'No logs available.',
  'Connessione alla console...': 'Connecting to console...',
  'Eliminare il server?': 'Delete server?',
  'Elimina server': 'Delete server',
  'Crea prima un server.': 'Create a server first.',
  'Modifica': 'Edit',
  'Rinomina': 'Rename',
  'File salvato': 'File saved',
  'File creato': 'File created',
  'Crea nuovo file': 'Create new file',
  'Aggiungi un file al server nella cartella corrente.': 'Add a file to the server in the current folder.',
  'Nome file': 'File name',
  'Crea file': 'Create file',
  'Crea nuova cartella': 'Create new folder',
  'Crea una cartella nella posizione corrente.': 'Create a folder in the current location.',
  'Nome cartella': 'Folder name',
  'Cartella creata': 'Folder created',
  'Rinomina elemento': 'Rename item',
  'Inserisci il nuovo nome del file o della cartella.': 'Enter the new file or folder name.',
  'Nuovo nome': 'New name',
  'Eliminare la cartella?': 'Delete folder?',
  'Eliminare il file?': 'Delete file?',
  'La cartella e tutto il suo contenuto verranno eliminati definitivamente.': 'The folder and all its contents will be permanently deleted.',
  'Il file verrà eliminato definitivamente.': 'The file will be permanently deleted.',
  'Elimina': 'Delete',
  'Nessun database.': 'No databases.',
  'Impossibile caricare i database.': 'Unable to load databases.',
  'Nome database': 'Database name',
  'Crea database': 'Create database',
  'Database creato': 'Database created',
  'Database eliminato': 'Database deleted',
  'Nessun backup.': 'No backups.',
  'Scegli il server di cui vuoi creare una copia completa.': 'Choose the server to create a full backup of.',
  'Server per backup': 'Server for backup',
  'Crea backup': 'Create backup',
  'Ripristinare il backup?': 'Restore backup?',
  'Il contenuto attuale del server verrà sostituito con quello del backup.': 'The current server content will be replaced by the backup.',
  'Eliminare il backup?': 'Delete backup?',
  'Questa copia verrà rimossa definitivamente.': 'This backup will be permanently removed.',
  'Elimina backup': 'Delete backup',
  'Configura una porta TCP per il tuo server.': 'Configure a TCP port for your server.',
  'Aggiungi porta': 'Add port',
  'Aggiungi servizio di rete': 'Add network service',
  'Nessun subuser.': 'No collaborators.',
  'Nuovo subuser': 'New collaborator',
  'Crea un collaboratore con accesso controllato al pannello.': 'Create a collaborator with controlled panel access.',
  'Crea subuser': 'Create collaborator',
  'Il collaboratore perderà immediatamente l’accesso condiviso.': 'The collaborator will immediately lose shared access.',
  'Impostazioni salvate': 'Settings saved',
  'Nessun ticket.': 'No tickets.',
  'Apri nuovo ticket': 'Open new ticket',
  'Salva / Rispondi': 'Save / Reply',
  'Crea prima un server': 'Create a server first',
  'Ticket aperto': 'Ticket opened',
  'Slot acquistato': 'Slot purchased',
  'Acquisto crediti': 'Credit purchase',
  'Inserisci un codice coupon': 'Enter a coupon code',
  'Riscattati': 'Redeemed',
  'Collegato': 'Connected',
  'Non collegato': 'Not connected',
  'PayPal non configurato': 'PayPal is not configured',
  'Nessuna transazione.': 'No transactions.',
  'Billing non configurato.': 'Billing is not configured.',
  'Scrivi un messaggio...': 'Write a message...',
  "Scrivi una risposta all'utente...": 'Write a reply to the user...',
  'Descrivi il problema...': 'Describe the problem...',
  'Descrivi la richiesta': 'Describe the request',
  'Descrivi brevemente il problema o la richiesta.': 'Briefly describe the problem or request.',
  'Scrivi tutti i dettagli utili al team di supporto.': 'Write all useful details for the support team.',
  'Oggetto del ticket': 'Ticket subject',
  'Messaggio': 'Message',
  'Apri ticket': 'Open ticket',
  'Invia': 'Send',
  'Aperto': 'Open',
  'In attesa': 'Pending',
  'Chiuso': 'Closed',
  'Nessun messaggio.': 'No messages.',
  'Gestisci i ticket degli utenti, rispondi e aggiorna lo stato.': 'Manage user tickets, reply and update their status.',
  'Supporto Staff': 'Staff Support',
  'Nessun file.': 'No files.',
  'Cartella vuota.': 'Empty folder.',
  'Il database verrà rimosso dal pannello.': 'The database will be removed from the panel.',
  'Inserisci una porta TCP compresa tra 1 e 65535.': 'Enter a TCP port between 1 and 65535.',
  'Il server, il suo storage e i relativi file verranno eliminati definitivamente.': 'The server, its storage and related files will be permanently deleted.',
};

const USER_LITERAL_IT = Object.fromEntries(
  Object.entries(USER_LITERAL_EN).map(([it, en]) => [en, it])
);

const TRANSLATED_MARKER = 'data-qh-translated';

function getLang() {
  return localStorage.getItem('qh_lang') || 'it';
}

function setLang(lang) {
  if (!I18N_DICT[lang]) return;
  localStorage.setItem('qh_lang', lang);
  document.documentElement.setAttribute('lang', lang);
  document.querySelectorAll('[' + TRANSLATED_MARKER + ']').forEach(el => {
    el.removeAttribute(TRANSLATED_MARKER);
  });
  applyI18n();
  applyAdminTranslation();
  translateUserLiterals(document);
  buildLangSwitcher();
  hideDesktopHeaderControls();
  document.dispatchEvent(new CustomEvent('qh:langchange', { detail: { lang } }));
}

function t(key, fallback) {
  const lang = getLang();
  const dict = I18N_DICT[lang] || I18N_DICT.it;
  return dict[key] ?? I18N_DICT.it[key] ?? fallback ?? key;
}

function applyI18n(root = document) {
  root.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.getAttribute('data-i18n'));
  });
  root.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.setAttribute('placeholder', t(el.getAttribute('data-i18n-placeholder')));
  });
  root.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.setAttribute('title', t(el.getAttribute('data-i18n-title')));
  });
  root.querySelectorAll('[data-i18n-aria-label]').forEach(el => {
    el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria-label')));
  });
}

function qhTranslateText(value) {
  const input = String(value ?? '');
  if (!input.trim()) return input;

  const lang = getLang();
  const dict = lang === 'en' ? USER_LITERAL_EN : USER_LITERAL_IT;
  const trimmed = input.trim();

  if (
    /^\d{1,4}([\/\-\.\s]\d{1,2}){1,2}([\/\-\.\s]\d{1,4})?(\s+\d{1,2}:\d{2}(:\d{2})?)?$/.test(trimmed) ||
    /^\d{4}-\d{2}-\d{2}(T|\s)\d{2}:\d{2}/.test(trimmed) ||
    /^\d+$/.test(trimmed)
  ) {
    return input;
  }

  if (dict[trimmed] !== undefined) {
    const leading = input.match(/^\s*/)?.[0] || '';
    const trailing = input.match(/\s*$/)?.[0] || '';
    return leading + dict[trimmed] + trailing;
  }

  const entries = Object.entries(dict)
    .filter(([key, translated]) => key && translated && key !== translated)
    .sort(([a], [b]) => b.length - a.length);

  let out = input;
  for (const [key, translated] of entries) {
    if (key.length < 4) continue;
    if (/^\d/.test(key) || /\d{2,}/.test(key)) continue;
    const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('(^|[^\\p{L}\\p{N}_])' + escaped + '(?=$|[^\\p{L}\\p{N}_])', 'giu');
    out = out.replace(re, (_, prefix) => prefix + translated);
  }

  if (lang === 'en') {
    out = out.replace(/\b(\d+) server\b/gi, '$1 servers');
    out = out.replace(/\b(\d+) file\b/gi, '$1 files');
  }

  return out;
}

function translateAdminLiterals(root = document) {
  const dict = getLang() === 'en' ? ADMIN_LITERAL_EN : ADMIN_LITERAL_IT;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const node of nodes) {
    if (!node.parentElement || ['SCRIPT', 'STYLE', 'TEXTAREA'].includes(node.parentElement.tagName)) continue;
    if (node.parentElement.hasAttribute(TRANSLATED_MARKER) && node.parentElement.getAttribute(TRANSLATED_MARKER) === getLang()) continue;
    const value = node.nodeValue.trim();
    if (!value || dict[value] === undefined) continue;
    if (
      /^\d{1,4}([\/\-\.\s]\d{1,2}){1,2}([\/\-\.\s]\d{1,4})?(\s+\d{1,2}:\d{2}(:\d{2})?)?$/.test(value) ||
      /^\d{4}-\d{2}-\d{2}/.test(value)
    ) continue;
    const leading = node.nodeValue.match(/^\s*/)?.[0] || '';
    const trailing = node.nodeValue.match(/\s*$/)?.[0] || '';
    node.nodeValue = leading + dict[value] + trailing;
    if (node.parentElement.childNodes.length === 1) {
      node.parentElement.setAttribute(TRANSLATED_MARKER, getLang());
    }
  }
}

function translateUserLiterals(root = document) {
  if (document.body?.classList.contains('admin-page')) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const node of nodes) {
    if (!node.parentElement || ['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE'].includes(node.parentElement.tagName)) continue;
    if (node.parentElement.hasAttribute(TRANSLATED_MARKER) && node.parentElement.getAttribute(TRANSLATED_MARKER) === getLang()) continue;
    const original = node.nodeValue;
    if (!original || !original.trim()) continue;
    const translated = qhTranslateText(original);
    if (translated !== original) {
      node.nodeValue = translated;
      if (node.parentElement.childNodes.length === 1) {
        node.parentElement.setAttribute(TRANSLATED_MARKER, getLang());
      }
    }
  }
}

function translateDashboardLiterals(root = document) {
  applyI18n(root);
  translateUserLiterals(root);
}

function buildLangSwitcher() {
  let el = document.getElementById('qhLangSwitch');

  if (!el) {
    el = document.createElement('div');
    el.id = 'qhLangSwitch';
    el.setAttribute('aria-label', 'Language');
    document.body.appendChild(el);
  }

  const lang = getLang();
  const isIt = lang === 'it';

  el.innerHTML = `
    <button type="button" class="qh-lang-trigger" aria-haspopup="true" aria-expanded="false">
      <span class="qh-lang-flag">${isIt ? '🇮🇹' : '🇬🇧'}</span>
      <span class="qh-lang-code">${isIt ? 'IT' : 'EN'}</span>
      <span class="qh-lang-chevron">⌄</span>
    </button>

    <div class="qh-lang-menu" role="menu">
      <button type="button" class="qh-lang-option ${isIt ? 'active' : ''}" data-qh-lang="it" role="menuitem">
        <span class="qh-lang-option-flag">🇮🇹</span>
        <span>Italiano</span>
        ${isIt ? '<span class="qh-lang-check">✓</span>' : ''}
      </button>

      <button type="button" class="qh-lang-option ${!isIt ? 'active' : ''}" data-qh-lang="en" role="menuitem">
        <span class="qh-lang-option-flag">🇬🇧</span>
        <span>English</span>
        ${!isIt ? '<span class="qh-lang-check">✓</span>' : ''}
      </button>
    </div>
  `;

  const trigger = el.querySelector('.qh-lang-trigger');
  const menu = el.querySelector('.qh-lang-menu');

  const closeMenu = () => {
    el.classList.remove('open');
    trigger.setAttribute('aria-expanded', 'false');
  };

  trigger.onclick = (event) => {
    event.stopPropagation();
    const open = el.classList.toggle('open');
    trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  };

  el.querySelectorAll('[data-qh-lang]').forEach(btn => {
    btn.onclick = (event) => {
      event.stopPropagation();
      closeMenu();
      setLang(btn.getAttribute('data-qh-lang'));
    };
  });

  document.addEventListener('click', (event) => {
    if (!el.contains(event.target)) closeMenu();
  }, { once: false });

  menu.addEventListener('click', event => event.stopPropagation());
}

function applyAdminTranslation() {
  if (document.body?.classList.contains('admin-page')) {
    translateAdminLiterals(document);
    applyI18n();
  }
}

let qhAdminTimer = null;
const qhAdminObserver = new MutationObserver(() => {
  if (!document.body?.classList.contains('admin-page')) return;
  clearTimeout(qhAdminTimer);
  qhAdminTimer = setTimeout(() => {
    qhAdminObserver.disconnect();
    applyAdminTranslation();
    qhAdminObserver.observe(document.body, { childList: true, subtree: true });
  }, 40);
});

let qhUserTimer = null;
const qhUserObserver = new MutationObserver(() => {
  if (document.body?.classList.contains('admin-page')) return;
  clearTimeout(qhUserTimer);
  qhUserTimer = setTimeout(() => {
    qhUserObserver.disconnect();
    translateUserLiterals(document);
    qhUserObserver.observe(document.body, { childList: true, subtree: true });
  }, 40);
});

function hideDesktopHeaderControls() {
  if (!window.matchMedia('(min-width: 769px)').matches) return;

  const selectors = [
    '[aria-label="Notifiche"]',
    '[aria-label="Notifications"]',
    '[title="Notifiche"]',
    '[title="Notifications"]',
    '[data-i18n="dash.notifications"]',
    '[aria-label="Profilo"]',
    '[aria-label="Profile"]',
    '[title="Profilo"]',
    '[title="Profile"]'
  ];

  selectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => {
      const target = el.closest('button, a, [role="button"]') || el;
      if (target.closest('#qhLangSwitch') || target.closest('[data-qh-lang]')) return;
      if (target.matches('[aria-label*="menu" i], [aria-label*="Menu" i], [class*="hamburger" i], [class*="menu-toggle" i], [id*="menu" i]')) return;
      target.style.display = 'none';
    });
  });

  document.querySelectorAll('body *').forEach(el => {
    if (el.children.length > 0) return;
    const text = el.textContent?.trim();
    if (text !== 'Area cliente' && text !== 'Client area') return;

    let target = el;
    const parent = el.parentElement;
    if (parent) {
      const rect = parent.getBoundingClientRect();
      const childCount = parent.children.length;
      if (
        rect.width >= 70 && rect.width <= 160 &&
        rect.height >= 24 && rect.height <= 48 &&
        childCount <= 3
      ) {
        target = parent;
      }
    }

    if (
      target.querySelector?.('[aria-label*="menu" i], [class*="hamburger" i], [class*="menu-toggle" i], [id*="hamburger" i], [id*="menu-toggle" i]') ||
      target.closest?.('#qhLangSwitch')
    ) {
      return;
    }

    target.style.display = 'none';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.setAttribute('lang', getLang());
  applyI18n();
  translateUserLiterals(document);
  buildLangSwitcher();
  hideDesktopHeaderControls();
  applyAdminTranslation();
  if (document.body.classList.contains('admin-page')) {
    qhAdminObserver.observe(document.body, { childList: true, subtree: true });
  } else {
    qhUserObserver.observe(document.body, { childList: true, subtree: true });
  }
  hideDesktopHeaderControls();
  window.addEventListener('resize', hideDesktopHeaderControls);
});
