let currentUser = null;
let allUsers = [];
let allAdminServers = [];
let currentFileServer = '';
let currentFilePath = '';
let currentEditorPath = '';
let adminEmailUsers = [];
let adminTickets = [];
let allAdminNodes = [];

const $id = id => document.getElementById(id);


document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button || button.disabled) return;
  if (button.dataset.adminView || button.dataset.view || button.dataset.viewJump) return;
  const raw = (button.innerText || button.getAttribute('aria-label') || button.title || '').replace(/\s+/g, ' ').trim();
  if (!raw || raw === '×' || raw === '⌄') return;
  if (/^(avvia|arresta|ferma|riavvia|acquista|crea backup|elimina backup|ripristina)$/i.test(raw)) return;
  fetch('/api/audit/movement', {method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin', body:JSON.stringify({action:`Pulsante: ${raw.slice(0,140)}`})}).catch(()=>{});
});

const adminFormatBytes = bytes => { const n=Number(bytes)||0; if(n<1024)return `${n} B`; if(n<1024**2)return `${(n/1024).toFixed(1)} KB`; if(n<1024**3)return `${(n/1024**2).toFixed(1)} MB`; return `${(n/1024**3).toFixed(2)} GB`; };
const adminFormatMB = mb => { const n=Math.max(0, Number(mb)||0); if(n>=1024) return `${(n/1024).toFixed(1)} GB`; return `${n.toFixed(n < 100 ? 1 : 0)} MB`; };

const ADMIN_VIEWS = ['Overview','Users','Servers','Backups','Nodes','Databases','Network','Logs','Support','Email','Billing'];
let adminConsoleTimer = null;
let adminConsoleRequestInFlight = false;
let adminConsoleLogsRequestInFlight = false;
const VIEW_META = {
  Overview:['admin.view.overview.title','admin.view.overview.subtitle'],
  Users:['admin.view.users.title','admin.view.users.subtitle'],
  Servers:['admin.view.servers.title','admin.view.servers.subtitle'],
  Backups:['admin.view.backups.title','admin.view.backups.subtitle'],
  Databases:['admin.view.databases.title','admin.view.databases.subtitle'],
  Network:['admin.view.network.title','admin.view.network.subtitle'],
  Support:['admin.view.support.title','admin.view.support.subtitle'],
  Email:['Email','Invia email personalizzate agli utenti'],
  Billing:['admin.view.billing.title','admin.view.billing.subtitle'],
  Nodes:['admin.view.nodes.title','admin.view.nodes.subtitle'],
  Logs:['Logs','Movimenti e azioni del pannello']
};

async function switchView(view) {
  if (typeof window.qhCloseMobileNav === 'function') window.qhCloseMobileNav();
  if (ADMIN_VIEWS.includes(view) && location.hash !== `#${view.toLowerCase()}`) history.replaceState(null, '', `#${view.toLowerCase()}`);
  try { localStorage.setItem('qh_admin_view', String(view).toLowerCase()); } catch (_) {}
  if (ADMIN_VIEWS.includes(view)) {
    fetch('/api/audit/movement', {method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin', body:JSON.stringify({action:`Apertura sezione ${view}`})}).catch(()=>{});
  }
  ADMIN_VIEWS.forEach(v => document.getElementById('view' + v)?.classList.toggle('hidden', v !== view));
  const meta = VIEW_META[view] || VIEW_META.Overview;
  document.getElementById('pageTitle').textContent = typeof t === 'function' ? t(meta[0]) : meta[0];
  document.getElementById('pageSub').textContent = typeof t === 'function' ? t(meta[1]) : meta[1];
  document.querySelectorAll('.sidebar .nav-item').forEach(n => n.classList.toggle('active', n.dataset.adminView === view));
  const loaders = {Overview:loadStats,Users:loadAdminUsers,Servers:loadAdminServers,Backups:loadAdminBackups,Nodes:loadAdminNodes,Databases:loadAdminDatabases,Network:loadAdminNetwork,Logs:loadAdminLogs,Support:loadAdminTickets,Email:loadAdminEmailUsers,Billing:loadBilling};
  
  
  if (view === 'Email') initAdminEmail();
  if (adminLogTimer) { clearInterval(adminLogTimer); adminLogTimer = null; }
  if (view === 'Logs') adminLogTimer = setInterval(() => loadAdminLogs(), 3000);
  Promise.resolve(loaders[view]?.()).catch(e => toast(e.message || 'Impossibile caricare la sezione', 'error'));
}

document.querySelectorAll('[data-admin-view]').forEach(el => el.addEventListener('click', () => { switchView(el.dataset.adminView); }));


document.addEventListener('qh:langchange', () => {
  const active = document.querySelector('.sidebar .nav-item.active')?.dataset.adminView || 'Overview';
  switchView(active);
});


let statsPollTimer = null;
let statsRequestInFlight = false;
let statsRefreshQueued = false;
let statsFirstLoad = true;

async function loadStats({silent = true} = {}) {
  
  
  
  if (statsRequestInFlight) {
    statsRefreshQueued = true;
    return;
  }
  statsRequestInFlight = true;

  const request = async (path, timeoutMs = 5000) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(path, {
        credentials: 'same-origin',
        cache: 'no-store',
        signal: controller.signal,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Errore caricamento statistiche');
      return data;
    } finally {
      clearTimeout(timer);
    }
  };

  try {
    const s = await request('/api/admin/stats', 5000);

    const n = (value, fallback = 0) => {
      const v = Number(value);
      return Number.isFinite(v) ? v : fallback;
    };
    const text = (id, value) => {
      const el = $id(id);
      if (el) el.textContent = value;
    };

    text('statUsers', n(s.totalUsers));
    text('statUsersSub', `${n(s.newUsersToday)} registrati oggi`);
    text('statUsersWeek', n(s.newUsers7d));
    text('statUsersWeekSub', `${n(s.newUsers30d)} negli ultimi 30 giorni`);
    text('statActiveUsers', n(s.activeUsers));
    text('statSuspendedUsers', `${n(s.suspendedUsers)} sospesi`);
    text('statServers', n(s.totalServers));
    text('statServersSub', `${n(s.stoppedServers)} offline · ${n(s.suspendedServers)} sospesi`);
    text('statRunning', n(s.runningServers));
    text('statStopped', `${n(s.stoppedServers)} offline`);
    text('statRam', `${n(s.ramAllocatedMB)} MB`);
    text('statCpu', `CPU ${n(s.cpuAllocatedCores).toFixed(1)} CPU`);
    text('statUsers7', n(s.newUsers7d));
    text('statUsers30', n(s.newUsers30d));

    const daily = Array.isArray(s.usersByDay) ? s.usersByDay : [];
    const dailyEl = $id('usersDailyReport');
    if (dailyEl) {
      dailyEl.innerHTML = daily.length
        ? `<div class="admin-muted" style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap">${daily.map(d => `<span>${escapeHtml(d.label)}: <b>${n(d.count)}</b></span>`).join('')}</div>`
        : '<div class="admin-muted">Nessun dato disponibile.</div>';
    }

    text('statOnlineReport', n(s.runningServers));
    text('statOfflineReport', n(s.stoppedServers));
    text('statSuspendedServers', n(s.suspendedServers));
    text('statSlotsUsed', `${n(s.usedSlots, n(s.totalServers))} / ${n(s.totalSlots)}`);
    const breakdown = $id('serverBreakdownReport');
    if (breakdown) breakdown.innerHTML = `<div class="admin-muted">${n(s.runningServers)} online · ${n(s.stoppedServers)} offline · ${n(s.suspendedServers)} sospesi</div>`;
    const node = s.primaryNode || null;
    const formatUptime = seconds => {
      const total = Math.max(0, Math.floor(n(seconds)));
      const d = Math.floor(total / 86400);
      const h = Math.floor((total % 86400) / 3600);
      const m = Math.floor((total % 3600) / 60);
      if (d) return `${d}g ${h}h`;
      if (h) return `${h}h ${m}m`;
      return `${m}m`;
    };
    if (node) {
      const nodeStatus = node.online ? 'Online' : 'Offline';
      const host = node.hostname && node.hostname !== node.host ? ` · ${node.hostname}` : '';
      text('runtimeNodeMeta', `${node.name || 'Nodo'} · ${nodeStatus}${host}`);
      text('runtimeCpuTotal', `${n(node.cpuPercent).toFixed(1)}%`);
      text('runtimeCpuSub', `${n(node.cpuCores)} CPU · load ${n(node.load1).toFixed(2)}`);
      text('runtimeRamTotal', `${adminFormatMB(node.ramUsedMB)} / ${adminFormatMB(node.ramTotalMB)}`);
      text('runtimeRamSub', `${n(node.ramPercent).toFixed(1)}% utilizzata`);
      text('runtimeDiskTotal', `${adminFormatMB(node.diskUsedMB)} / ${adminFormatMB(node.diskTotalMB)}`);
      text('runtimeDiskSub', `${n(node.diskPercent).toFixed(1)}% utilizzato`);
      text('runtimeUptimeTotal', formatUptime(node.uptimeSeconds));
      text('runtimeUptimeSub', node.online ? 'Sistema operativo del nodo' : (node.error ? 'Nodo non raggiungibile' : 'Stato non disponibile'));
      text('runtimeLastUpdate', node.updatedAt ? `Aggiornato ${new Date(node.updatedAt).toLocaleTimeString('it-IT')}` : 'In attesa dei dati del nodo');
    } else {
      text('runtimeNodeMeta', 'Nessun nodo collegato al pannello');
      text('runtimeCpuTotal', '—');
      text('runtimeCpuSub', 'Nessun dato');
      text('runtimeRamTotal', '—');
      text('runtimeRamSub', 'Nessun dato');
      text('runtimeDiskTotal', '—');
      text('runtimeDiskSub', 'Nessun dato');
      text('runtimeUptimeTotal', '—');
      text('runtimeUptimeSub', 'Nessun dato');
      text('runtimeLastUpdate', 'Nessun nodo collegato');
    }

    const recent = Array.isArray(s.recentUsers) ? s.recentUsers : [];
    const recentEl = $id('recentUsersReport');
    if (recentEl) {
      recentEl.innerHTML = recent.length
        ? `<div class="admin-muted"><b>Ultimi utenti:</b> ${recent.map(u => `${escapeHtml(u.username)} (${escapeHtml(u.date)})`).join(' · ')}</div>`
        : '<div class="admin-muted">Nessun utente registrato.</div>';
    }

    const overview = $id('viewOverview');
    if (overview) {
      overview.dataset.lastUpdate = String(Date.now());
      overview.dataset.statsReady = '1';
    }
    statsFirstLoad = false;
  } catch (e) {
    try {
      const [ur, sr] = await Promise.all([
        request('/api/admin/users', 5000),
        request('/api/admin/servers', 5000),
      ]);
      const users = Array.isArray(ur.users) ? ur.users : [];
      const servers = Array.isArray(sr.servers) ? sr.servers : [];
      const active = users.filter(u => !u.suspended).length;
      const suspendedUsers = users.length - active;
      const running = servers.filter(s => !!s.running && !s.suspended).length;
      const suspendedServers = servers.filter(s => !!s.suspended).length;
      const stopped = Math.max(0, servers.length - running - suspendedServers);
      const ram = servers.reduce((a, s) => a + (Number(s.ramMB) || 0), 0);
      const cpu = servers.reduce((a, s) => a + (Number(s.cpuCores) || 0.5), 0);
      const now = Date.now(), day = 86400000;
      const new7 = users.filter(u => Number(u.createdAt) >= now - 7 * day).length;
      const new30 = users.filter(u => Number(u.createdAt) >= now - 30 * day).length;
      const today = users.filter(u => Number(u.createdAt) >= now - day).length;
      const set = (id, value) => { const el = $id(id); if (el) el.textContent = value; };
      set('statUsers', users.length); set('statUsersSub', `${today} registrati oggi`);
      set('statUsersWeek', new7); set('statUsersWeekSub', `${new30} negli ultimi 30 giorni`);
      set('statActiveUsers', active); set('statSuspendedUsers', `${suspendedUsers} sospesi`);
      set('statServers', servers.length); set('statServersSub', `${stopped} offline · ${suspendedServers} sospesi`);
      set('statRunning', running); set('statStopped', `${stopped} offline`);
      set('statRam', `${ram} MB`); set('statCpu', `CPU ${cpu.toFixed(1)}`);
      set('statUsers7', new7); set('statUsers30', new30);
      set('statOnlineReport', running); set('statOfflineReport', stopped); set('statSuspendedServers', suspendedServers);
      const fallbackTotalSlots = users.reduce((a,u)=>a+Math.max(0,Number(u.slots)||0),0);
      set('statSlotsUsed', `${servers.length} / ${fallbackTotalSlots}`);
      set('runtimeNodeMeta', 'Dati del nodo non ancora disponibili');
      set('runtimeCpuTotal', '—'); set('runtimeCpuSub', 'In attesa');
      set('runtimeRamTotal', '—'); set('runtimeRamSub', 'In attesa');
      set('runtimeDiskTotal', '—'); set('runtimeDiskSub', 'In attesa');
      set('runtimeUptimeTotal', '—'); set('runtimeUptimeSub', 'In attesa');
      set('runtimeLastUpdate', 'In attesa dei dati del nodo');
      const breakdown = $id('serverBreakdownReport');
      if (breakdown) breakdown.innerHTML = `<div class="admin-muted">${running} online · ${stopped} offline · ${suspendedServers} sospesi</div>`;
      statsFirstLoad = false;
    } catch (fallbackError) {
      if (!silent) console.warn('[admin] statistiche non ancora disponibili:', fallbackError.message || fallbackError);
    }
  } finally {
    statsRequestInFlight = false;
    if (statsRefreshQueued) {
      statsRefreshQueued = false;
      
      setTimeout(() => loadStats({silent:true}), 0);
    }
  }
}

function startStatsPolling() {
  clearInterval(statsPollTimer);
  statsPollTimer = setInterval(() => {
    const overview = $id('viewOverview');
    if (overview && !overview.classList.contains('hidden')) loadStats({silent:true});
  }, 3000);
}

let statsFastRetryTimer = null;





function startStatsFastRetry() {
  clearInterval(statsFastRetryTimer);
  statsFastRetryTimer = setInterval(() => {
    if (!statsFirstLoad) {
      clearInterval(statsFastRetryTimer);
      statsFastRetryTimer = null;
      return;
    }
    const overview = $id('viewOverview');
    if (overview && !overview.classList.contains('hidden')) loadStats({silent:true});
  }, 1200);
}





document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') return;
  const overview = $id('viewOverview');
  if (overview && !overview.classList.contains('hidden')) loadStats({silent:true});
});
window.addEventListener('pageshow', () => {
  const overview = $id('viewOverview');
  if (overview && !overview.classList.contains('hidden')) loadStats({silent:true});
});

function watchOverviewActivation() {
  const overview = $id('viewOverview');
  if (!overview || overview.dataset.statsWatcher === '1') return;
  overview.dataset.statsWatcher = '1';

  const observer = new MutationObserver(() => {
    if (!overview.classList.contains('hidden')) {
      loadStats({silent:true});
    }
  });

  observer.observe(overview, {attributes:true, attributeFilter:['class']});

  if (!overview.classList.contains('hidden')) {
    loadStats({silent:true});
  }
}

function formatAdminUptime(seconds) {
  const s = Math.max(0, Number(seconds) || 0);
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  return d ? `${d}g ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
}

let adminLogCategory = 'all';
let adminLogTimer = null;

async function loadAdminLogs() {
  const q = ($id('adminLogsSearch')?.value || '').trim();
  const url = `/api/admin/logs?category=${encodeURIComponent(adminLogCategory)}&q=${encodeURIComponent(q)}&limit=500`;
  try {
    const r = await api(url);
    const logs = Array.isArray(r.logs) ? r.logs : [];
    const body = $id('adminLogsBody');
    const count = $id('adminLogsCount');
    if (count) count.textContent = `${logs.length} eventi`;
    if (!body) return;
    body.innerHTML = logs.length ? logs.map(log => {
      const categoryLabel = log.category === 'account' ? 'Account' : log.category === 'movement' ? 'Movimento' : log.category === 'action' ? 'Azione' : 'Admin';
      return `<tr>
        <td>${new Date(log.createdAt).toLocaleString('it-IT')}</td>
        <td><b>${escapeHtml(log.username)}</b><br><span class="admin-muted">${escapeHtml(log.email)}</span></td>
        <td><span class="admin-log-category category-${escapeHtml(log.category)}">${categoryLabel}</span></td>
        <td><b>${escapeHtml(log.action)}</b>${log.details ? `<br><span class="admin-muted">${escapeHtml(log.details)}</span>` : ''}</td>
        <td>${escapeHtml(log.ip || '—')}</td>
      </tr>`;
    }).join('') : '<tr><td colspan="5"><div class="empty">Nessun evento trovato.</div></td></tr>';
  } catch (e) { toast(e.message, 'error'); }
}

function setAdminLogCategory(category) {
  adminLogCategory = ['all','account','movement','action','admin'].includes(category) ? category : 'all';
  const label = {all:'Tutti gli eventi',account:'Account',movement:'Movimento',action:'Azione',admin:'Admin'}[adminLogCategory];
  const text = $id('adminLogFilterText'); if (text) text.textContent = label;
  document.querySelector('.admin-log-filter-menu')?.classList.remove('open');
  loadAdminLogs();
}

function toggleAdminLogFilter(event) {
  event?.stopPropagation();
  document.querySelector('.admin-log-filter-menu')?.classList.toggle('open');
}
document.addEventListener('click', () => document.querySelector('.admin-log-filter-menu')?.classList.remove('open'));

function showModal(html) { return globalModal(html); }
function closeModal() { if(adminConsoleTimer){clearInterval(adminConsoleTimer);adminConsoleTimer=null;} closeGlobalModal(); }


const PROVIDER_LABEL = { discord: '🔵 Discord', google: '🔴 Google', manual: '⚪ Manuale' };




function getClusterInfo(u) {
  if (!u.possibleDoubleAccount || !Array.isArray(u.linkedAccounts) || !u.linkedAccounts.length) return null;
  const self = { id: u.id, username: u.username, email: u.email, provider: u.authProvider, createdAt: u.createdAt };
  const members = [self, ...u.linkedAccounts];
  const sorted = [...members].sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
  const primary = sorted[0];
  const others = sorted.filter(m => m.id !== primary.id);
  return { primary, others };
}

function userRow(u, clusterOthers) {
  const verified = u.emailVerified ? '<span class="badge state-ok">Verificata</span>' : '<span class="badge state-bad">Non verificata</span>';
  const status = u.suspended ? '<span class="badge state-bad">Sospeso</span>' : '<span class="badge state-ok">Attivo</span>';
  const accessCount = u.accessCount || 0;
  let linkedCell;
  if (clusterOthers && clusterOthers.length) {
    linkedCell = `<span class="badge state-bad">⚠️ ${clusterOthers.length}</span><br>` +
      clusterOthers.map(o => `<span class="admin-muted">${escapeHtml(o.username)} — ${escapeHtml(o.email || '')} (${PROVIDER_LABEL[o.provider] || o.provider})</span>`).join('<br>');
  } else if (u.linkedAccountCount) {
    linkedCell = `<span class="badge state-bad">${u.linkedAccountCount}</span>`;
  } else {
    linkedCell = `<span class="admin-muted">0</span>`;
  }
  const ipList = Array.isArray(u.ipAddresses) ? u.ipAddresses : [];
  const ipCell = ipList.length
    ? ipList.map(entry => {
        const vpnBadge = entry.vpnOrProxy ? ' <span class="badge state-bad" title="'+escapeHtml(entry.isp||'VPN/proxy nota')+'">VPN/proxy</span>' : '';
        return `<span class="admin-muted">${escapeHtml(entry.ip)}</span>${vpnBadge}`;
      }).join('<br>')
    : '<span class="admin-muted">—</span>';
  return `<tr>
    <td><b>${escapeHtml(u.username)}</b><br><span class="admin-muted">PIN: ${escapeHtml(u.pin || '—')}</span></td>
    <td>${escapeHtml(u.email || '—')}<br>${verified}<br>${ipCell}</td>
    <td>${accessCount}</td>
    <td>${linkedCell}</td>
    <td><input type="number" min="0" value="${u.slots}" style="width:80px" onchange="updateUserField('${u.id}','slots',this.value)"></td>
    <td><input type="number" min="0" value="${u.credits || 0}" style="width:90px" onchange="updateUserField('${u.id}','credits',this.value)"></td>
    <td><span class="badge ${u.role === 'admin' ? 'role-admin' : ''}">${u.role === 'admin' ? 'Admin' : u.role === 'staff' ? 'Staff' : u.role === 'tester' ? 'Tester' : 'Utente'}</span></td>
    <td>${status}</td>
    <td>${u.createdAt ? new Date(u.createdAt).toLocaleDateString('it-IT') : '—'}</td>
    <td><div class="admin-actions">
      <button class="btn btn-sm btn-ghost" onclick="editUser('${u.id}')">Modifica</button>
      <button class="btn btn-sm btn-ghost" onclick="changeUserPassword('${u.id}')">Password</button>
      <button class="btn btn-sm btn-ghost" onclick="toggleUserSuspend('${u.id}',${!u.suspended})">${u.suspended ? 'Riattiva' : 'Sospendi'}</button>
      <button class="btn btn-sm btn-danger" onclick="deleteUser('${u.id}')">Elimina</button>
    </div></td>
  </tr>`;
}

let currentUserFilter = 'all';

async function loadAdminUsers() {
  try {
    allUsers = (await api('/api/admin/users')).users || [];
    updateUserCounts(allUsers);
    applyUserFilter();
  } catch(e) { toast(e.message,'error'); }
}

function updateUserCounts(list) {
  let discord = 0, google = 0, manual = 0;
  const clusters = new Set();
  list.forEach(u => {
    if (u.authProvider === 'discord') discord++;
    else if (u.authProvider === 'google') google++;
    else manual++;
    const c = getClusterInfo(u);
    if (c) clusters.add(c.primary.id);
  });
  $id('userCountAll').textContent = list.length;
  $id('userCountDiscord').textContent = discord;
  $id('userCountGoogle').textContent = google;
  $id('userCountManual').textContent = manual;
  $id('userCountDouble').textContent = clusters.size;
}

function setUserFilter(filter) {
  currentUserFilter = filter;
  document.querySelectorAll('.user-filter').forEach(b => b.classList.toggle('active', b.dataset.userFilter === filter));
  applyUserFilter();
}

function applyUserFilter() {
  const q = ($id('userSearch').value || '').trim().toLowerCase();
  let list = allUsers;
  if (q) list = list.filter(u => `${u.username} ${u.email || ''} ${u.pin || ''}`.toLowerCase().includes(q));
  if (currentUserFilter === 'discord') list = list.filter(u => u.authProvider === 'discord');
  else if (currentUserFilter === 'google') list = list.filter(u => u.authProvider === 'google');
  else if (currentUserFilter === 'manual') list = list.filter(u => u.authProvider === 'manual');
  else if (currentUserFilter === 'double') {
    
    
    list = list
      .map(u => ({ u, cluster: getClusterInfo(u) }))
      .filter(x => x.cluster && x.cluster.primary.id === x.u.id);
  }
  renderAdminUsers(list);
}

function renderAdminUsers(list) {
  const rows = list.map(item => {
    if (item && item.u && item.cluster) return userRow(item.u, item.cluster.others);
    return userRow(item);
  });
  document.getElementById('usersBody').innerHTML = rows.length ? rows.join('') : '<tr><td colspan="10"><div class="empty">Nessun utente.</div></td></tr>';
}
let userSearchTimer;
document.getElementById('userSearch').addEventListener('input', e => {
  clearTimeout(userSearchTimer);
  userSearchTimer = setTimeout(applyUserFilter, 120);
});

function openCreateUser() {
  showModal(`<div class="modal-head"><div><div class="modal-icon">＋</div><div class="eyebrow">Admin</div><h2>Nuovo utente</h2><p class="modal-desc">Crea e configura subito l'account.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>
  <form id="createUserForm" class="modal-form">
    <label>Username<input id="cuUsername" required minlength="3"></label>
    <label>Email<input id="cuEmail" type="email" required></label>
    <label>Password<input id="cuPassword" type="password" required minlength="6"></label>
    <div class="field-row"><label>Ruolo<select id="cuRole"><option value="user">Utente</option><option value="staff">Staff</option><option value="tester">Tester</option><option value="admin">Admin</option></select></label><label>Slot<input id="cuSlots" type="number" min="0" value="1"></label></div>
    <label>Crediti iniziali<input id="cuCredits" type="number" min="0" value="0"></label>
    <div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Crea utente</button></div>
  </form>`);
  document.getElementById('createUserForm').onsubmit = async e => {
    e.preventDefault();
    try { await api('/api/admin/users',{method:'POST',body:{username:$id('cuUsername').value,email:$id('cuEmail').value,password:$id('cuPassword').value,role:$id('cuRole').value,slots:Number($id('cuSlots').value),credits:Number($id('cuCredits').value)}}); closeModal(); toast('Utente creato','success'); loadAdminUsers(); }
    catch(err){toast(err.message,'error');}
  };
}

function editUser(id) {
  const u = allUsers.find(x=>x.id===id); if(!u)return;
  showModal(`<div class="modal-head"><div><div class="modal-icon">👤</div><div class="eyebrow">Utente</div><h2>${escapeHtml(u.username)}</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div>
  <form id="editUserForm" class="modal-form">
    <label>Username<input id="euUsername" value="${escapeHtml(u.username)}" required></label>
    <label>Email<input id="euEmail" type="email" value="${escapeHtml(u.email || '')}" required></label>
    <div class="field-row"><label>Ruolo<select id="euRole"><option value="user" ${u.role==='user'?'selected':''}>Utente</option><option value="staff" ${u.role==='staff'?'selected':''}>Staff</option><option value="tester" ${u.role==='tester'?'selected':''}>Tester</option><option value="admin" ${u.role==='admin'?'selected':''}>Admin</option></select></label><label>Slot<input id="euSlots" type="number" min="0" value="${u.slots}"></label></div>
    <div class="field-row"><label>Crediti<input id="euCredits" type="number" min="0" value="${u.credits||0}"></label><label>Email verificata<select id="euVerified"><option value="true" ${u.emailVerified?'selected':''}>Sì</option><option value="false" ${!u.emailVerified?'selected':''}>No</option></select></label></div>
    <label>Nuova password <span class="admin-muted">(lascia vuoto per non cambiarla)</span><input id="euPassword" type="password" minlength="6"></label>
    <div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva modifiche</button></div>
  </form>`);
  document.getElementById('editUserForm').onsubmit = async e => {
    e.preventDefault();
    const body={username:$id('euUsername').value,email:$id('euEmail').value,role:$id('euRole').value,slots:Number($id('euSlots').value),credits:Number($id('euCredits').value),emailVerified:$id('euVerified').value==='true'};
    if($id('euPassword').value) body.password=$id('euPassword').value;
    try{await api(`/api/admin/users/${id}`,{method:'PATCH',body});closeModal();toast('Utente aggiornato','success');await loadAdminUsers();}catch(err){toast(err.message,'error');}
  };
}
async function changeUserPassword(id){const u=allUsers.find(x=>x.id===id);const password=await qhPrompt({title:'Cambia password',description:`Nuova password per ${u?.username||'utente'}.`,label:'Nuova password',type:'password',submit:'Salva password',icon:'🔐'});if(password===null)return;if(password.length<6)return toast('Minimo 6 caratteri','error');try{await api(`/api/admin/users/${id}`,{method:'PATCH',body:{password}});toast('Password aggiornata','success');}catch(e){toast(e.message,'error');}}
async function updateUserField(id,field,value){const body={};body[field]=field==='slots'?Math.max(0,Math.floor(Number(value)||0)):Math.max(0,Math.floor(Number(value)||0));try{await api(`/api/admin/users/${id}`,{method:'PATCH',body});toast(field==='slots'?'Slot aggiornati':'Crediti aggiornati','success');}catch(e){toast(e.message,'error');loadAdminUsers();}}
async function toggleUserSuspend(id,suspended){try{await api(`/api/admin/users/${id}`,{method:'PATCH',body:{suspended}});toast(suspended?'Utente sospeso':'Utente riattivato','success');loadAdminUsers();}catch(e){toast(e.message,'error');}}
async function deleteUser(id){const u=allUsers.find(x=>x.id===id);if(!await qhConfirm({icon:'🗑',title:'Eliminare utente?',description:`Verranno eliminati anche i suoi server: ${u?.username||''}.`,submit:'Elimina'}))return;try{await api(`/api/admin/users/${id}`,{method:'DELETE'});toast('Utente eliminato','success');loadAdminUsers();}catch(e){toast(e.message,'error');}}


function renderAdminServers(){
  const body=document.getElementById('serversBody');
  if(!body)return;
  body.innerHTML=allAdminServers.length?allAdminServers.map(s=>`<tr data-server-id="${s.id}" class="admin-server-row" onclick="openServerPanel('${s.id}','console')">
    <td><b>${escapeHtml(s.name)}</b><br><span class="admin-muted">${s.id.slice(0,8)}</span></td><td>${escapeHtml(s.ownerUsername)}</td><td>${escapeHtml(s.ownerEmail)}</td><td>${s.language==='nodejs'?'Node.js':'Python'}</td><td>${s.ramMB} MB</td><td>${Number(s.cpuCores || 0.5).toFixed(1)} CPU</td>
    <td class="admin-server-status">${s.suspended?'<span class="badge state-bad">Sospeso</span>':s.running?'<span class="badge state-ok">Online</span>':'<span class="badge">Offline</span>'}</td>
    <td><div class="admin-actions">
      <button class="btn btn-sm btn-ghost" ${s.running||s.suspended?'disabled':''} onclick="event.stopPropagation();adminServerAction('${s.id}','start')">Avvia</button>
      <button class="btn btn-sm btn-ghost" ${!s.running||s.suspended?'disabled':''} onclick="event.stopPropagation();adminServerAction('${s.id}','stop')">Stop</button>
      <button class="btn btn-sm btn-ghost" ${s.suspended?'disabled':''} onclick="event.stopPropagation();adminServerAction('${s.id}','restart')">Riavvia</button>
      <button class="btn btn-sm btn-ghost" onclick="event.stopPropagation();openServerPanel('${s.id}','console')">Console</button><button class="btn btn-sm btn-ghost" onclick="event.stopPropagation();editServer('${s.id}')">Modifica</button><button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteAdminServer('${s.id}')">Elimina</button>
    </div></td></tr>`).join(''):'<tr><td colspan="8"><div class="empty">Nessun server.</div></td></tr>';
}
async function loadAdminServers(){
  try{const r=await api('/api/admin/servers');allAdminServers=r.servers||[];renderAdminServers();}
  catch(e){toast(e.message,'error');}
}
async function adminServerAction(id,action){
  const s=allAdminServers.find(x=>String(x.id)===String(id));
  if(!s)return;

  try{
    const result=await api(`/api/servers/${id}/${action}`,{method:'POST'});

    toast(
      result?.pending
        ? 'Operazione avviata in background'
        : action==='start'
          ? 'Server avviato'
          : action==='stop'
            ? 'Server arrestato'
            : 'Server riavviato',
      'success'
    );

    await loadAdminServers();

    let attempts=0;
    const timer=setInterval(async()=>{
      attempts++;
      await loadAdminServers();

      const fresh=allAdminServers.find(x=>String(x.id)===String(id));
      if(
        fresh &&
        (
          (action==='start' && fresh.running) ||
          (action==='stop' && !fresh.running) ||
          (action==='restart' && fresh.running)
        )
      ){
        clearInterval(timer);
      }

      if(attempts>=15)clearInterval(timer);
    },1000);

  }catch(e){
    toast(e.message,'error');
    await loadAdminServers();
  }
}
async function createAdminServer(){
  if(!allUsers.length) await loadAdminUsers();
  const options=allUsers.map(u=>`<option value="${u.id}">${escapeHtml(u.username)} — ${escapeHtml(u.email||'')}</option>`).join('');
  showModal(`<div class="modal-head"><div><div class="modal-icon">🖥️</div><div class="eyebrow">Admin</div><h2>Crea server</h2><p class="modal-desc">Il server viene creato direttamente nello storage dell'utente.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="createAdminServerForm" class="modal-form"><label>Proprietario<select id="casOwner">${options}</select></label><label>Nome server<input id="casName" value="Discord Bot" required></label><div class="field-row"><label>Runtime<select id="casLang"><option value="nodejs">Node.js</option><option value="python">Python</option></select></label><label>RAM MB<input id="casRam" type="number" min="1" value="256"></label></div><div class="field-row"><label>CPU<input value="0.5 CPU" disabled></label><label>Token Discord<input id="casToken" type="password" required></label></div><div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Crea server</button></div></form>`);
  document.getElementById('createAdminServerForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/admin/servers',{method:'POST',body:{ownerId:$id('casOwner').value,name:$id('casName').value,language:$id('casLang').value,ramMB:Number($id('casRam').value),botToken:$id('casToken').value}});closeModal();toast('Server creato','success');loadAdminServers();}catch(err){toast(err.message,'error');}};
}
async function editServer(id){const s=allAdminServers.find(x=>x.id===id);if(!s)return;if(!allUsers.length)await loadAdminUsers();const ownerOptions=allUsers.map(u=>`<option value="${u.id}" ${u.id===s.ownerId?'selected':''}>${escapeHtml(u.username)} — ${escapeHtml(u.email||'')}</option>`).join('');showModal(`<div class="modal-head"><div><div class="modal-icon">🖥️</div><div class="eyebrow">Server</div><h2>Modifica ${escapeHtml(s.name)}</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="editServerForm" class="modal-form"><label>Nome<input id="esName" value="${escapeHtml(s.name)}" required></label><label>Proprietario<select id="esOwner">${ownerOptions}</select></label><div class="field-row"><label>RAM MB<input id="esRam" type="number" min="1" value="${s.ramMB}"></label><label>CPU<input value="0.5 CPU" disabled></label></div><label>Nuovo token <span class="admin-muted">(lascia vuoto per mantenere quello attuale)</span><input id="esToken" type="password"></label><div class="field-row"><label>Stato<select id="esSusp"><option value="false" ${!s.suspended?'selected':''}>Attivo</option><option value="true" ${s.suspended?'selected':''}>Sospeso</option></select></label></div><div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva</button></div></form>`);document.getElementById('editServerForm').onsubmit=async e=>{e.preventDefault();const body={name:$id('esName').value,ownerId:$id('esOwner').value,ramMB:Number($id('esRam').value),suspended:$id('esSusp').value==='true'};if($id('esToken').value)body.botToken=$id('esToken').value;try{await api(`/api/admin/servers/${id}`,{method:'PATCH',body});closeModal();toast('Server aggiornato','success');loadAdminServers();}catch(err){toast(err.message,'error');}};}
async function deleteAdminServer(id){if(!await qhConfirm({icon:'🗑',title:'Eliminare server?',description:'Storage e configurazione verranno eliminati definitivamente.',submit:'Elimina server'}))return;try{await api(`/api/admin/servers/${id}`,{method:'DELETE'});toast('Server eliminato','success');loadAdminServers();}catch(e){toast(e.message,'error');}}
let adminServerPanelFilePath='';

function serverPanelTabs(id,active){
  return `<div class="admin-server-tabs" role="tablist">
    <button type="button" class="admin-server-tab ${active==='console'?'active':''}" onclick="openServerPanel('${id}','console')"><svg class="ui-icon"><use href="#i-terminal"></use></svg><span>Console</span></button>
    <button type="button" class="admin-server-tab ${active==='files'?'active':''}" onclick="openServerPanel('${id}','files')"><svg class="ui-icon"><use href="#i-files"></use></svg><span>File Manager</span></button>
  </div>`;
}

async function openServerPanel(id,tab='console'){
  const s=allAdminServers.find(x=>x.id===id); if(!s)return;
  if(adminConsoleTimer){clearInterval(adminConsoleTimer);adminConsoleTimer=null;}
  currentFileServer=id;
  if(tab==='files' && !adminServerPanelFilePath)adminServerPanelFilePath='';
  showModal(`<div class="admin-server-workspace">
    <div class="admin-server-head">
      <div class="admin-server-heading">
        <div class="admin-server-icon"><svg class="ui-icon"><use href="#i-server"></use></svg></div>
        <div><div class="eyebrow">Server slot</div><h2>${escapeHtml(s.name)}</h2><div class="admin-server-meta">${escapeHtml(s.ownerUsername||'')} · ${s.language==='nodejs'?'Node.js':'Python'} · ${s.ramMB} MB · ${Number(s.cpuCores||0.5).toFixed(1)} CPU</div></div>
      </div>
      <button type="button" class="icon-btn" onclick="closeModal()">×</button>
    </div>
    ${serverPanelTabs(id,tab)}
    <div id="adminServerPanelBody"></div>
  </div>`);
  if(tab==='files')return renderServerPanelFiles(id);
  const body=document.getElementById('adminServerPanelBody');
  body.innerHTML=`<div class="admin-console-workspace">
    <div class="admin-console-toolbar"><div class="admin-console-status"><span class="admin-console-dot ${s.running?'online':''}"></span><span id="adminConsoleStatus">${s.running?'Online':'Offline'}</span></div><div class="server-action-bar"><button id="adminStartBtn" class="btn btn-gradient" onclick="adminServerActionFromConsole('${id}','start')">▶ Avvia</button><button id="adminStopBtn" class="btn btn-outline" onclick="adminServerActionFromConsole('${id}','stop')">■ Stop</button><button id="adminRestartBtn" class="btn btn-outline" onclick="adminServerActionFromConsole('${id}','restart')">↻ Riavvia</button></div></div>
    <div class="admin-console-frame"><div class="admin-console-top"><span></span><span></span><span></span><b>SERVER CONSOLE</b></div><pre id="adminConsole" class="console admin-console">Caricamento...</pre></div>
    <div class="console-input admin-console-input"><input id="adminConsoleCmd" placeholder="Digita un comando..."><button class="btn btn-gradient" onclick="sendAdminCommand('${id}')">Invia</button></div>
  </div>`;
  await refreshAdminConsole(id);
  adminConsoleTimer=setInterval(()=>refreshAdminConsole(id),1000);
  updateAdminConsoleButtons(!!s.running);
}

async function openServerConsole(id){return openServerPanel(id,'console');}

async function renderServerPanelFiles(id){
  const body=document.getElementById('adminServerPanelBody'); if(!body)return;
  body.innerHTML=`<div class="admin-server-files">
    <div class="admin-files-toolbar"><div class="admin-path"><button type="button" class="btn btn-sm btn-ghost" onclick="serverPanelFileUp('${id}')">← Indietro</button><span id="serverPanelPath" class="admin-pill">/${escapeHtml(adminServerPanelFilePath||'')}</span></div><div class="admin-actions"><button type="button" class="btn btn-sm btn-ghost" onclick="createServerPanelFile('${id}')">＋ File</button><button type="button" class="btn btn-sm btn-ghost" onclick="createServerPanelFolder('${id}')">＋ Cartella</button><button type="button" class="btn btn-sm btn-ghost" onclick="refreshServerPanelFiles('${id}')">↻ Aggiorna</button></div></div>
    <div class="admin-server-file-list" id="serverPanelFilesList"><div class="admin-muted">Caricamento file...</div></div>
  </div>`;
  try{
    const r=await api(`/api/admin/servers/${id}/files?path=${encodeURIComponent(adminServerPanelFilePath||'')}`);
    document.getElementById('serverPanelPath').textContent='/'+(r.path||'');
    const list=document.getElementById('serverPanelFilesList');
    list.innerHTML=(r.files||[]).length?r.files.map(f=>`<div class="admin-server-file-row"><div class="admin-server-file-main"><span class="admin-server-file-icon"><svg class="ui-icon"><use href="${f.isDir?'#i-files':'#i-code'}"></use></svg></span><div><b>${escapeHtml(f.name)}</b><small>${f.isDir?'Cartella':adminFormatBytes(f.size)}</small></div></div><div class="admin-actions"><button type="button" class="btn btn-sm btn-ghost" onclick="${f.isDir?`openServerPanelFolder('${id}','${encodeURIComponent(f.name)}')`:`openServerFileEditor('${id}','${encodeURIComponent(f.path)}')`}">${f.isDir?'Apri':'Modifica'}</button><button type="button" class="btn btn-sm btn-danger" onclick="deleteServerPanelPath('${id}','${encodeURIComponent(f.path)}',${f.isDir})">×</button></div></div>`).join(''):'<div class="admin-server-files-empty">Nessun file in questa cartella.</div>';
  }catch(e){body.innerHTML=`<div class="admin-server-files-empty">${escapeHtml(e.message||'Impossibile caricare i file.')}</div>`;}
}
function refreshServerPanelFiles(id){return renderServerPanelFiles(id);}
function openServerPanelFolder(id,encoded){adminServerPanelFilePath=adminServerPanelFilePath?`${adminServerPanelFilePath}/${decodeURIComponent(encoded)}`:decodeURIComponent(encoded);return renderServerPanelFiles(id);}
function serverPanelFileUp(id){if(!adminServerPanelFilePath)return;const p=adminServerPanelFilePath.split('/');p.pop();adminServerPanelFilePath=p.join('/');return renderServerPanelFiles(id);}
async function createServerPanelFile(id){const name=await qhPrompt({title:'Nuovo file',label:'Nome file',value:'index.js',submit:'Crea file',icon:'📄'});if(name===null)return;try{await api(`/api/admin/servers/${id}/files/create`,{method:'POST',body:{path:adminServerPanelFilePath,name,content:''}});refreshServerPanelFiles(id);}catch(e){toast(e.message,'error');}}
async function createServerPanelFolder(id){const name=await qhPrompt({title:'Nuova cartella',label:'Nome cartella',value:'src',submit:'Crea cartella',icon:'📁'});if(name===null)return;try{await api(`/api/admin/servers/${id}/folders/create`,{method:'POST',body:{path:adminServerPanelFilePath,name}});refreshServerPanelFiles(id);}catch(e){toast(e.message,'error');}}
async function deleteServerPanelPath(id,encoded,isDir){if(!await qhConfirm({icon:'🗑',title:isDir?'Eliminare cartella?':'Eliminare file?',description:'L’elemento verrà eliminato definitivamente.',submit:'Elimina'}))return;try{await api(`/api/admin/servers/${id}/file?path=${encoded}`,{method:'DELETE'});refreshServerPanelFiles(id);}catch(e){toast(e.message,'error');}}
async function openServerFileEditor(id,encoded){
  const filePath=decodeURIComponent(encoded);
  try{
    const r=await api(`/api/admin/servers/${id}/file?path=${encodeURIComponent(filePath)}`);
    currentEditorPath=filePath;
    showModal(`<div class="admin-file-editor-modal"><div class="modal-head"><div><div class="modal-icon"><svg class="ui-icon"><use href="#i-code"></use></svg></div><div class="eyebrow">Editor file</div><h2>${escapeHtml(filePath.split('/').pop()||filePath)}</h2><p class="modal-desc">${escapeHtml(filePath)}</p></div><button type="button" class="icon-btn" onclick="openServerPanel('${id}','files')">×</button></div><div class="admin-editor-surface"><textarea id="editorText" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" wrap="off">${escapeHtml(trimEditorTrailingBlankLines(r.content||''))}</textarea></div><div class="admin-editor-actions"><button type="button" class="btn btn-outline" onclick="openServerPanel('${id}','files')">ANNULLA</button><button type="button" class="btn btn-gradient" onclick="saveServerFileEditor('${id}')">SALVA</button></div></div>`);
    resizeAdminEditor();
    document.getElementById('editorText')?.focus();
  }catch(e){toast(e.message,'error');}
}
async function saveServerFileEditor(id){if(!currentEditorPath)return;try{await api(`/api/admin/servers/${id}/file?path=${encodeURIComponent(currentEditorPath)}`,{method:'PUT',body:{content:document.getElementById('editorText').value}});toast('File salvato','success');currentEditorPath='';await openServerPanel(id,'files');}catch(e){toast(e.message,'error');}}
async function adminServerActionFromConsole(id,action){
  const s=allAdminServers.find(x=>x.id===id);
  const previous=s?!!s.running:false;

  if(s){
    if(action==='start'||action==='restart')s.running=true;
    if(action==='stop')s.running=false;
    renderAdminServers();
    updateAdminConsoleButtons(s.running);
  }

  if(action==='stop'){
    const out=document.getElementById('adminConsole');
    if(out)out.textContent='Nessun log disponibile.';
  }

  try{
    const result=await api(`/api/servers/${id}/${action}`,{method:'POST'});
    toast(result?.message||(
      action==='start'?'Avvio richiesto':
      action==='stop'?'Arresto richiesto':'Riavvio richiesto'
    ),'success');

    if(action==='stop'){
      updateAdminConsoleButtons(false);
      const status=document.getElementById('adminConsoleStatus');
      if(status){
        status.className='badge';
        status.textContent='Offline';
      }
    }else{
      await refreshAdminConsole(id);
    }

    loadAdminServers();

    if(action!=='stop'){
      setTimeout(()=>refreshAdminConsole(id),1800);
      setTimeout(()=>{refreshAdminConsole(id);loadAdminServers();},5000);
    }else{
      setTimeout(loadAdminServers,1800);
      setTimeout(loadAdminServers,5000);
    }
  }
  catch(e){
    if(s){
      s.running=previous;
      renderAdminServers();
      updateAdminConsoleButtons(s.running);
    }
    if(action==='stop'){
      refreshAdminConsole(id);
    }
    toast(e.message,'error');
  }
}
function updateAdminConsoleButtons(running){const start=document.getElementById('adminStartBtn'),stop=document.getElementById('adminStopBtn'),restart=document.getElementById('adminRestartBtn'),status=document.getElementById('adminConsoleStatus');if(start)start.disabled=running;if(stop)stop.disabled=!running;if(restart)restart.disabled=false;if(status){status.className=`badge ${running?'state-ok':''}`;status.textContent=running?'Online':'Offline';}}
async function loadAdminConsoleLogs(id){
  if(adminConsoleLogsRequestInFlight)return;
  adminConsoleLogsRequestInFlight=true;
  try{
    const logsResult=await api(`/api/servers/${id}/logs`)
      .then(data=>({ok:true,data}))
      .catch(e=>({ok:false,error:e}));
    if(logsResult.ok){
      const el=document.getElementById('adminConsole');
      if(el){
        const nearBottom=el.scrollHeight-el.scrollTop-el.clientHeight<80;
        el.textContent=(logsResult.data?.logs||[]).join('\n')||'Nessun log disponibile.';
        if(nearBottom)el.scrollTop=el.scrollHeight;
      }
    }
  }catch(e){
    console.warn('Errore aggiornamento log console admin:',e);
  }finally{
    adminConsoleLogsRequestInFlight=false;
  }
}

async function refreshAdminConsole(id){
  // I log vengono aggiornati subito e non aspettano le statistiche SSH.
  void loadAdminConsoleLogs(id);

  if(adminConsoleRequestInFlight)return;
  adminConsoleRequestInFlight=true;
  try{
    const statsResult=await api(`/api/servers/${id}/stats`)
      .then(data=>({ok:true,data}))
      .catch(e=>({ok:false,error:e}));

    const s=allAdminServers.find(x=>x.id===id);
    if(statsResult.ok){
      const running=!!(statsResult.data?.stats?.running);
      if(s)s.running=running;
      updateAdminConsoleButtons(running);

      const status=document.getElementById('adminConsoleStatus');
      if(status){
        status.className=`badge ${running?'state-ok':''}`;
        status.textContent=running?'Online':'Offline';
      }
    }
    if(s)renderAdminServers();
  }catch(e){
    console.warn('Errore refresh console admin:',e);
  }finally{
    adminConsoleRequestInFlight=false;
  }
}
async function sendAdminCommand(id){const input=document.getElementById('adminConsoleCmd');if(!input?.value.trim())return;try{await api(`/api/servers/${id}/command`,{method:'POST',body:{command:input.value.trim()}});input.value='';await refreshAdminConsole(id);}catch(e){toast(e.message,'error');}}


async function initAdminFiles(){
  if(!allAdminServers.length) await loadAdminServers();
  const select=document.getElementById('fileServer');
  select.innerHTML=allAdminServers.length?allAdminServers.map(s=>`<option value="${s.id}">${escapeHtml(s.name)} — ${escapeHtml(s.ownerUsername)}</option>`).join(''):'<option value="">Nessun server</option>';
  if(currentFileServer && allAdminServers.some(s=>s.id===currentFileServer))select.value=currentFileServer; else currentFileServer=select.value||'';
  select.onchange=()=>{currentFileServer=select.value;currentFilePath='';closeAdminEditor();loadAdminFiles();};
  if(currentFileServer)loadAdminFiles();
}
function openFilesForServer(id){currentFileServer=id;currentFilePath='';adminServerPanelFilePath='';return openServerPanel(id,'files');}
async function loadAdminFiles(){
  if(!currentFileServer)return;
  try{
    const r=await api(`/api/admin/servers/${currentFileServer}/files?path=${encodeURIComponent(currentFilePath)}`);
    document.getElementById('filePath').textContent='/'+(r.path||'');
    const list=document.getElementById('filesList');

    list.innerHTML=r.files.length?r.files.map(f=>`
      <div class="admin-file-row">
        <span>${f.isDir?'📁':'📄'}</span>
        <div>
          <b>${escapeHtml(f.name)}</b>
          <div class="admin-muted">${f.isDir?'Cartella':adminFormatBytes(f.size)}</div>
        </div>

        <div class="admin-actions">
          <div class="action-menu">
            <button
              type="button"
              class="btn btn-sm btn-ghost action-menu-trigger"
              title="Azioni"
              aria-label="Azioni"
              onclick="event.stopPropagation();toggleActionMenu(this)"
            >⋮</button>

            <div class="action-menu-dropdown">
              ${f.isDir
                ? `<button type="button" onclick="event.stopPropagation();openAdminFolder('${encodeURIComponent(f.name)}')">Apri</button>`
                : ''
              }

              <button
                type="button"
                onclick="event.stopPropagation();renameAdminPath('${encodeURIComponent(f.name)}')"
              >Rinomina</button>

              ${!f.isDir
                ? `
                  <button type="button" onclick="event.stopPropagation();downloadAdminFile('${encodeURIComponent(f.path)}')">Scarica</button>
                  <button type="button" onclick="event.stopPropagation();editAdminFile('${encodeURIComponent(f.path)}')">Editor</button>
                `
                : ''
              }

              <button
                type="button"
                onclick="event.stopPropagation();deleteAdminPath('${encodeURIComponent(f.path)}',${f.isDir})"
              >Elimina</button>
            </div>
          </div>
        </div>
      </div>
    `).join(''):'<div class="admin-muted" style="padding:14px">Cartella vuota.</div>';
  }catch(e){
    toast(e.message,'error');
  }
}
function openAdminFolder(encoded){currentFilePath=currentFilePath?`${currentFilePath}/${decodeURIComponent(encoded)}`:decodeURIComponent(encoded);closeAdminEditor();loadAdminFiles();}
function fileUp(){if(!currentFilePath)return;const parts=currentFilePath.split('/');parts.pop();currentFilePath=parts.join('/');closeAdminEditor();loadAdminFiles();}
function trimEditorTrailingBlankLines(content){return String(content??'').replace(/[ \\t]+$/,'').replace(/(\\r?\\n[ \\t]*)+$/,'')}
function resizeAdminEditor(){const ta=document.getElementById('editorText');if(!ta)return;ta.style.minHeight='0px';ta.style.height='auto';const max=Math.max(120,Math.floor(window.innerHeight*.7));const h=Math.min(ta.scrollHeight,max);ta.style.height=h+'px';ta.style.overflowY=ta.scrollHeight>h?'auto':'hidden'}
document.getElementById('editorText')?.addEventListener('input',resizeAdminEditor);
window.addEventListener('resize',()=>{if(document.getElementById('editorText')?.value!==undefined)resizeAdminEditor()});
async function editAdminFile(encoded){const filePath=decodeURIComponent(encoded);try{const r=await api(`/api/admin/servers/${currentFileServer}/file?path=${encodeURIComponent(filePath)}`);currentEditorPath=filePath;document.getElementById('editorTitle').textContent=filePath;document.getElementById('editorText').value=trimEditorTrailingBlankLines(r.content||'');resizeAdminEditor();document.getElementById('editorText').focus();}catch(e){toast(e.message,'error');}}
function closeAdminEditor(){currentEditorPath='';const t=document.getElementById('editorText');if(t)t.value='';const h=document.getElementById('editorTitle');if(h)h.textContent='Editor';}
async function saveAdminEditor(){if(!currentEditorPath)return toast('Seleziona un file','error');try{await api(`/api/admin/servers/${currentFileServer}/file?path=${encodeURIComponent(currentEditorPath)}`,{method:'PUT',body:{content:document.getElementById('editorText').value}});toast('File salvato','success');loadAdminFiles();}catch(e){toast(e.message,'error');}}
function downloadAdminFile(encoded){window.location.href=`/api/admin/servers/${currentFileServer}/file?path=${encoded}&download=1`;}
async function createAdminFile(){const name=await qhPrompt({title:'Nuovo file',label:'Nome file',value:'index.js',submit:'Crea file',icon:'📄'});if(name===null)return;try{await api(`/api/admin/servers/${currentFileServer}/files/create`,{method:'POST',body:{path:currentFilePath,name,content:''}});loadAdminFiles();}catch(e){toast(e.message,'error');}}
async function createAdminFolder(){const name=await qhPrompt({title:'Nuova cartella',label:'Nome cartella',value:'src',submit:'Crea cartella',icon:'📁'});if(name===null)return;try{await api(`/api/admin/servers/${currentFileServer}/folders/create`,{method:'POST',body:{path:currentFilePath,name}});loadAdminFiles();}catch(e){toast(e.message,'error');}}
async function renameAdminPath(encodedName){const oldName=decodeURIComponent(encodedName||"");const newName=await qhPrompt({title:"Rinomina",label:"Nuovo nome",value:oldName,submit:"Rinomina"});if(newName===null||!String(newName).trim()||String(newName).trim()===oldName)return;try{await api("/api/admin/servers/"+currentFileServer+"/files/rename",{method:"POST",body:{path:currentFilePath,oldName:oldName,newName:String(newName).trim()}});toast("Elemento rinominato","success");loadAdminFiles();}catch(e){toast(e.message,"error");}}
async function deleteAdminPath(encoded,isDir){if(!await qhConfirm({icon:'🗑',title:isDir?'Eliminare cartella?':'Eliminare file?',description:'L’elemento verrà eliminato definitivamente.',submit:'Elimina'}))return;try{await api(`/api/admin/servers/${currentFileServer}/file?path=${encoded}`,{method:'DELETE'});if(currentEditorPath===decodeURIComponent(encoded))closeAdminEditor();loadAdminFiles();}catch(e){toast(e.message,'error');}}
document.getElementById('adminFileUpload').addEventListener('change',async e=>{const file=e.target.files[0];if(!file||!currentFileServer)return;const fd=new FormData();fd.append('file',file);try{await fetch(`/api/admin/servers/${currentFileServer}/upload?path=${encodeURIComponent(currentFilePath)}`,{method:'POST',body:fd,credentials:'same-origin'}).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Upload fallito');});toast('Upload completato','success');loadAdminFiles();}catch(err){toast(err.message,'error');}e.target.value='';});


async function loadAdminBackups(){try{const r=await api('/api/admin/backups');document.getElementById('backupsBody').innerHTML=r.backups.length?r.backups.map(b=>`<tr><td><b>${escapeHtml(b.filename)}</b></td><td>${escapeHtml(b.serverName)}</td><td>${escapeHtml(b.ownerUsername)}<br><span class="admin-muted">${escapeHtml(b.ownerEmail)}</span></td><td>${adminFormatBytes(b.size)}</td><td>${b.createdAt?new Date(b.createdAt).toLocaleString('it-IT'):'—'}</td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="downloadAdminBackup('${b.id}')">↓</button><button class="btn btn-sm btn-ghost" onclick="restoreAdminBackup('${b.id}')">Ripristina</button><button class="btn btn-sm btn-danger" onclick="deleteAdminBackup('${b.id}')">×</button></div></td></tr>`).join(''):'<tr><td colspan="6"><div class="empty">Nessun backup.</div></td></tr>';}catch(e){toast(e.message,'error');}}
async function createAdminBackup(){if(!allAdminServers.length)await loadAdminServers();const options=allAdminServers.map((s,i)=>`${i+1}. ${s.name} — ${s.ownerUsername}`).join('\n');const v=await qhPrompt({title:'Crea backup',description:options,label:'Numero server',value:'1',submit:'Crea backup',icon:'💾'});if(v===null)return;const s=allAdminServers[Number(v)-1];if(!s)return toast('Server non valido','error');try{const result=await api('/api/admin/backups',{method:'POST',body:{serverId:s.id}});if(result?.pending&&result.jobId){toast('Backup avviato sul nodo predefinito','success');pollAdminBackupJob(result.jobId)}else{toast('Backup creato','success');loadAdminBackups()}}catch(e){toast(e.message,'error')}}
async function pollAdminBackupJob(jobId){for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,2000));try{const st=await api(`/api/admin/backups/jobs/${jobId}`);if(st.state==='completed'){toast('Backup completato','success');await loadAdminBackups();return}if(st.state==='error'){toast(st.error||'Creazione backup fallita','error');return}}catch(_){}}toast('Il backup è ancora in lavorazione','info')}
function downloadAdminBackup(id){window.location.href=`/api/admin/backups/${id}/download`;}
async function restoreAdminBackup(id){if(!await qhConfirm({icon:'♻️',title:'Ripristinare backup?',description:'Il contenuto attuale del server verrà sostituito.',submit:'Ripristina',danger:false}))return;try{const result=await api(`/api/admin/backups/${id}`,{method:'POST',body:{action:'restore'}});if(result?.pending)pollAdminRestoreJob(result.jobId);else{toast('Backup ripristinato','success');loadAdminServers()}}catch(e){toast(e.message,'error')}}
async function pollAdminRestoreJob(jobId){for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,2000));try{const st=await api(`/api/admin/backups/jobs/${jobId}`);if(st.state==='completed'){toast('Backup ripristinato','success');await loadAdminServers();return}if(st.state==='error'){toast(st.error||'Ripristino fallito','error');return}}catch(_){}}toast('Il ripristino è ancora in lavorazione','info')}
async function deleteAdminBackup(id){if(!await qhConfirm({icon:'🗑',title:'Eliminare backup?',description:'Il file verrà cancellato definitivamente.',submit:'Elimina'}))return;try{await api(`/api/admin/backups/${id}`,{method:'DELETE'});toast('Backup eliminato','success');loadAdminBackups();}catch(e){toast(e.message,'error');}}



async function loadAdminNodes() {
  try {
    const r = await api('/api/admin/nodes');
    allAdminNodes = Array.isArray(r.nodes) ? r.nodes : [];
    const body = $id('nodesBody');
    if (!body) return;
    body.innerHTML = allAdminNodes.length ? allAdminNodes.map(n => {
      const status = n.online
        ? '<span class="badge state-ok">Online</span>'
        : '<span class="badge state-bad">Offline</span>';
      const users = Array.isArray(n.assignedUsers) ? n.assignedUsers : [];
      const defaultBadge = n.isDefault ? ' <span class="badge state-ok" title="I nuovi utenti vengono assegnati qui">Predefinito</span>' : '';
      return `<tr>
        <td><b>${escapeHtml(n.name)}</b>${defaultBadge}<br><span class="admin-muted">${escapeHtml(n.id)}</span></td>
        <td>${escapeHtml(n.host)}:${n.port}</td>
        <td>${escapeHtml(n.username)}<br><span class="admin-muted">${escapeHtml(n.keyPath || 'Chiave non configurata')}</span></td>
        <td>${status}${n.lastCheckAt ? `<br><span class="admin-muted">${new Date(n.lastCheckAt).toLocaleString('it-IT')}</span>` : ''}</td>
        <td>${users.length}${users.length ? `<br><span class="admin-muted">${escapeHtml(users.slice(0,3).map(u=>u.username).join(', '))}${users.length>3?'…':''}</span>` : ''}</td>
        <td>${Number(n.serverCount || 0)}</td>
        <td><div class="admin-actions">
          <button class="btn btn-sm btn-ghost" onclick="testAdminNode('${n.id}')">Test</button>
          <button class="btn btn-sm btn-ghost" onclick="manageAdminNodeUsers('${n.id}')">Utenti</button>
          ${n.isDefault ? '' : `<button class="btn btn-sm btn-ghost" onclick="setDefaultAdminNode('${n.id}')" title="I nuovi registrati finiscono su questo nodo">Predefinito</button>`}
          <button class="btn btn-sm btn-ghost" onclick="editAdminNode('${n.id}')">Modifica</button>
          <button class="btn btn-sm btn-danger" onclick="deleteAdminNode('${n.id}')">Elimina</button>
        </div></td>
      </tr>`;
    }).join('') : '<tr><td colspan="7"><div class="empty">Nessun nodo configurato.</div></td></tr>';
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function createAdminNode() {
  showModal(`<div class="modal-head"><div><div class="modal-icon">🖥️</div><div class="eyebrow">Nodi</div><h2>Aggiungi VPS</h2><p class="modal-desc">Il pannello userà SSH per verificare automaticamente il collegamento al nodo.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>
    <form id="createNodeForm" class="modal-form">
      <label>Nome nodo<input id="nodeName" placeholder="Nodo 1" required></label>
      <div class="field-row"><label>Indirizzo IP / Host<input id="nodeHost" placeholder="203.0.113.10" required></label><label>Porta SSH<input id="nodePort" type="number" min="1" max="65535" value="22" required></label></div>
      <div class="field-row"><label>Utente SSH<input id="nodeUser" value="ubuntu" required></label><label>Chiave privata<input id="nodeKeyPath" placeholder="/home/ubuntu/.ssh/id_ed25519" required></label></div>
      <label>Descrizione <span class="admin-muted">(facoltativa)</span><input id="nodeDescription" placeholder="VPS principale"></label>
      <div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva e testa</button></div>
    </form>`);
  $id('createNodeForm').onsubmit = async e => {
    e.preventDefault();
    try {
      await api('/api/admin/nodes', { method:'POST', body:{
        name:$id('nodeName').value.trim(), host:$id('nodeHost').value.trim(), port:Number($id('nodePort').value), username:$id('nodeUser').value.trim(), keyPath:$id('nodeKeyPath').value.trim(), description:$id('nodeDescription').value.trim()
      }});
      closeModal(); toast('Nodo aggiunto', 'success'); loadAdminNodes();
    } catch (err) { toast(err.message, 'error'); }
  };
}

async function testAdminNode(id) {
  try {
    const r = await api(`/api/admin/nodes/${id}/test`, { method:'POST', timeoutMs:8000 });
    toast(r.pending ? 'Test SSH avviato in background' : (r.message || 'Connessione SSH riuscita'), 'success');
    loadAdminNodes();
    
    setTimeout(() => loadAdminNodes(), 1500);
    setTimeout(() => loadAdminNodes(), 5000);
  } catch (e) { toast(e.message, 'error'); loadAdminNodes(); }
}

async function setDefaultAdminNode(id) {
  try {
    await api(`/api/admin/nodes/${id}`, { method: 'PATCH', body: { isDefault: true } });
    toast('Nodo impostato come predefinito: i nuovi utenti verranno assegnati qui', 'success');
    loadAdminNodes();
  } catch (e) { toast(e.message, 'error'); }
}

async function editAdminNode(id) {
  const n = allAdminNodes.find(x => x.id === id);
  if (!n) return;
  showModal(`<div class="modal-head"><div><div class="modal-icon">🖥️</div><div class="eyebrow">Nodo</div><h2>Modifica ${escapeHtml(n.name)}</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div>
    <form id="editNodeForm" class="modal-form">
      <label>Nome nodo<input id="enName" value="${escapeHtml(n.name)}" required></label>
      <div class="field-row"><label>Indirizzo IP / Host<input id="enHost" value="${escapeHtml(n.host)}" required></label><label>Porta SSH<input id="enPort" type="number" min="1" max="65535" value="${Number(n.port)||22}" required></label></div>
      <div class="field-row"><label>Utente SSH<input id="enUser" value="${escapeHtml(n.username)}" required></label><label>Chiave privata<input id="enKeyPath" value="${escapeHtml(n.keyPath||'')}" required></label></div>
      <label>Descrizione<input id="enDescription" value="${escapeHtml(n.description||'')}"></label>
      <div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva</button></div>
    </form>`);
  $id('editNodeForm').onsubmit = async e => {
    e.preventDefault();
    try {
      await api(`/api/admin/nodes/${id}`, { method:'PATCH', body:{name:$id('enName').value.trim(),host:$id('enHost').value.trim(),port:Number($id('enPort').value),username:$id('enUser').value.trim(),keyPath:$id('enKeyPath').value.trim(),description:$id('enDescription').value.trim()} });
      closeModal(); toast('Nodo aggiornato', 'success'); loadAdminNodes();
    } catch (err) { toast(err.message, 'error'); }
  };
}

async function manageAdminNodeUsers(id) {
  if (!allUsers.length) await loadAdminUsers();
  const n = allAdminNodes.find(x => x.id === id);
  if (!n) return;
  const assigned = new Set(Array.isArray(n.userIds) ? n.userIds : []);
  showModal(`<div class="modal-head"><div><div class="modal-icon">👥</div><div class="eyebrow">Nodo</div><h2>Utenti autorizzati</h2><p class="modal-desc">Spostando un utente su questo nodo vengono migrati automaticamente anche i suoi server e i relativi file.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>
    <form id="nodeUsersForm" class="modal-form">
      <div style="display:grid;gap:8px;max-height:420px;overflow:auto">${allUsers.map(u => `<label style="display:flex;align-items:center;gap:10px"><input type="checkbox" name="nodeUser" value="${escapeHtml(u.id)}" ${assigned.has(u.id)?'checked':''}> <span><b>${escapeHtml(u.username)}</b><br><span class="admin-muted">${escapeHtml(u.email||'')}</span></span></label>`).join('')}</div>
      <div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva utenti</button></div>
    </form>`);
  $id('nodeUsersForm').onsubmit = async e => {
    e.preventDefault();
    const userIds = [...document.querySelectorAll('#nodeUsersForm input[name="nodeUser"]:checked')].map(x => x.value);
    try { await api(`/api/admin/nodes/${id}/users`, {method:'PATCH', body:{userIds}}); closeModal(); toast('Utenti e server del nodo aggiornati (la migrazione dei file può continuare in background)','success'); loadAdminNodes(); }
    catch (err) { toast(err.message,'error'); }
  };
}

async function deleteAdminNode(id) {
  if (!await qhConfirm({icon:'🗑',title:'Eliminare nodo?',description:'Il nodo verrà eliminato subito. Se esiste un altro nodo, utenti e server verranno trasferiti lì mantenendo i rispettivi proprietari/email; i file verranno copiati in background.',submit:'Elimina subito',danger:true})) return;
  try {
    const r = await api(`/api/admin/nodes/${id}?force=true`, {method:'DELETE', timeoutMs:8000});
    toast(r.movedServers ? `Nodo eliminato · ${r.movedServers} server trasferiti a ${r.targetNodeName || 'altro nodo'}` : 'Nodo eliminato', 'success');
    loadAdminNodes();
  } catch (e) { toast(e.message,'error'); }
}

async function loadAdminDatabases(){try{const r=await api('/api/admin/databases');document.getElementById('databasesBody').innerHTML=r.databases.length?r.databases.map(d=>`<tr><td><b>${escapeHtml(d.name)}</b></td><td>${escapeHtml(d.type||'MySQL 8.0')}</td><td>${escapeHtml(d.username||'—')}</td><td>${escapeHtml(d.ownerUsername)}<br><span class="admin-muted">${escapeHtml(d.ownerEmail)}</span></td><td>${Number(d.sizeMB||0)} MB</td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="renameAdminDatabase('${d.id}','${escapeHtml(d.name)}')">Modifica</button><button class="btn btn-sm btn-danger" onclick="deleteAdminDatabase('${d.id}')">Elimina</button></div></td></tr>`).join(''):'<tr><td colspan="6"><div class="empty">Nessun database.</div></td></tr>';}catch(e){toast(e.message,'error');}}
async function createAdminDatabase(){if(!allUsers.length)await loadAdminUsers();const options=allUsers.map((u,i)=>`${i+1}. ${u.username} — ${u.email}`).join('\n');const owner=await qhPrompt({title:'Nuovo database',description:options,label:'Numero utente',value:'1',submit:'Continua',icon:'🗄️'});if(owner===null)return;const u=allUsers[Number(owner)-1];if(!u)return toast('Utente non valido','error');const name=await qhPrompt({title:'Nome database',label:'Nome',value:'database',submit:'Crea',icon:'🗄️'});if(name===null)return;try{await api('/api/admin/databases',{method:'POST',body:{ownerId:u.id,name}});toast('Database creato','success');loadAdminDatabases();}catch(e){toast(e.message,'error');}}
async function renameAdminDatabase(id,current){const name=await qhPrompt({title:'Rinomina database',label:'Nome',value:current,submit:'Salva',icon:'🗄️'});if(name===null)return;try{await api(`/api/admin/databases/${id}`,{method:'PATCH',body:{name}});toast('Database aggiornato','success');loadAdminDatabases();}catch(e){toast(e.message,'error');}}
async function deleteAdminDatabase(id){if(!await qhConfirm({icon:'🗑',title:'Eliminare database?',submit:'Elimina'}))return;try{await api(`/api/admin/databases/${id}`,{method:'DELETE'});toast('Database eliminato','success');loadAdminDatabases();}catch(e){toast(e.message,'error');}}


async function loadAdminNetwork(){try{const r=await api('/api/admin/network');document.getElementById('networkBody').innerHTML=r.network.length?r.network.map(n=>`<tr><td><b>${n.port}</b></td><td>${escapeHtml(n.protocol)}</td><td>${escapeHtml(n.service||'Custom')}</td><td>${escapeHtml(n.ownerUsername)}<br><span class="admin-muted">${escapeHtml(n.ownerEmail)}</span></td><td>${n.enabled?'<span class="badge state-ok">Attiva</span>':'<span class="badge">Disattiva</span>'}</td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="toggleAdminNetwork('${n.id}',${!n.enabled})">${n.enabled?'Disattiva':'Attiva'}</button><button class="btn btn-sm btn-ghost" onclick="editAdminNetwork('${n.id}',${n.port},'${escapeHtml(n.protocol)}','${escapeHtml(n.service||'Custom')}')">Modifica</button><button class="btn btn-sm btn-danger" onclick="deleteAdminNetwork('${n.id}')">×</button></div></td></tr>`).join(''):'<tr><td colspan="6"><div class="empty">Nessuna regola.</div></td></tr>';}catch(e){toast(e.message,'error');}}
async function createAdminNetwork(){if(!allUsers.length)await loadAdminUsers();const options=allUsers.map((u,i)=>`${i+1}. ${u.username}`).join('\n');const owner=await qhPrompt({title:'Nuova regola network',description:options,label:'Numero utente',value:'1',submit:'Continua',icon:'🌐'});if(owner===null)return;const u=allUsers[Number(owner)-1];if(!u)return toast('Utente non valido','error');showModal(`<div class="modal-head"><div><div class="modal-icon">🌐</div><div class="eyebrow">Network</div><h2>Nuova regola</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="netForm" class="modal-form"><label>Porta<input id="netPort" type="number" min="1" max="65535" required></label><div class="field-row"><label>Protocollo<select id="netProtocol"><option>TCP</option><option>UDP</option></select></label><label>Servizio<input id="netService" value="Custom"></label></div><div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Crea per ${escapeHtml(u.username)}</button></div></form>`);document.getElementById('netForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/admin/network',{method:'POST',body:{ownerId:u.id,port:Number($id('netPort').value),protocol:$id('netProtocol').value,service:$id('netService').value}});closeModal();toast('Regola creata','success');loadAdminNetwork();}catch(err){toast(err.message,'error');}};}
async function toggleAdminNetwork(id,enabled){try{await api(`/api/admin/network/${id}`,{method:'PATCH',body:{enabled}});loadAdminNetwork();}catch(e){toast(e.message,'error');}}
async function editAdminNetwork(id,port,protocol,service){showModal(`<div class="modal-head"><div><div class="modal-icon">🌐</div><div class="eyebrow">Network</div><h2>Modifica regola</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="editNetForm" class="modal-form"><label>Porta<input id="enPort" type="number" min="1" max="65535" value="${port}"></label><div class="field-row"><label>Protocollo<select id="enProtocol"><option ${protocol==='TCP'?'selected':''}>TCP</option><option ${protocol==='UDP'?'selected':''}>UDP</option></select></label><label>Servizio<input id="enService" value="${service}"></label></div><div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva</button></div></form>`);document.getElementById('editNetForm').onsubmit=async e=>{e.preventDefault();try{await api(`/api/admin/network/${id}`,{method:'PATCH',body:{port:Number($id('enPort').value),protocol:$id('enProtocol').value,service:$id('enService').value}});closeModal();loadAdminNetwork();}catch(err){toast(err.message,'error');}};}
async function deleteAdminNetwork(id){if(!await qhConfirm({icon:'🗑',title:'Eliminare regola?',submit:'Elimina'}))return;try{await api(`/api/admin/network/${id}`,{method:'DELETE'});loadAdminNetwork();}catch(e){toast(e.message,'error');}}


function renderAdminEmailUsers() {
  const select = $id('adminEmailRecipient');
  if (!select) return;
  if (!adminEmailUsers.length) {
    select.innerHTML = '<option value="">Nessun utente con email disponibile</option>';
    return;
  }
  select.innerHTML = '<option value="">Seleziona un destinatario...</option>' + adminEmailUsers.map(u =>
    `<option value="${escapeHtml(u.id)}">${escapeHtml(u.username)} — ${escapeHtml(u.email)}${u.suspended ? ' — Sospeso' : ''}</option>`
  ).join('');
}

async function loadAdminEmailUsers() {
  try {
    const r = await api('/api/admin/email-users');
    adminEmailUsers = Array.isArray(r.users) ? r.users : [];
    renderAdminEmailUsers();
  } catch (e) {
    toast(e.message || 'Impossibile caricare gli utenti', 'error');
  }
}

function updateAdminEmailPreview() {
  const subject = $id('adminEmailSubject')?.value.trim() || 'Titolo dell\'email';
  const message = $id('adminEmailMessage')?.value || 'Il messaggio che scrivi comparirà qui.';
  const subjectEl = $id('adminEmailPreviewSubject');
  const messageEl = $id('adminEmailPreviewMessage');
  if (subjectEl) subjectEl.textContent = subject;
  if (messageEl) messageEl.textContent = message;
}

async function sendAdminEmail(e) {
  e.preventDefault();
  const recipient = $id('adminEmailRecipient').value;
  const subject = $id('adminEmailSubject').value.trim();
  const message = $id('adminEmailMessage').value.trim();
  if (!recipient) return toast('Seleziona un destinatario', 'error');
  if (!subject) return toast('Inserisci il titolo dell\'email', 'error');
  if (!message) return toast('Inserisci il messaggio dell\'email', 'error');
  const btn = $id('adminEmailSendBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Invio...'; }
  try {
    const r = await api('/api/admin/email', { method:'POST', body:{userId:recipient, subject, message} });
    toast(`Email inviata a ${r.recipient?.email || 'utente'}`, 'success');
    $id('adminEmailSubject').value = '';
    $id('adminEmailMessage').value = '';
    updateAdminEmailPreview();
  } catch (err) {
    toast(err.message || 'Invio email fallito', 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Invia email'; }
  }
}

function initAdminEmail() {
  const form = $id('adminEmailForm');
  if (!form || form.dataset.bound === '1') return;
  form.dataset.bound = '1';
  form.addEventListener('submit', sendAdminEmail);
  $id('adminEmailSubject')?.addEventListener('input', updateAdminEmailPreview);
  $id('adminEmailMessage')?.addEventListener('input', updateAdminEmailPreview);
  updateAdminEmailPreview();
}


async function loadAdminTickets(){try{const r=await api('/api/admin/tickets');adminTickets=r.tickets||[];document.getElementById('ticketsBody').innerHTML=adminTickets.length?adminTickets.map(t=>`<tr><td>#${t.number||'—'}</td><td>${escapeHtml(t.ownerUsername)}</td><td>${escapeHtml(t.ownerEmail)}</td><td><b>${escapeHtml(t.subject)}</b></td><td>${escapeHtml(t.category||'—')}</td><td><span class="badge">${escapeHtml(t.status||'open')}</span></td><td>${t.updatedAt?new Date(t.updatedAt).toLocaleString('it-IT'):'—'}</td><td><button class="btn btn-sm btn-ghost" onclick="openAdminTicket('${t.id}')">Apri</button></td></tr>`).join(''):'<tr><td colspan="8"><div class="empty">Nessun ticket.</div></td></tr>';}catch(e){toast(e.message,'error');}}
function openAdminTicket(id){const t=adminTickets.find(x=>x.id===id);if(!t)return;const messages=(t.messages||[]).map(m=>`<div class="ticket-message"><b>${escapeHtml(m.author||'—')}</b> <span class="admin-muted">${escapeHtml(m.role||'')}</span><div style="margin-top:5px">${escapeHtml(m.content||'')}</div><div class="admin-muted" style="margin-top:5px">${m.createdAt?new Date(m.createdAt).toLocaleString('it-IT'):''}</div></div>`).join('');const detail=document.getElementById('ticketDetail');detail.classList.remove('hidden');detail.innerHTML=`<div class="panel-title"><h2>Ticket #${t.number||'—'} — ${escapeHtml(t.subject)}</h2><button class="btn btn-sm btn-ghost" onclick="document.getElementById('ticketDetail').classList.add('hidden')">Chiudi</button></div><div class="admin-muted">${escapeHtml(t.ownerUsername)} · ${escapeHtml(t.ownerEmail)} · ${escapeHtml(t.category||'')}</div><div style="margin-top:12px">${messages||'<div class="admin-muted">Nessun messaggio.</div>'}</div><div class="field-row" style="margin-top:12px"><label>Stato<select id="ticketStatus"><option value="open" ${t.status==='open'?'selected':''}>Aperto</option><option value="pending" ${t.status==='pending'?'selected':''}>In attesa</option><option value="closed" ${t.status==='closed'?'selected':''}>Chiuso</option></select></label><label>Risposta<textarea id="ticketReply" rows="3" placeholder="Scrivi una risposta all'utente..."></textarea></label></div><div class="modal-actions"><button class="btn btn-gradient" onclick="saveAdminTicket('${t.id}')">Salva / Rispondi</button></div>`;detail.scrollIntoView({behavior:'smooth',block:'start'});}
async function saveAdminTicket(id){try{const message=document.getElementById('ticketReply').value.trim();const status=document.getElementById('ticketStatus').value;await api(`/api/admin/tickets/${id}`,{method:'PATCH',body:{status,message}});toast('Ticket aggiornato','success');await loadAdminTickets();openAdminTicket(id);}catch(e){toast(e.message,'error');}}


async function loadBilling(){try{const r=await api('/api/admin/billing');document.getElementById('adminSlotCost').textContent=r.settings.slotCreditCost;document.getElementById('adminSlotInput').value=r.settings.slotCreditCost;document.getElementById('adminPackageCount').textContent=r.packages.length;document.getElementById('adminTransactionCount').textContent=r.transactions.length;document.getElementById('billingPackagesBody').innerHTML=r.packages.length?r.packages.map(p=>`<tr><td><b>${escapeHtml(p.label)}</b></td><td>${p.credits}</td><td>€ ${(p.amountCents/100).toFixed(2)}</td><td><span class="subtle">${escapeHtml(p.id)}</span></td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="editBillingPackage('${p.id}',${JSON.stringify(p.label)},${p.credits},${p.amountCents})">Modifica</button><button class="btn btn-sm btn-danger" onclick="deleteBillingPackage('${p.id}')">Elimina</button></div></td></tr>`).join(''):'<tr><td colspan="5"><div class="empty">Nessun piano</div></td></tr>';document.getElementById('billingCouponsBody').innerHTML=r.coupons.length?r.coupons.map(c=>`<tr><td><b>${escapeHtml(c.code)}</b></td><td>${c.type==='slots'?'Slot':'Crediti'}</td><td>${c.amount}</td><td>${c.usedCount}/${c.maxUses}</td><td>${c.enabled?'<span class="badge badge-success">Attivo</span>':'<span class="badge badge-muted">Disattivo</span>'}</td><td><div class="admin-actions"><button class="btn btn-sm btn-ghost" onclick="toggleBillingCoupon('${c.id}',${!c.enabled})">${c.enabled?'Disattiva':'Attiva'}</button><button class="btn btn-sm btn-danger" onclick="deleteBillingCoupon('${c.id}')">Elimina</button></div></td></tr>`).join(''):'<tr><td colspan="6"><div class="empty">Nessun coupon</div></td></tr>';}catch(e){toast(e.message,'error');}}
async function createBillingCoupon(){const code=document.getElementById('couponCode').value.trim().toUpperCase(),type=document.getElementById('couponType').value,amount=Number(document.getElementById('couponAmount').value),maxUses=Number(document.getElementById('couponMaxUses').value);if(!code||!amount||!maxUses)return toast('Compila tutti i campi','error');try{await api('/api/admin/billing/coupons',{method:'POST',body:{code,type,amount,maxUses}});document.getElementById('couponCode').value='';document.getElementById('couponAmount').value='';document.getElementById('couponMaxUses').value='1';toast('Coupon creato','success');loadBilling();}catch(e){toast(e.message,'error');}}
async function toggleBillingCoupon(id,enabled){try{await api(`/api/admin/billing/coupons/${id}`,{method:'PATCH',body:{enabled}});toast(enabled?'Coupon attivato':'Coupon disattivato','success');loadBilling();}catch(e){toast(e.message,'error');}}
async function deleteBillingCoupon(id){if(!await qhConfirm({icon:'🗑',title:'Eliminare coupon?',description:'Il coupon non sarà più utilizzabile.',submit:'Elimina'}))return;try{await api(`/api/admin/billing/coupons/${id}`,{method:'DELETE'});toast('Coupon eliminato','success');loadBilling();}catch(e){toast(e.message,'error');}}
async function saveBillingSettings(){try{await api('/api/admin/billing/settings',{method:'PATCH',body:{slotCreditCost:Number(document.getElementById('adminSlotInput').value)}});toast('Configurazione salvata','success');loadBilling();}catch(e){toast(e.message,'error');}}
async function createBillingPackage(){const label=document.getElementById('planLabel').value.trim(),credits=Number(document.getElementById('planCredits').value),price=Number(document.getElementById('planPrice').value);if(!label||!credits||!price)return toast('Compila tutti i campi','error');try{await api('/api/admin/billing/packages',{method:'POST',body:{label,credits,amountCents:Math.round(price*100)}});document.getElementById('planLabel').value='';document.getElementById('planCredits').value='';document.getElementById('planPrice').value='';toast('Piano creato','success');loadBilling();}catch(e){toast(e.message,'error');}}
async function editBillingPackage(id,label,credits,amountCents){showModal(`<div class="modal-head"><div><div class="modal-icon">€</div><div class="eyebrow">Billing</div><h2>Modifica piano</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="editPlanForm" class="modal-form"><label>Nome<input id="bpLabel" value="${escapeHtml(label)}"></label><label>Crediti<input id="bpCredits" type="number" min="1" value="${credits}"></label><label>Prezzo EUR<input id="bpPrice" type="number" min="0.50" step="0.01" value="${(amountCents/100).toFixed(2)}"></label><div class="modal-actions"><button type="button" class="btn btn-outline" onclick="closeModal()">Annulla</button><button class="btn btn-gradient">Salva</button></div></form>`);document.getElementById('editPlanForm').onsubmit=async e=>{e.preventDefault();try{await api(`/api/admin/billing/packages/${id}`,{method:'PATCH',body:{label:$id('bpLabel').value,credits:Number($id('bpCredits').value),amountCents:Math.round(Number($id('bpPrice').value)*100)}});closeModal();toast('Piano aggiornato','success');loadBilling();}catch(err){toast(err.message,'error');}};}
async function deleteBillingPackage(id){if(!await qhConfirm({icon:'🗑',title:'Eliminare piano?',description:'Il piano non sarà più disponibile per nuovi acquisti.',submit:'Elimina'}))return;try{await api(`/api/admin/billing/packages/${id}`,{method:'DELETE'});toast('Piano eliminato','success');loadBilling();}catch(e){toast(e.message,'error');}}

let adminInitialized = false;

async function initAdminPage() {
  if (adminInitialized) return;
  adminInitialized = true;

  currentUser = await requireAuth('admin');
  if (!currentUser) {
    adminInitialized = false;
    return;
  }

  $id('sideName').textContent = currentUser.username;
  $id('avatar').textContent = initials(currentUser.username);
  $id('sideRole').textContent = t('common.admin');

  const saved=(location.hash||'').slice(1).toLowerCase() || (()=>{try{return localStorage.getItem('qh_admin_view')||''}catch(_){return ''}})();
  const initialView=ADMIN_VIEWS.find(v=>v.toLowerCase()===saved)||'Overview';
  try { localStorage.setItem('qh_admin_view', initialView.toLowerCase()); } catch (_) {}

  
  
  
  switchView(initialView);
  startStatsPolling();
  startStatsFastRetry();
  watchOverviewActivation();

  if (initialView === 'Overview') {
    await loadStats({silent:true});
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAdminPage, {once:true});
} else {
  initAdminPage();
}

window.addEventListener('hashchange', () => {
  const saved=(location.hash||'').slice(1).toLowerCase();
  const view=ADMIN_VIEWS.find(v=>v.toLowerCase()===saved)||'Overview';
  switchView(view);
  if (view === 'Overview') loadStats({silent:false});
});
