try{const savedTheme=localStorage.getItem('qh_theme');if(savedTheme==='dark')document.body.classList.add('theme-dark')}catch(_){}
let me=null, currentServer=null, editorFile=null, serverMonitorTimer=null, serverMonitorGeneration=0, overviewRequestInFlight=false, overviewRetryTimer=null;
let userServerPanelFilePath='';
let userServerPanelEditorPath='';
const FormatBytes = window.FormatBytes || window.formatBytes || (bytes => `${Number(bytes)||0} B`);
const $=id=>document.getElementById(id);
const esc=escapeHtml;
const normalizeTesterConsoleLine=line=>String(line??'').replace(/\x1b\[[0-?]*[ -\/]*[@-~]/g,'').replace(/^\s*[A-Za-z0-9._-]+@[^:#>$\s]+(?::[^#>$]*)?[#>$]\s*/,'');


document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button || button.disabled) return;
  if (button.dataset.adminView || button.dataset.view || button.dataset.viewJump) return;
  const raw = (button.innerText || button.getAttribute('aria-label') || button.title || '').replace(/\s+/g, ' ').trim();
  if (!raw || raw === '×' || raw === '⌄') return;
  if (/^(avvia|arresta|ferma|riavvia|acquista|crea backup|elimina backup|ripristina)$/i.test(raw)) return;
  fetch('/api/audit/movement', {method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin', body:JSON.stringify({action:`Pulsante: ${raw.slice(0,140)}`})}).catch(()=>{});
});

const locale=()=>typeof getLang==='function'&&getLang()==='en'?'en-US':'it-IT';
const formatToday=()=>new Intl.DateTimeFormat(locale(),{weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(new Date());
const updateToday=()=>{const el=$('today');if(el)el.textContent=formatToday()};
const fmtDate=ts=>new Date(ts||Date.now()).toLocaleString(locale(),{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
document.addEventListener('qh:langchange',updateToday);
const isStaff=()=>me?.role==='staff';
async function jump(view){
  const loaders={dashboard:loadOverview,servers:loadServers,files:loadFiles,databases:loadDatabases,backups:loadBackups,network:loadNetwork,subusers:loadSubusers,billing:loadBilling,settings:loadSettings,support:loadTickets};
  if(!loaders[view])view='dashboard';
  if(location.hash!==`#${view}`)history.replaceState(null,'',`#${view}`);
  try{localStorage.setItem('qh_user_view',view)}catch(_){}
  fetch('/api/audit/movement',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action:`Apertura sezione ${view}`})}).catch(()=>{});
  if(view!=='servers')stopServerMonitor();
  document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===`view-${view}`));
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.view===view));
  document.querySelector('.sidebar')?.classList.remove('open');
  try{
    
    
    if(view==='files'&&(!$('fileServer')?.value||!currentServer))void loadServers({silent:true}).catch(()=>{});
    if(view==='dashboard')void loadOverview({silent:false});
    else void loaders[view]?.().catch?.(e=>{ if(e?.message) toast2(e.message,'error'); });
    if(typeof translateDashboardLiterals==='function')translateDashboardLiterals(document);
  }catch(e){toast2(e.message||'Impossibile caricare la sezione','error');}
}
document.querySelectorAll('.nav-item').forEach(b=>b.onclick=()=>jump(b.dataset.view));document.querySelectorAll('[data-view-jump]').forEach(b=>b.onclick=()=>jump(b.dataset.viewJump));
const menuBtn=$('menuBtn');const sidebar=$('sidebar');let drawerBackdrop=document.querySelector('.drawer-backdrop');if(!drawerBackdrop){drawerBackdrop=document.createElement('div');drawerBackdrop.className='drawer-backdrop';document.body.appendChild(drawerBackdrop)}function closeMobileMenu(){sidebar?.classList.remove('open');drawerBackdrop?.classList.remove('open');drawerBackdrop?.style.removeProperty('display');document.body.classList.remove('drawer-open')}function openMobileMenu(){sidebar?.classList.add('open');drawerBackdrop?.classList.add('open');if(drawerBackdrop)drawerBackdrop.style.display='block';document.body.classList.add('drawer-open')}if(menuBtn){menuBtn.onclick=e=>{e.preventDefault();e.stopPropagation();sidebar?.classList.contains('open')?closeMobileMenu():openMobileMenu()}}if(drawerBackdrop){drawerBackdrop.onclick=e=>{if(e.target===drawerBackdrop)closeMobileMenu()}}document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMobileMenu()});
function stopServerMonitor(){serverMonitorGeneration++;if(serverMonitorTimer){clearInterval(serverMonitorTimer);serverMonitorTimer=null}}
function startServerMonitor(id){
  stopServerMonitor();
  refreshServerMonitor(id).catch(()=>{});
  serverMonitorTimer=setInterval(()=>{
    if(currentServer!==id || !document.getElementById('consoleOut')){stopServerMonitor();return;}
    refreshServerMonitor(id).catch(()=>{});
  },1000);
}
function modal(html){stopServerMonitor();$('modal').innerHTML=html;$('modalBackdrop').classList.remove('hidden')};function closeModal(){stopServerMonitor();$('modalBackdrop').classList.add('hidden');$('modal').innerHTML=''};$('modalBackdrop').onclick=e=>{if(e.target.id==='modalBackdrop')closeModal()};
function toast2(msg,type='default'){const translated=typeof qhTranslateText==='function'?qhTranslateText(msg):msg;const e=document.createElement('div');e.className=`toast ${type}`;e.textContent=translated;$('toasts').appendChild(e);setTimeout(()=>e.remove(),3500)}
function applyOverviewStats(r){
  const servers=Number(r?.servers)||0;
  const running=Number(r?.running)||0;
  const cpu=Number(r?.cpuCores)||0;
  const ram=Number(r?.ramMB)||0;
  const disk=1024;
  $('sServers').textContent=servers;
  $('sOnline').textContent=running;
  $('sCpu').textContent=`${cpu.toFixed(1)} CPU`;
  $('sRam').textContent=`${Math.round(ram)} MB`;
  $('sDisk').textContent='1 GB';
  $('ringCpu').textContent=`${cpu.toFixed(1)} CPU`;
  $('barCpuText').textContent=`${cpu.toFixed(1)} CPU`;
  $('barCpu').style.width=`${Math.min(100,(cpu/1)*100)}%`;
  $('barRamText').textContent=`${Math.min(100,Math.round((ram/4096)*100)||0)}%`;
  $('barRam').style.width=`${Math.min(100,Math.round((ram/4096)*100)||0)}%`;
  $('barDiskText').textContent=`${Math.min(100,Math.round((disk/51200)*100)||0)}%`;
  $('barDisk').style.width=`${Math.min(100,Math.round((disk/51200)*100)||0)}%`;
  $('activity').innerHTML=r?.recent?.length?r.recent.map(x=>`<div class="activity"><span class="activity-icon">▣</span><div><b>Server "${esc(x.name)}"</b><small>${x.running?'Online':'Offline'} · ${timeAgo(x.createdAt)}</small></div></div>`).join(''):'<div class="empty">Nessuna attività recente.</div>';
}
function applyServersFallback(list){
  const servers=Array.isArray(list)?list:[];
  const running=servers.filter(s=>s.running||s.status==='running').length;
  const cpu=servers.reduce((a,s)=>a+Number(s.cpuCores||0.5),0);
  const ram=servers.reduce((a,s)=>a+Number(s.ramMB||0),0);
  applyOverviewStats({servers:servers.length,running,cpuCores:cpu,ramMB:ram,diskMB:1024,recent:servers.map(s=>({name:s.name,running:Boolean(s.running||s.status==='running'),createdAt:s.createdAt})).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).slice(0,5)});
}
async function loadOverview({silent=false}={}){
  if(overviewRequestInFlight)return;
  overviewRequestInFlight=true;
  try{
    const r=await api('/api/panel/overview');
    applyOverviewStats(r);
    clearTimeout(overviewRetryTimer);
  }catch(e){
    if(!silent)toast2(e.message,'error');
    clearTimeout(overviewRetryTimer);
    overviewRetryTimer=setTimeout(()=>loadOverview({silent:true}),1200);
  }finally{
    overviewRequestInFlight=false;
  }
}
function serverCardActionMenu(s, canStart, canStop, canRestart, canFileManager, canDelete){
  return `<div class="server-card-menu action-menu">
    <button type="button" class="btn btn-sm btn-ghost action-menu-trigger" title="Azioni server" aria-label="Azioni server" onclick="event.stopPropagation();toggleActionMenu(this)">⋮</button>
    <div class="action-menu-dropdown">
      
      ${canFileManager?`<button type="button" onclick="event.stopPropagation();openTesterServerFiles('${s.id}')">File Manager</button>`:''}
      ${canStart && !s.running?`<button type="button" onclick="event.stopPropagation();serverAction('${s.id}','start')">▶ Avvia</button>`:''}
      ${canStop && s.running?`<button type="button" onclick="event.stopPropagation();serverAction('${s.id}','stop')">■ Stop</button>`:''}
      ${canRestart?`<button type="button" onclick="event.stopPropagation();serverAction('${s.id}','restart')">↻ Riavvia</button>`:''}
      ${canDelete?`<button type="button" class="danger" onclick="event.stopPropagation();deleteServer('${s.id}')">Elimina</button>`:''}
    </div>
  </div>`;
}
async function loadServers({silent=false}={}){
  try{
    const r=await api('/api/servers');
    const emptySlots = Number.isFinite(r.emptySlots) ? r.emptySlots : Math.max(0, (Number(r.slots)||0) - r.servers.length);
    $('serverCount').textContent=`${r.servers.length}/${r.slots ?? r.servers.length} slot`;
    const actualCards=r.servers.map(s=>{const p=s.collaboratorPermissions||[];const own=me?.role==='admin'||s.ownerId===me?.id;const canStart=own||p.includes('server.start');const canStop=own||p.includes('server.stop');const canRestart=own||p.includes('server.restart');const canFileManager=own||p.includes('files.read');const canOpenServer=own||p.includes('console.read');const canDelete=own;return `<article class="server-slot-card" onclick="${canOpenServer?`openTesterServer('${s.id}')`:''}"><div class="server-slot-top"><div class="server-name"><span class="server-icon">${s.language==='python'?'Py':'JS'}</span><div><b>${esc(s.name)}</b><small>${s.language==='nodejs'?'Node.js':'Python'} · ${s.id.slice(0,8)}</small></div></div><div class="server-slot-top-right"><span class="state ${s.running?'running':'stopped'}"><i></i>${s.running?'Online':'Offline'}</span>${serverCardActionMenu(s,canStart,canStop,canRestart,canFileManager,canDelete)}</div></div><div class="server-slot-resources"><div><small>RAM</small><b>256 MB</b></div><div><small>CPU</small><b>0.5 CPU</b></div><div><small>ARCHIVIAZIONE</small><b>1 GB</b></div></div><div class="server-slot-actions">${canStart&& !s.running?`<button class="btn btn-gradient btn-sm" onclick="event.stopPropagation();serverAction('${s.id}','start')">▶ Avvia</button>`:''}${canStop&&s.running?`<button class="btn btn-gradient btn-sm" onclick="event.stopPropagation();serverAction('${s.id}','stop')">■ Stop</button>`:''}${canRestart?`<button class="btn btn-outline btn-sm" onclick="event.stopPropagation();serverAction('${s.id}','restart')">↻ Riavvia</button>`:''}${canDelete?`<button class="btn btn-danger btn-sm" onclick="event.stopPropagation();deleteServer('${s.id}')">Elimina</button>`:''}</div><div class="server-slot-hint">${canOpenServer?'Clicca sul riquadro per aprire console e statistiche →':canFileManager?'Accesso al File Manager · permessi limitati':'Accesso condiviso · permessi limitati'}</div></article>`}).join('');
    const emptyCards=Array.from({length:emptySlots},(_,i)=>`<article class="server-slot-card server-slot-empty" onclick="openCreateSlotModal(${r.servers.length+i+1})"><div class="server-slot-top"><div class="server-name"><span class="server-icon">+</span><div><b>Slot ${r.servers.length+i+1}</b><small>Slot disponibile · server non ancora creato</small></div></div><span class="state stopped"><i></i>Vuoto</span></div><div class="server-slot-resources"><div><small>RAM</small><b>256 MB</b></div><div><small>CPU</small><b>0.5 CPU</b></div><div><small>Slot</small><b>1</b></div></div><div class="server-slot-hint">Clicca sullo slot per configurare e creare il server →</div></article>`);
    $('serversBody').innerHTML=(actualCards+emptyCards.join(''))||'<div class="empty server-empty">Nessuno slot disponibile.</div>';
    if((location.hash||'#dashboard').slice(1).toLowerCase()==='dashboard')applyServersFallback(r.servers);
    populateFileServers(r.servers, false)
  }catch(e){if(!silent)toast2(e.message,'error');throw e}
}
function openCreateSlotModal(slotNumber=1){modal(`<div class="modal-head"><div><div class="eyebrow">Slot ${slotNumber}</div><h2>Crea il tuo server</h2><p class="modal-subtitle">Questo slot è disponibile. Configura qui il server per attivarlo.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="serverForm" class="modal-form"><label>Nome server<input id="newName" required placeholder="Discord Bot"></label><label>Runtime<select id="newLang"><option value="nodejs">Node.js</option><option value="python">Python</option></select></label><label>Token Discord<input id="newToken" type="password" required placeholder="Bot token"></label><div class="resource-note"><b>Risorse dello slot</b><span>256 MB RAM · 0.5 CPU · 1 GB storage · 1 slot</span></div><button class="btn btn-gradient btn-block">Crea server</button></form>`);$('serverForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/servers',{method:'POST',body:{name:$('newName').value,language:$('newLang').value,botToken:$('newToken').value}});closeModal();toast2('Server creato','success');await loadServers();jump('servers')}catch(x){toast2(x.message,'error')}}}
function openServerModal(){return openCreateSlotModal(1)}
async function serverAction(id,a){
  const previous=currentServer;
  try{
    const result=await api(`/api/servers/${id}/${a}`,{method:'POST'});

    toast2(
      result?.pending
        ? 'Operazione avviata in background'
        : a==='start'
          ? 'Server avviato'
          : a==='stop'
            ? 'Server arrestato'
            : 'Server riavviato',
      'success'
    );

    // Non ricaricare la lista server mentre siamo dentro la console:
    // potrebbe cambiare currentServer e interrompere il monitor dei log.
    currentServer=id;

    // Forza il recupero dei log senza interrompere il monitor esistente.
    refreshServerMonitor(id).catch(()=>{});
    setTimeout(()=>refreshServerMonitor(id).catch(()=>{}),350);
    setTimeout(()=>refreshServerMonitor(id).catch(()=>{}),900);
    setTimeout(()=>refreshServerMonitor(id).catch(()=>{}),1600);
    setTimeout(()=>refreshServerMonitor(id).catch(()=>{}),3000);
    setTimeout(()=>refreshServerMonitor(id).catch(()=>{}),5000);

  }catch(e){
    toast2(e.message,'error');
  }finally{
    currentServer=id;
  }
}
function userServerPanelTabs(id, active){return `<div class="detail-nav"><button type="button" class="detail-nav-btn" onclick="openTesterServerFiles('${id}')">FILE MANAGER</button></div>`;}
async function serverConsole(id){return openTesterServer(id)}
async function openTesterServerFiles(id){
  stopServerMonitor();
  currentServer=id;
  userServerPanelFilePath='';
  userServerPanelEditorPath='';
  const workspace=$('testerServerWorkspace');
  const grid=$('serversBody');
  const head=$('serverCount')?.closest('.server-list-head');
  const pageHead=$('view-servers')?.querySelector(':scope > .page-head');
  if(!workspace)return;
  const r=await api('/api/servers');
  const s=r.servers.find(x=>x.id===id);
  if(!s)return;
  workspace.classList.remove('hidden');
  workspace.dataset.serverId=id;
  if(grid)grid.classList.add('hidden');
  if(head)head.classList.add('hidden');
  if(pageHead)pageHead.classList.add('hidden');
  workspace.innerHTML=`<div class="tester-reference-page tester-file-manager-page">
    <div class="file-manager-back">
      <button class="back" type="button" onclick="openTesterServer('${id}')">← Console</button>
    </div>
    <div id="userServerPanelBody"></div>
  </div>`;
  await renderUserServerPanelFiles(id);
}
async function openTesterServer(id){
  stopServerMonitor();
  const workspace=$('testerServerWorkspace');
  const grid=$('serversBody');
  const head=$('serverCount')?.closest('.server-list-head');
  const pageHead=$('view-servers')?.querySelector(':scope > .page-head');
  if(!workspace)return;
  const r=await api('/api/servers');
  const s=r.servers.find(x=>x.id===id);
  if(!s)return;
  workspace.classList.remove('hidden');
  workspace.dataset.serverId=id;
  if(grid)grid.classList.add('hidden');
  if(head)head.classList.add('hidden');
  if(pageHead)pageHead.classList.add('hidden');
  workspace.innerHTML=`<div class="tester-reference-page">
    <div class="server-detail-head">
      <div class="detail-title">
        <div class="eyebrow">SERVER</div>
        <h1>${esc(s.name)}</h1>
        <small>${s.language==='nodejs'?'Node.js':'Python'} · ${esc(s.id.slice(0,8))}</small>
      </div>
      <button class="back" type="button" onclick="closeTesterServer()">← Server</button>
    </div>
    <div class="detail-actions">
      <button id="serverStartBtn" class="btn btn-gradient" onclick="serverActionFromConsole('${id}','start')">▶ AVVIA</button>
      <button id="serverStopBtn" class="btn btn-outline" onclick="serverActionFromConsole('${id}','stop')">■ STOP</button>
      <button id="serverRestartBtn" class="btn btn-outline" onclick="serverActionFromConsole('${id}','restart')">↻ RIAVVIA</button>
    </div>
    ${userServerPanelTabs(id,'console')}
    <div class="console-row">
      <div class="console-box">
        <div class="console-head">
          <span>CONSOLE</span>
          <span class="console-status"><i id="userConsoleDot" class="${s.running?'online':''}"></i><span id="serverMonitorStatus">${s.running?'Online':'Offline'}</span></span>
        </div>
        <pre id="consoleOut" class="console-body">container@qubiqohost - Server offline. Avvia il server per visualizzare i log.</pre>
      </div>
    </div>
    <h2 class="stats-title">Statistiche</h2>
    <div class="stats">
      <div class="stat"><small>CPU</small><b id="serverCpu">0.5 CPU</b></div>
      <div class="stat"><small>RAM</small><b id="serverRam">256 MB</b></div>
      <div class="stat"><small>STORAGE</small><b id="serverDisk">1 GB</b></div>
    </div>
  </div>`;
  startServerMonitor(id);
}
function closeTesterServer(){
  stopServerMonitor();
  const workspace=$('testerServerWorkspace');
  const grid=$('serversBody');
  const head=$('serverCount')?.closest('.server-list-head');
  if(workspace){workspace.classList.add('hidden');workspace.innerHTML='';workspace.removeAttribute('data-server-id');}
  if(grid)grid.classList.remove('hidden');
  if(head)head.classList.remove('hidden');
  const pageHead=$('view-servers')?.querySelector(':scope > .page-head');
  if(pageHead)pageHead.classList.remove('hidden');
}

async function renderUserServerPanelFiles(id){
  const body=$('userServerPanelBody'); if(!body)return;
  body.innerHTML=`<div class="admin-server-files"><div class="admin-files-toolbar"><div class="admin-path"><button class="btn btn-outline btn-sm" onclick="userServerPanelUp('${id}')">← Indietro</button><span class="admin-pill" id="userServerPanelPath">/</span></div><div class="admin-actions"><button class="btn btn-gradient btn-sm" onclick="userServerPanelCreateFile('${id}')">＋ File</button><button class="btn btn-outline btn-sm" onclick="userServerPanelCreateFolder('${id}')">＋ Cartella</button><button class="btn btn-outline btn-sm" onclick="userServerPanelRefresh('${id}')">↻ Aggiorna</button></div></div><div class="admin-server-file-list" id="userServerPanelFiles"><div class="admin-server-files-empty">Caricamento...</div></div><input type="file" id="userPanelUpload" hidden multiple onchange="userServerPanelUpload('${id}',this.files,false)"><input type="file" id="userPanelFolderUpload" hidden webkitdirectory directory multiple onchange="userServerPanelUpload('${id}',this.files,true)"><div class="admin-actions" style="margin-top:10px"><button class="btn btn-outline btn-sm" onclick="document.getElementById('userPanelUpload').click()">↑ Carica file</button><button class="btn btn-outline btn-sm" onclick="document.getElementById('userPanelFolderUpload').click()">↑ Carica cartella</button></div></div>`;
  await userServerPanelRefresh(id);
}


async function userServerPanelDelete(id,encodedPath,isDir){
  const target=decodeURIComponent(encodedPath||'');
  const ok=await qhConfirm({
    title:isDir?'Eliminare la cartella?':'Eliminare il file?',
    description:isDir
      ?'La cartella e tutto il suo contenuto verranno eliminati definitivamente.'
      :'Il file verrà eliminato definitivamente.',
    submit:'Elimina',
    icon:'⚠',
    danger:true
  });

  if(!ok)return;

  try{
    await api(`/api/servers/${id}/files/${encodePath(target)}`,{
      method:'DELETE'
    });
    toast2(isDir?'Cartella eliminata':'File eliminato','success');
    await userServerPanelRefresh(id);
  }catch(e){
    toast2(e?.message||'Impossibile eliminare l\'elemento','error');
  }
}

async function userServerPanelCreateFile(id){
  const name=await qhPrompt({
    title:'Crea nuovo file',
    description:'Crea un nuovo file nella cartella corrente.',
    label:'Nome file',
    value:'index.js',
    placeholder:'es. index.js',
    submit:'Crea file',
    icon:'📄'
  });
  if(!name)return;

  try{
    await api(`/api/servers/${id}/files/create`,{
      method:'POST',
      body:{
        path:userServerPanelFilePath,
        name:String(name).trim(),
        content:''
      }
    });
    toast2('File creato','success');
    await userServerPanelRefresh(id);
  }catch(e){
    toast2(e?.message||'Impossibile creare il file','error');
  }
}

async function userServerPanelCreateFolder(id){
  const name=await qhPrompt({
    title:'Crea nuova cartella',
    description:'Crea una nuova cartella nella posizione corrente.',
    label:'Nome cartella',
    value:'nuova-cartella',
    placeholder:'es. config',
    submit:'Crea cartella',
    icon:'📁'
  });
  if(!name)return;

  try{
    await api(`/api/servers/${id}/folders/create`,{
      method:'POST',
      body:{
        path:userServerPanelFilePath,
        name:String(name).trim()
      }
    });
    toast2('Cartella creata','success');
    await userServerPanelRefresh(id);
  }catch(e){
    toast2(e?.message||'Impossibile creare la cartella','error');
  }
}

async function userServerPanelUpload(id,fileList,isFolder=false){
  if(!fileList?.length)return;

  try{
    const files=Array.from(fileList);
    const fd=new FormData();

    for(const file of files){
      const relative=String(
        isFolder
          ? (file.webkitRelativePath||file.name)
          : file.name
      ).replace(/\\/g,'/');

      if(relative){
        fd.append('file',file,relative);
      }
    }

    if(!fd.has('file')){
      throw new Error('Nessun file selezionato');
    }

    const result=await api(
      `/api/servers/${id}/upload?path=${encodeURIComponent(userServerPanelFilePath)}`,
      {
        method:'POST',
        body:fd,
        timeoutMs:120000
      }
    );

    toast2(
      `${result.uploaded||files.length} elemento/i caricati`,
      'success'
    );

    await userServerPanelRefresh(id);
  }catch(e){
    toast2(e?.message||'Upload fallito','error');
  }
}

async function userServerPanelRefresh(id){
  try{
    const r=await api(`/api/servers/${id}/files?path=${encodeURIComponent(userServerPanelFilePath)}`);
    userServerPanelFilePath=r.path||'';
    const path=$('userServerPanelPath');
    if(path)path.textContent='/'+userServerPanelFilePath;

    const list=$('userServerPanelFiles');
    if(!list)return;

    const files=(r.files||[]).filter(f=>!(f.isDir&&['.qbq-runtime','data'].includes(String(f.name||'').toLowerCase())));

    list.innerHTML=files.length?files.map(f=>`
      <div class="admin-server-file-row" onclick="${f.isDir?`userServerPanelOpenFolder('${id}','${encodeURIComponent(f.name)}')`:`userServerPanelEdit('${id}','${encodeURIComponent(f.path)}')`}">
        <div class="admin-server-file-main">
          <span class="admin-server-file-icon">
            <svg class="ui-icon"><use href="${f.isDir?'#i-files':'#i-code'}"></use></svg>
          </span>
          <div>
            <b>${esc(f.name)}</b>
            <small>${f.isDir?'Cartella':FormatBytes(f.size)}</small>
          </div>
        </div>
        <div class="admin-actions">
          <div class="action-menu">
            <button type="button" class="btn btn-sm btn-ghost action-menu-trigger" title="Azioni" aria-label="Azioni" onclick="event.stopPropagation();toggleActionMenu(this)">⋮</button>
            <div class="action-menu-dropdown">
              <button type="button" onclick="event.stopPropagation();userServerPanelRename('${id}','${encodeURIComponent(f.name)}')">Rinomina</button>
              ${f.isDir?'':`<button type="button" onclick="event.stopPropagation();userServerPanelDownload('${id}','${encodeURIComponent(f.path)}')">Scarica</button>`}
              <button type="button" onclick="event.stopPropagation();userServerPanelDelete('${id}','${encodeURIComponent(f.path)}',${!!f.isDir})">Elimina</button>
            </div>
          </div>
        </div>
      </div>`).join(''):'<div class="admin-server-files-empty">Nessun file in questa cartella.</div>';
  }catch(e){
    toast2(e.message,'error');
  }
}

function userServerPanelOpenFolder(id,encoded){
  userServerPanelFilePath=userServerPanelFilePath?`${userServerPanelFilePath}/${decodeURIComponent(encoded)}`:decodeURIComponent(encoded);
  return userServerPanelRefresh(id);
}

function userServerPanelUp(id){
  if(!userServerPanelFilePath)return;
  const parts=userServerPanelFilePath.split('/');
  parts.pop();
  userServerPanelFilePath=parts.join('/');
  return userServerPanelRefresh(id);
}

async function userServerPanelRename(id,encoded){
  const oldName=decodeURIComponent(encoded);
  const name=await qhPrompt({
    title:'Rinomina elemento',
    description:'Inserisci il nuovo nome del file o della cartella.',
    label:'Nuovo nome',
    value:oldName,
    placeholder:oldName,
    submit:'Rinomina',
    icon:'✎'
  });
  if(!name)return;

  try{
    await api(`/api/servers/${id}/files/rename`,{
      method:'POST',
      body:{
        path:userServerPanelFilePath,
        oldName,
        newName:String(name).trim()
      }
    });
    toast2('Elemento rinominato','success');
    userServerPanelRefresh(id);
  }catch(e){
    toast2(e.message,'error');
  }
}

async function userServerPanelDownload(id,encoded){
  const filePath=decodeURIComponent(encoded);
  try{
    const r=await api(`/api/servers/${id}/files/${encodeURIComponent(filePath)}`);
    const blob=new Blob([String(r.content||'')],{type:'text/plain;charset=utf-8'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url;
    a.download=filePath.split('/').pop()||'download';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(e){
    toast2(e.message,'error');
  }
}

async function userServerPanelEdit(id,encoded){const filePath=decodeURIComponent(encoded);try{const r=await api(`/api/servers/${id}/files/${encodeURIComponent(filePath)}`);userServerPanelEditorPath=filePath;const body=$('userServerPanelBody');body.innerHTML=`<div class="admin-file-editor-modal"><div class="modal-head"><div><div class="eyebrow">Editor file</div><h2>${esc(filePath.split('/').pop()||filePath)}</h2></div></div><div class="admin-editor-surface"><textarea id="userPanelEditorText" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" wrap="off">${esc(trimTrailingBlankLines(r.content||''))}</textarea></div><div class="admin-editor-actions"><button type="button" class="btn btn-outline" onclick="openTesterServerFiles('${id}')">ANNULLA</button><button type="button" class="btn btn-gradient" onclick="userServerPanelSave('${id}')">SALVA</button></div></div>`;}catch(e){toast2(e.message,'error')}}
async function userServerPanelSave(id){if(!userServerPanelEditorPath)return;try{await api(`/api/servers/${id}/files/${encodeURIComponent(userServerPanelEditorPath)}`,{method:'PUT',body:{content:$('userPanelEditorText').value}});toast2('File salvato','success');userServerPanelEditorPath='';openTesterServerFiles(id)}catch(e){toast2(e.message,'error')}}

function formatResource(v,unit){const n=Number(v)||0;if(unit==='MB'){if(n>=1024)return `${(n/1024).toFixed(2).replace(/\.00$/,'')} GB`;if(n===0)return '0 MB';return `${n>=100?Math.round(n):n>=10?Math.round(n):n.toFixed(1).replace(/\.0$/,'')} MB`}return `${n.toFixed(1)}%`}
async function refreshServerMonitor(id){
  const generation=serverMonitorGeneration;
  const status=$('serverMonitorStatus');
  const out=$('consoleOut');
  if(!status)return;

  // I log devono essere aggiornati indipendentemente dalle statistiche:
  // la richiesta SSH delle stats può essere lenta e non deve bloccare la console.
  const logsPromise=api(`/api/servers/${id}/logs`)
    .then(data=>({ok:true,data}))
    .catch(error=>({ok:false,error}));

  const statsPromise=api(`/api/servers/${id}/stats`)
    .then(data=>({ok:true,data}))
    .catch(error=>({ok:false,error}));

  // Mostra i nuovi log appena arrivano, senza aspettare /stats.
  const logsResult=await logsPromise;
  if(generation!==serverMonitorGeneration || !$('serverMonitorStatus'))return;
  if(logsResult.ok){
    const logs=Array.isArray(logsResult.data?.logs)?logsResult.data.logs:[];
    if(out){
      const wasNearBottom=out.scrollHeight-out.scrollTop-out.clientHeight<70;
      out.textContent=logs.length?logs.map(line=>`container@qubiqohost - ${normalizeTesterConsoleLine(line)}`).join('\n'):'container@qubiqohost - Nessun log disponibile.';
      if(wasNearBottom)out.scrollTop=out.scrollHeight;
    }
  }else if(out&&out.textContent==='Connessione alla console...'){
    out.textContent='Nessun log disponibile.';
  }

  // Le statistiche possono arrivare dopo e non bloccano la console.
  const statsResult=await statsPromise;
  if(generation!==serverMonitorGeneration || !$('serverMonitorStatus'))return;
  if(statsResult.ok){
    const st=statsResult.data?.stats||{};
    const running=!!st.running;
    status.className=`admin-console-status`;
    status.textContent=running?'Online':'Offline';
    const userDot=$('userConsoleDot'); if(userDot)userDot.classList.toggle('online',running);
    const cpu=Number(st.cpuPercent)||0;
    const ram=Number(st.ramMB)||0;
    const disk=1024;
    const uptime=Number(st.uptimeSeconds)||0;
    const cpuEl=$('serverCpu'),ramEl=$('serverRam'),diskEl=$('serverDisk');
    if(cpuEl)cpuEl.textContent='0.5 CPU';
    if(ramEl)ramEl.textContent='256 MB';
    if(diskEl)diskEl.textContent='1 GB';
    const uptimeEl=$('serverUptime');
    if(uptimeEl){
      const d=Math.floor(uptime/86400), h=Math.floor((uptime%86400)/3600), m=Math.floor((uptime%3600)/60), sec=uptime%60;
      uptimeEl.textContent=d?`${d}g ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`:`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
    }
    const cpuBar=$('serverCpuBar'),ramBar=$('serverRamBar'),diskBar=$('serverDiskBar');
    if(cpuBar)cpuBar.style.width=`${Math.min(100,Math.max(0,cpu/50*100))}%`;
    if(ramBar)ramBar.style.width=`${Math.min(100,Math.max(0,ram/256*100))}%`;
    if(diskBar)diskBar.style.width=`${Math.min(100,Math.max(0,disk/51200*100))}%`;
    const start=$('serverStartBtn'),stop=$('serverStopBtn'),restart=$('serverRestartBtn');
    if(start)start.disabled=running;
    if(stop)stop.disabled=!running;
    if(restart)restart.disabled=false;
    const refresh=$('serverResourceRefresh');
    if(refresh)refresh.textContent='Aggiornato ora';
  }else{
    const refresh=$('serverResourceRefresh');
    if(refresh)refresh.textContent='In attesa dei dati...';
  }
}

async function serverActionFromConsole(id,a){
  try{
    await serverAction(id,a);
    currentServer=id;

    if(typeof refreshServerMonitor==='function'){
      refreshServerMonitor(id).catch(()=>{});
      [350,900,1600,3000,5000].forEach(ms=>{
        setTimeout(()=>refreshServerMonitor(id).catch(()=>{}),ms);
      });
    }
  }catch(e){
    const out=$('consoleOut');
    if(out)out.textContent='container@qubiqohost - Errore: '+(e.message||String(e));
    toast2(e.message,'error');
  }
}
async function sendConsole(id){const input=$('consoleCmd');const v=input?.value.trim();if(!v)return;try{await api(`/api/servers/${id}/command`,{method:'POST',body:{command:v}});input.value='';const out=$('consoleOut');if(out)out.textContent+=`\ncontainer@qubiqohost - ${v}`;input.focus()}catch(e){toast2(e.message,'error')}}
async function deleteServer(id){const ok=await qhConfirm({title:'Eliminare il server?',description:'Il server, il suo storage e i relativi file verranno eliminati definitivamente.',submit:'Elimina server',icon:'⚠',danger:true});if(!ok)return;try{await api(`/api/servers/${id}/delete`,{method:'POST'});toast2('Server eliminato','success');loadServers()}catch(e){toast2(e.message,'error')}}
function populateFileServers(servers,loadNow=true){const select=$('fileServer');if(!select)return;const previous=select.value||currentServer||'';select.innerHTML=servers.length?servers.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join(''):'<option value="">Nessun server</option>';if(servers.length){const wanted=servers.some(s=>s.id===previous)?previous:servers[0].id;select.value=wanted;currentServer=wanted;}else{currentServer='';}if(loadNow&&servers.length)loadFiles();}
let currentFilePath='';
function encodePath(p){return encodeURIComponent(p||'');}
function renderBreadcrumbs(){const el=$('breadcrumbs');if(!el)return;const parts=currentFilePath?currentFilePath.split('/').filter(Boolean):[];let html=`<button class="crumb-btn" onclick="goToFolder('')">home</button>`;let acc='';parts.forEach((part,i)=>{acc=acc?`${acc}/${part}`:part;html+=`<span>›</span><button class="crumb-btn" onclick="goToFolder('${encodeURIComponent(acc)}')">${esc(part)}</button>`});el.innerHTML=html;}
async function goToFolder(encoded){currentFilePath=encoded?decodeURIComponent(encoded):'';closeEditor();await loadFiles();}
async function loadFiles(){if(!$('fileServer'))return;currentServer=$('fileServer').value||currentServer;if(!currentServer){$('filesList').innerHTML='<div class="empty">Crea prima un server.</div>';return}try{const r=await api(`/api/servers/${currentServer}/files?path=${encodePath(currentFilePath)}`);currentFilePath=r.path||'';renderBreadcrumbs();const rows=(r.files||[]).filter(f=>!(f.isDir&&['.qbq-runtime','data'].includes(String(f.name||'').toLowerCase()))).map(f=>`<div class="file-row" onclick="${f.isDir?`openFolder('${encodeURIComponent(f.path)}')`:`editFile('${encodeURIComponent(f.path)}')`}"><span class="file-icon">${f.isDir?'📁':'📄'}</span><div><b>${esc(f.name)}</b><small>${f.isDir?'Cartella':FormatBytes(f.size)}</small></div><div class="file-actions"><div class="action-menu"><button class="btn btn-xs btn-outline action-menu-trigger" title="Azioni" aria-label="Azioni" onclick="event.stopPropagation();toggleActionMenu(this)">⋮</button><div class="action-menu-dropdown">${f.isDir?`<button type="button" onclick="event.stopPropagation();renameFile('${encodeURIComponent(f.name)}')">Rinomina</button>`:`<button type="button" onclick="event.stopPropagation();renameFile('${encodeURIComponent(f.name)}')">Rinomina</button><button type="button" onclick="event.stopPropagation();downloadFile('${encodeURIComponent(f.path)}')">Scarica</button><button type="button" onclick="event.stopPropagation();editFile('${encodeURIComponent(f.path)}')">Editor</button>`}<button type="button" onclick="event.stopPropagation();removeFile('${encodeURIComponent(f.path)}',${f.isDir})">Elimina</button></div></div></div></div>`).join('');$('filesList').innerHTML=rows||'<div class="empty">Cartella vuota.</div>'}catch(e){toast2(e.message,'error')}}
function trimTrailingBlankLines(content){return String(content??'').replace(/[ \\t]+$/,'').replace(/(\r?\n[ \\t]*)+$/,'')}
function resizeEditor(){
  const ta=$('editorText'), body=ta?.closest('.editor-body'), g=$('editorGutter');
  if(!ta)return;
  const content=trimTrailingBlankLines(ta.value);
  if(ta.value!==content)ta.value=content;

  
  
  const mobile=window.innerWidth<=700;
  const target=Math.floor(window.innerHeight*(mobile ? .72 : .74));
  const min=mobile?Math.floor(window.innerHeight*.68):560;
  const h=Math.max(min,Math.min(target,820));

  ta.style.height=h+'px';
  ta.style.minHeight=h+'px';
  ta.style.overflowY='auto';
  if(body){
    body.style.height=h+'px';
    body.style.minHeight=h+'px';
  }
  if(g){
    const lines=Math.max(1,content?content.split(/\n/).length:1);
    g.innerHTML=Array.from({length:lines},(_,i)=>i+1).join('<br>');
    g.style.height=h+'px';
    g.style.minHeight=h+'px';
    g.scrollTop=ta.scrollTop;
  }
}window.addEventListener('resize',()=>{if($('fileEditor')&&!$('fileEditor').classList.contains('hidden'))resizeEditor()});
$('fileServer').onchange=()=>{currentServer=$('fileServer').value;currentFilePath='';closeEditor();loadFiles()};
function openFolder(encoded){currentFilePath=decodeURIComponent(encoded);closeEditor();loadFiles();}
function updateEditorGutter(){resizeEditor()}
async function editFile(encodedPath){const filePath=decodeURIComponent(encodedPath);try{const r=await api(`/api/servers/${currentServer}/files/${encodePath(filePath)}`);editorFile=filePath;$('editorName').textContent=filePath;$('editorLang').textContent=(filePath.split('.').pop()||'TEXT').toUpperCase();$('editorText').value=trimTrailingBlankLines(r.content||'');$('fileEditor').classList.remove('hidden');requestAnimationFrame(()=>{resizeEditor();$('editorText').focus()})}catch(e){toast2(e.message,'error')}}
function closeEditor(){$('fileEditor').classList.add('hidden');editorFile=null}
async function saveEditor(){if(!editorFile)return;try{await api(`/api/servers/${currentServer}/files/${encodePath(editorFile)}`,{method:'PUT',body:{content:$('editorText').value}});toast2('File salvato','success')}catch(e){toast2(e.message,'error')}}
function downloadFile(encoded){window.location.href=`/api/servers/${currentServer}/files/${encodePath(decodeURIComponent(encoded))}?download=1`}
async function createFile(){
  if(!currentServer)return;
  try{
    const name=await qhPrompt({
      title:'Crea nuovo file',
      description:'Aggiungi un file al server nella cartella corrente.',
      label:'Nome file',
      value:'index.js',
      placeholder:'es. index.js',
      submit:'Crea file',
      icon:'📄'
    });
    if(!name)return;
    await api(`/api/servers/${currentServer}/files/create`,{
      method:'POST',
      body:{path:currentFilePath,name:name.trim(),content:''}
    });
    toast2('File creato','success');
    await loadFiles();
  }catch(e){
    toast2(e?.message||'Impossibile creare il file','error');
  }
}

async function createFolder(){
  if(!currentServer)return;
  try{
    const name=await qhPrompt({
      title:'Crea nuova cartella',
      description:'Crea una cartella nella posizione corrente.',
      label:'Nome cartella',
      value:'src',
      placeholder:'es. src',
      submit:'Crea cartella',
      icon:'📁'
    });
    if(!name)return;
    await api(`/api/servers/${currentServer}/folders/create`,{
      method:'POST',
      body:{path:currentFilePath,name:name.trim()}
    });
    toast2('Cartella creata','success');
    await loadFiles();
  }catch(e){
    toast2(e?.message||'Impossibile creare la cartella','error');
  }
}
async function renameFile(encoded){const oldName=decodeURIComponent(encoded),n=await qhPrompt({title:'Rinomina elemento',description:'Inserisci il nuovo nome del file o della cartella.',label:'Nuovo nome',value:oldName,placeholder:oldName,submit:'Rinomina',icon:'✎'});if(!n)return;try{await api(`/api/servers/${currentServer}/files/rename`,{method:'POST',body:{path:currentFilePath,oldName,newName:n}});toast2('Elemento rinominato','success');loadFiles()}catch(e){toast2(e.message,'error')}}
async function removeFile(encoded,isDir){const ok=await qhConfirm({title:isDir?'Eliminare la cartella?':'Eliminare il file?',description:isDir?'La cartella e tutto il suo contenuto verranno eliminati definitivamente.':'Il file verrà eliminato definitivamente.',submit:'Elimina',icon:'⚠',danger:true});if(!ok)return;try{await api(`/api/servers/${currentServer}/files/${encodePath(decodeURIComponent(encoded))}`,{method:'DELETE'});loadFiles()}catch(e){toast2(e.message,'error')}}
async function uploadFiles(fileList){
  if(!fileList?.length||!currentServer)return;
  try{
    const files=Array.from(fileList);
    const fd=new FormData();

    for(const file of files){
      const relative=String(file.webkitRelativePath||file.name||'').replace(/\\/g,'/');
      if(relative)fd.append('file',file,relative);
    }

    if(!fd.has('file'))throw new Error('Nessun file selezionato');

    const d=await api(`/api/servers/${currentServer}/upload?path=${encodePath(currentFilePath)}`,{
      method:'POST',
      body:fd,
      timeoutMs:120000
    });

    toast2(`${d.uploaded||files.length} elemento/i caricati`,'success');
    await loadFiles();
  }catch(e){
    toast2(e?.message||'Upload fallito','error');
  }
}
async function uploadFile(){const input=$('fileUpload');await uploadFiles(input.files);input.value=''}
async function uploadFolder(){const input=$('folderUpload');await uploadFiles(input.files);input.value=''}

async function loadDatabases(){
  try{
    const r=await api('/api/panel/databases');
    const items=Array.isArray(r.databases)?r.databases:[];
    $('dbBody').innerHTML=items.length?items.map(d=>`<tr><td><b>${esc(d.name)}</b></td><td>${esc(d.type||'MySQL 8.0')}</td><td><code>${esc(d.username||'—')}</code></td><td>${FormatBytes(Number(d.sizeMB||0)*1024*1024)}</td><td>${fmtDate(d.createdAt)}</td><td><div class="row-actions"><button class="btn btn-xs btn-danger" onclick="deleteDatabase('${d.id}')">×</button></div></td></tr>`).join(''):'<tr><td colspan="6"><div class="empty">Nessun database.</div></td></tr>';
  }catch(e){
    $('dbBody').innerHTML='<tr><td colspan="6"><div class="empty">Impossibile caricare i database.</div></td></tr>';
    toast2(e.message,'error');
  }
}
async function createDatabase(){
  modal(`<div class="modal-head"><div><div class="eyebrow">Database</div><h2>Nuovo database</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div><form id="databaseForm" class="modal-form"><label>Nome database<input id="databaseName" required maxlength="40" pattern="[A-Za-z0-9_-]+" placeholder="my_database"></label><button class="btn btn-gradient btn-block">Crea database</button></form>`);
  $('databaseForm').onsubmit=async e=>{
    e.preventDefault();
    try{
      await api('/api/panel/databases',{method:'POST',body:{name:$('databaseName').value}});
      closeModal(); toast2('Database creato','success'); loadDatabases();
    }catch(err){toast2(err.message,'error')}
  };
}
async function deleteDatabase(id){
  const ok=await qhConfirm({icon:'⚠',title:'Eliminare database?',description:'Il database verrà rimosso dal pannello.',submit:'Elimina',danger:true});
  if(!ok)return;
  try{await api(`/api/panel/databases/${id}`,{method:'DELETE'});toast2('Database eliminato','success');loadDatabases()}catch(e){toast2(e.message,'error')}
}

async function loadBackups(){
  try{
    const r=await api('/api/panel/backups');
    $('backupBody').innerHTML=r.backups.length?r.backups.map(b=>`
      <tr>
        <td><b>${esc(b.filename)}</b></td>
        <td>${esc(b.serverName)}</td>
        <td>${FormatBytes(b.size)}</td>
        <td><span class="state running"><i></i>Completato</span></td>
        <td>${fmtDate(b.createdAt)}</td>
        <td>
          <div class="row-actions backup-actions">
            <div class="action-menu">
              <button class="btn btn-xs btn-outline action-menu-trigger" title="Azioni" aria-label="Azioni" onclick="toggleActionMenu(this)">⋮</button>
              <div class="action-menu-dropdown">
                <button type="button" onclick="restoreBackup('${b.id}')">Ripristina</button>
                <button type="button" onclick="renameBackup('${b.id}')">Rinomina</button>
                <button type="button" onclick="downloadBackup('${b.id}')">Scarica</button>
                <button type="button" onclick="deleteBackup('${b.id}')">Elimina</button>
              </div>
            </div>

          </div>
        </td>
      </tr>`).join(''):'<tr><td colspan="6"><div class="empty">Nessun backup.</div></td></tr>'
  }catch(e){toast2(e.message,'error')}
}

function getActionMenuDropdown(menu){
  return menu?menu._qhDropdown||menu.querySelector('.action-menu-dropdown'):null;
}
function closeActionMenus(){
  document.querySelectorAll('.action-menu.open').forEach(menu=>{
    menu.classList.remove('open');
    const dropdown=getActionMenuDropdown(menu);
    if(!dropdown)return;
    dropdown.style.top='';dropdown.style.left='';dropdown.style.right='';dropdown.style.bottom='';dropdown.style.position='';
    dropdown.style.display='';
    dropdown.style.visibility='';
    dropdown.removeAttribute('data-action-menu-portal');
    if(dropdown.parentElement!==menu)menu.appendChild(dropdown);
  });
}
function toggleActionMenu(btn){
  const menu=btn.parentElement;
  const dropdown=getActionMenuDropdown(menu);
  const wasOpen=menu.classList.contains('open');
  closeActionMenus();
  if(wasOpen || !dropdown)return;
  menu._qhDropdown=dropdown;
  menu.classList.add('open');

  // Porta il menu fuori da card/tabelle con overflow o stacking context e
  // posizionalo rispetto alla viewport, così non viene mai tagliato.
  if(dropdown.parentElement!==document.body){
    document.body.appendChild(dropdown);
    dropdown.setAttribute('data-action-menu-portal','1');
  }
  dropdown.style.position='fixed';
  dropdown.style.display='grid';
  dropdown.style.visibility='hidden';
  dropdown.style.left='0px';
  dropdown.style.top='0px';
  dropdown.style.right='auto';
  dropdown.style.bottom='auto';

  const place=()=>{
    const rect=btn.getBoundingClientRect();
    const vw=window.visualViewport?.width || window.innerWidth;
    const vh=window.visualViewport?.height || window.innerHeight;
    const margin=8;
    const gap=8;
    const width=Math.min(Math.max(dropdown.offsetWidth,150),Math.max(120,vw-margin*2));
    const height=Math.min(dropdown.offsetHeight,Math.max(80,vh-margin*2));

    // Di default sotto al pulsante; se non c'e' spazio, apri sopra.
    let left=rect.right-width;
    let top=rect.bottom+gap;
    if(top+height>vh-margin) top=rect.top-height-gap;

    // Clamp orizzontale/verticale alla viewport.
    left=Math.max(margin,Math.min(left,vw-width-margin));
    top=Math.max(margin,Math.min(top,vh-height-margin));

    dropdown.style.width=`${width}px`;
    dropdown.style.maxHeight=`${Math.max(80,vh-margin*2)}px`;
    dropdown.style.left=`${Math.round(left)}px`;
    dropdown.style.top=`${Math.round(top)}px`;
    dropdown.style.visibility='visible';
  };

  // Aspetta il layout reale: su mobile offsetWidth/offsetHeight possono non
  // essere definitivi nello stesso frame del click.
  requestAnimationFrame(place);
}
document.addEventListener('click',e=>{
  if(e.target.closest('.action-menu')||e.target.closest('.action-menu-dropdown'))return;
  closeActionMenus();
});
document.addEventListener('scroll',closeActionMenus,true);
window.addEventListener('resize',closeActionMenus);

async function renameBackup(id){
  const b=(await api('/api/panel/backups')).backups.find(x=>x.id===id);
  if(!b)return;

  const name=await qhPrompt({
    title:'Rinomina backup',
    description:'Inserisci il nuovo nome del backup.',
    label:'Nome backup',
    value:b.filename,
    submit:'Rinomina'
  });

  if(!name)return;

  try{
    await api(`/api/panel/backups/${id}`,{
      method:'PATCH',
      body:{name:String(name).trim()}
    });
    toast2('Backup rinominato','success');
    loadBackups();
  }catch(e){
    toast2(e.message,'error');
  }
}

async function createBackup(){const r=await api('/api/servers');if(!r.servers.length)return toast2('Crea prima un server','error');const selected=await qhSelect({title:'Nuovo backup',description:'Scegli il server di cui vuoi creare una copia completa.',label:'Server per backup',options:r.servers.map(s=>({value:s.id,label:s.name})),value:r.servers[0].id,submit:'Crea backup',icon:'↥'});if(!selected)return;try{const result=await api('/api/panel/backups',{method:'POST',body:{serverId:selected}});if(result?.pending&&result.jobId){toast2('Backup avviato sul nodo predefinito','success');pollBackupJob(result.jobId)}else{toast2('Backup creato','success');loadBackups()}}catch(e){toast2(e.message,'error')}}async function pollBackupJob(jobId){for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,2000));try{const st=await api(`/api/panel/backups/jobs/${jobId}`);if(st.state==='completed'){toast2('Backup completato','success');await loadBackups();return}if(st.state==='error'){toast2(st.error||'Creazione backup fallita','error');return}}catch(_){}}toast2('Il backup è ancora in lavorazione','info')}function downloadBackup(id){window.location.href=`/api/panel/backups/${id}/download`}async function restoreBackup(id){const ok=await qhConfirm({title:'Ripristinare il backup?',description:'Il contenuto attuale del server verrà sostituito con quello del backup.',submit:'Ripristina',icon:'↥',danger:true});if(!ok)return;try{const result=await api(`/api/panel/backups/${id}`,{method:'POST',body:{action:'restore'}});if(result?.pending){toast2('Ripristino avviato sul nodo predefinito','success');pollRestoreJob(result.jobId)}else toast2('Backup ripristinato','success')}catch(e){toast2(e.message,'error')}}async function pollRestoreJob(jobId){for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,2000));try{const st=await api(`/api/panel/backups/jobs/${jobId}`);if(st.state==='completed'){toast2('Backup ripristinato','success');await loadBackups();return}if(st.state==='error'){toast2(st.error||'Ripristino fallito','error');return}}catch(_){}}toast2('Il ripristino è ancora in lavorazione','info')}async function deleteBackup(id){const ok=await qhConfirm({title:'Eliminare il backup?',description:'Questa copia verrà rimossa definitivamente.',submit:'Elimina backup',icon:'⚠',danger:true});if(!ok)return;try{await api(`/api/panel/backups/${id}`,{method:'DELETE'});toast2('Backup eliminato','success');loadBackups()}catch(e){toast2(e.message,'error')}}
async function loadNetwork(){try{const r=await api('/api/panel/network');$('networkBody').innerHTML=r.network.length?r.network.map(n=>`<tr><td>${esc(n.service)}</td><td>${n.protocol}</td><td><b>${n.port}</b></td><td><label class="switch"><input type="checkbox" ${n.enabled?'checked':''} onchange="toggleNetwork('${n.id}',this.checked)"><i></i></label></td><td><button class="btn btn-xs btn-danger" onclick="deleteNetwork('${n.id}')">Elimina</button></td></tr>`).join(''):'<tr><td colspan="5"><div class="empty">Nessuna porta configurata.</div></td></tr>'}catch(e){toast2(e.message,'error')}}async function createNetwork(){const service=await qhPrompt({title:'Aggiungi servizio di rete',description:'Configura una porta TCP per il tuo server.',label:'Servizio',value:'Discord Bot',placeholder:'Nome servizio',submit:'Continua',icon:'↔'});if(!service)return;const port=await qhPrompt({title:'Porta del servizio',description:'Inserisci una porta TCP compresa tra 1 e 65535.',label:'Porta',value:'3000',placeholder:'3000',submit:'Aggiungi porta',icon:'⇄',type:'number'});if(!port)return;try{await api('/api/panel/network',{method:'POST',body:{service,port,protocol:'TCP'}});toast2('Porta aggiunta','success');loadNetwork()}catch(e){toast2(e.message,'error')}}async function toggleNetwork(id,en){await api(`/api/panel/network/${id}`,{method:'PATCH',body:{enabled:en}})}async function deleteNetwork(id){await api(`/api/panel/network/${id}`,{method:'DELETE'});loadNetwork()}
const COLLAB_PERMISSION_LABELS={
  'console.read':'Leggi console',
  'files.read':'Leggi file','files.write':'Modifica file',
  'server.start':'Avvia','server.stop':'Stop','server.restart':'Riavvia'
};
function collaboratorPermissionChecks(selected=[]){
  return Object.entries(COLLAB_PERMISSION_LABELS).map(([key,label])=>`<label class="toggle-row" style="margin:0;padding:9px 0;border-bottom:1px solid var(--line2)"><span>${label}</span><input type="checkbox" data-collab-permission="${key}" ${selected.includes(key)?'checked':''}><i></i></label>`).join('');
}
async function loadSubusers(){
  try{
    const r=await api('/api/panel/subusers');
    $('subuserBody').innerHTML=r.subusers.length?r.subusers.map(x=>`<tr><td><b>${esc(x.username)}</b><small style="display:block;color:var(--muted);margin-top:3px">${esc(x.email||'')}</small></td><td>${x.permissions.length}</td><td>${x.serverIds.length}</td><td>${fmtDate(x.createdAt)}</td><td><div class="row-actions"><button class="btn btn-xs btn-outline" onclick="editSubuser('${x.id}')">Modifica</button><button class="btn btn-xs btn-danger" onclick="deleteSubuser('${x.id}')">Rimuovi</button></div></td></tr>`).join(''):'<tr><td colspan="5"><div class="empty">Nessun collaboratore.</div></td></tr>';
  }catch(e){toast2(e.message,'error')}
}
async function openSubuserEditor(existing=null){
  const servers=(await api('/api/servers')).servers||[];
  const selectedServers=new Set((existing?.serverIds||[]).map(String));
  const selectedPermissions=existing?.permissions||['console.read'];
  modal(`<div class="modal-head"><div><div class="eyebrow">Collaboratori</div><h2>${existing?'Modifica collaboratore':'Nuovo collaboratore'}</h2><p class="modal-subtitle">Usa username o email di un account già registrato.</p></div><button class="icon-btn" onclick="closeModal()">×</button></div>
  <form id="subuserForm" class="modal-form">
    <label>Username o email<input id="subuserIdentifier" required ${existing?'disabled':''} value="${esc(existing?.username||'')}" placeholder="es. mario@example.com"></label>
    ${existing?'':'<small style="color:var(--muted);margin:-2px 0 8px">L’account deve già esistere. Non verrà creato nessun nuovo account.</small>'}
    <div><b style="display:block;margin:8px 0">Server autorizzati</b><div style="border:1px solid var(--line);border-radius:9px;padding:4px 10px;max-height:190px;overflow:auto">${servers.length?servers.map(x=>`<label class="toggle-row" style="margin:0;padding:9px 0;border-bottom:1px solid var(--line2)"><span>${esc(x.name)}</span><input type="checkbox" data-collab-server="${x.id}" ${selectedServers.has(String(x.id))?'checked':''}><i></i></label>`).join(''):'<div style="padding:12px;color:var(--muted)">Non hai ancora creato server.</div>'}</div></div>
    <div><b style="display:block;margin:14px 0 4px">Permessi</b><div style="border:1px solid var(--line);border-radius:9px;padding:4px 10px">${collaboratorPermissionChecks(selectedPermissions)}</div></div>
    <button class="btn btn-gradient btn-block">${existing?'Salva modifiche':'Aggiungi collaboratore'}</button>
  </form>`);
  $('subuserForm').onsubmit=async e=>{
    e.preventDefault();
    const serverIds=[...document.querySelectorAll('[data-collab-server]:checked')].map(x=>x.dataset.collabServer);
    const permissions=[...document.querySelectorAll('[data-collab-permission]:checked')].map(x=>x.dataset.collabPermission);
    try{
      if(existing) await api(`/api/panel/subusers/${existing.id}`,{method:'PATCH',body:{serverIds,permissions}});
      else await api('/api/panel/subusers',{method:'POST',body:{identifier:$('subuserIdentifier').value,serverIds,permissions}});
      closeModal();toast2(existing?'Collaboratore aggiornato':'Collaboratore aggiunto','success');loadSubusers();
    }catch(e){toast2(e.message,'error')}
  };
}
async function createSubuser(){try{await openSubuserEditor()}catch(e){toast2(e.message,'error')}}
async function editSubuser(id){try{const r=await api('/api/panel/subusers');const sub=r.subusers.find(x=>x.id===id);if(sub)await openSubuserEditor(sub)}catch(e){toast2(e.message,'error')}}
async function deleteSubuser(id){const ok=await qhConfirm({title:'Rimuovere il collaboratore?',description:'Perderà immediatamente l’accesso ai server condivisi.',submit:'Rimuovi',icon:'⚠',danger:true});if(!ok)return;try{await api(`/api/panel/subusers/${id}`,{method:'DELETE'});toast2('Collaboratore rimosso','success');loadSubusers()}catch(e){toast2(e.message,'error')}}
async function loadBilling(){try{const [r,tr]=await Promise.all([api('/api/billing'),api('/api/billing/transactions')]);$('creditBalance').textContent=r.credits??me.credits??0;$('slotBalance').textContent=r.slots??me.slots??0;$('slotCost').textContent=r.slotCost??100;$('packages').innerHTML=(r.packages||[]).map(p=>`<div class="package"><div class="package-top"><span>Qubiqo</span><b>${p.label}</b></div><strong>${p.credits}</strong><small>crediti</small><div class="package-price">€${(p.amountCents/100).toFixed(2)}</div><button class="btn btn-gradient btn-block" onclick="buyCredits('${p.id}')">Acquista con PayPal</button></div>`).join('');$('transactionsBody').innerHTML=tr.transactions?.length?tr.transactions.map(t=>`<tr><td>${esc(t.description||'Acquisto crediti')}</td><td>${t.credits||0}</td><td>€${((t.amountCents||0)/100).toFixed(2)}</td><td><span class="badge">${esc(t.status)}</span></td><td>${fmtDate(t.createdAt)}</td></tr>`).join(''):'<tr><td colspan="5"><div class="empty">Nessuna transazione.</div></td></tr>'}catch(e){toast2(e.message,'error')}}async function buyCredits(id){try{const r=await api('/api/billing/checkout',{method:'POST',body:{packageId:id}});if(r.approvalUrl)window.location.href=r.approvalUrl;else toast2('PayPal non configurato','error')}catch(e){toast2(e.message,'error')}}async function buySlot(){try{const r=await api('/api/billing/buy-slot',{method:'POST',body:{quantity:1}});me.credits=r.credits;me.slots=r.slots;$('creditBalance').textContent=r.credits;$('slotBalance').textContent=r.slots;toast2('Slot acquistato','success');}catch(e){toast2(e.message,'error')}}
async function redeemCoupon(){const input=$('couponInput');const code=(input?.value||'').trim();if(!code)return toast2('Inserisci un codice coupon','error');try{const r=await api('/api/billing/redeem',{method:'POST',body:{code}});me.credits=r.credits;me.slots=r.slots;$('creditBalance').textContent=r.credits;$('slotBalance').textContent=r.slots;if(input)input.value='';toast2(r.type==='slots'?`Riscattati ${r.amount} slot!`:`Riscattati ${r.amount} crediti!`,'success');await loadTransactions();}catch(e){toast2(e.message,'error')}}
async function loadTransactions(){try{const r=await api('/api/billing/transactions');$('transactionsBody').innerHTML=r.transactions?.length?r.transactions.map(t=>`<tr><td>${esc(t.description||'Acquisto crediti')}</td><td>${t.credits||0}</td><td>€${((t.amountCents||0)/100).toFixed(2)}</td><td><span class="badge">${esc(t.status)}</span></td><td>${fmtDate(t.createdAt)}</td></tr>`).join(''):'<tr><td colspan="5"><div class="empty">Nessuna transazione.</div></td></tr>'}catch(e){$('transactionsBody').innerHTML='<tr><td colspan="5"><div class="empty">Billing non configurato.</div></td></tr>'}}
function applyUserTheme(theme){
  const normalized = String(theme || '').toLowerCase() === 'dark' ? 'dark' : 'light';
  const isDark = normalized === 'dark';
  document.body.classList.toggle('theme-dark', isDark);
  document.documentElement.setAttribute('data-theme', normalized);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', isDark ? '#071521' : '#f3f6f6');
  try { localStorage.setItem('qh_theme', normalized); } catch (_) {}
}

function languageCode(value){
  return String(value || '').toLowerCase() === 'english' || value === 'en' ? 'en' : 'it';
}
function languageName(code){
  return code === 'en' ? 'English' : 'Italiano';
}

let savingLanguagePreference = false;
let savingThemePreference = false;
async function persistLanguagePreference(code){
  if (!me || savingLanguagePreference) return;
  savingLanguagePreference = true;
  try {
    const r = await api('/api/panel/settings', { method:'PATCH', body:{ language:languageName(code) } });
    if (r?.settings) {
      const savedCode = languageCode(r.settings.language);
      const select = $('language');
      if (select) select.value = languageName(savedCode);
    }
  } catch (e) {
    console.warn('[preferences] language save failed:', e.message);
    toast2('Impossibile salvare la lingua: ' + e.message, 'error');
  } finally {
    savingLanguagePreference = false;
  }
}

async function persistThemePreference(theme){
  if (!me || savingThemePreference) return;
  savingThemePreference = true;
  try {
    const r = await api('/api/panel/settings', { method:'PATCH', body:{ theme } });
    if (r?.settings) applyUserTheme(r.settings.theme);
  } catch (e) {
    console.warn('[preferences] theme save failed:', e.message);
    toast2('Impossibile salvare il tema: ' + e.message, 'error');
  } finally {
    savingThemePreference = false;
  }
}

async function loadUserPreferences(){
  try {
    const r = await api('/api/panel/settings');
    applyUserTheme(r.settings.theme);
    if (typeof setLang === 'function') {
      const lang = languageCode(r.settings.language);
      if (getLang() !== lang) setLang(lang);
    }
    return r.settings;
  } catch (e) {
    try { applyUserTheme(localStorage.getItem('qh_theme') === 'dark' ? 'dark' : 'light'); } catch (_) { applyUserTheme('light'); }
    throw e;
  }
}

async function loadSettings(){
  try {
    const r=await api('/api/panel/settings');
    const settings=r.settings || {};
    $('settingsName').textContent=settings.username || '';
    $('settingsEmail').textContent=settings.email || '';
    $('setUsername').value=settings.username || '';
    $('setEmail').value=settings.email || '';
    $('setDiscord').value=settings.discordConnected ? 'Collegato' : 'Non collegato';
    $('twoFactor').checked=Boolean(settings.twoFactor);
    $('theme').value=settings.theme === 'dark' ? 'dark' : 'light';
    $('language').value=languageName(languageCode(settings.language));
    applyUserTheme(settings.theme);
    if (typeof setLang === 'function') setLang(languageCode(settings.language));
  }catch(e){toast2(e.message,'error')}
}

async function saveProfile(event){
  event?.preventDefault();
  const username=$('setUsername').value.trim();
  const email=$('setEmail').value.trim().toLowerCase();
  const currentPassword=$('profileCurrentPassword').value;
  const currentName=$('settingsName').textContent.trim();
  const currentEmail=$('settingsEmail').textContent.trim().toLowerCase();

  if (!username || username.length < 3) return toast2('Inserisci uno username valido di almeno 3 caratteri','error');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return toast2('Inserisci un indirizzo email valido','error');

  const body={currentPassword};
  if(username!==currentName) body.username=username;
  if(email!==currentEmail) body.email=email;
  if(!body.username && !body.email){toast2('Nessuna modifica al profilo','default');return}
  if(!currentPassword) return toast2('Inserisci la password attuale per modificare username o email','error');

  try{
    const r=await api('/api/panel/settings',{method:'PATCH',body});
    const u=r.settings;
    $('settingsName').textContent=u.username;
    $('settingsEmail').textContent=u.email;
    $('setUsername').value=u.username;
    $('setEmail').value=u.email;
    $('welcome').textContent=u.username;
    $('sideName').textContent=u.username;
    $('topName').textContent=u.username;
    const ini=initials(u.username);
    $('avatar').textContent=ini;$('topAvatar').textContent=ini;$('settingsAvatar').textContent=ini;
    $('profileCurrentPassword').value='';
    toast2(u.email!==currentEmail?'Profilo salvato. È stata inviata una nuova email di verifica.':'Profilo salvato','success');
  }catch(e){toast2(e.message,'error')}
}

async function savePassword(event){
  event?.preventDefault();
  const currentPassword=$('currentPassword').value;
  const newPassword=$('newPassword').value;
  const confirmPassword=$('confirmPassword').value;
  if(newPassword!==confirmPassword){toast2('Le nuove password non coincidono','error');return}
  try{
    await api('/api/panel/settings',{method:'PATCH',body:{currentPassword,newPassword}});
    $('currentPassword').value='';$('newPassword').value='';$('confirmPassword').value='';
    toast2('Password aggiornata','success');
  }catch(e){toast2(e.message,'error')}
}

function previewTheme(value){
  const theme=value === 'dark' ? 'dark' : 'light';
  applyUserTheme(theme);
  persistThemePreference(theme);
}
function previewLanguage(value){
  const code=languageCode(value);
  if(typeof setLang==='function' && getLang() !== code) setLang(code);
  else persistLanguagePreference(code);
}

async function saveSettings(){
  try{
    const theme=$('theme').value === 'dark' ? 'dark' : 'light';
    const language=$('language').value === 'English' ? 'English' : 'Italiano';
    applyUserTheme(theme);
    if(typeof setLang==='function') setLang(language === 'English' ? 'en' : 'it');
    const r=await api('/api/panel/settings',{method:'PATCH',body:{theme,language,twoFactor:$('twoFactor').checked}});
    if(r?.settings){
      applyUserTheme(r.settings.theme);
      const savedCode=languageCode(r.settings.language);
      if(typeof setLang==='function' && getLang()!==savedCode) setLang(savedCode);
      $('theme').value=r.settings.theme === 'dark' ? 'dark' : 'light';
      $('language').value=languageName(savedCode);
    }
    toast2('Impostazioni salvate','success');
  }catch(e){toast2(e.message,'error')}
}

async function loadTickets(){
  try{
    const staff=isStaff();
    const r=await api(staff?'/api/staff/tickets':'/api/panel/tickets');
    const list=Array.isArray(r.tickets)?r.tickets:[];
    const view=$('view-support');
    const head=view?.querySelector('.page-head');
    const title=head?.querySelector('h1');
    const desc=head?.querySelector('p');
    const action=head?.querySelector('button');
    const tableHead=view?.querySelector('thead');
    if(staff){
      if(title) title.textContent='Supporto Staff';
      if(desc) desc.textContent='Gestisci i ticket degli utenti, rispondi e aggiorna lo stato.';
      if(action) action.classList.add('hidden');
      if(tableHead) tableHead.innerHTML='<tr><th>Ticket</th><th>Utente</th><th>Email</th><th>Categoria</th><th>Stato</th><th>Ultimo aggiornamento</th><th></th></tr>';
      $('ticketsBody').innerHTML=list.length?list.map(t=>`<tr onclick="openTicket('${t.id}')" class="click-row"><td>#${t.number||'—'}</td><td>${esc(t.ownerUsername||'—')}</td><td>${esc(t.ownerEmail||'—')}</td><td>${esc(t.category||'—')}</td><td><span class="badge ${t.status==='closed'?'bad':''}">${t.status==='open'?'Aperto':t.status==='pending'?'In attesa':'Chiuso'}</span></td><td>${fmtDate(t.updatedAt)}</td><td>→</td></tr>`).join(''):'<tr><td colspan="7"><div class="empty">Nessun ticket.</div></td></tr>';
    }else{
      const supportLang = typeof getLang === 'function' ? getLang() : 'it';
      const supportText = (key, it, en) => {
        if (typeof t !== 'function') return supportLang === 'en' ? en : it;
        const value = t(key);
        return (!value || value === key || value.toLowerCase?.() === key.toLowerCase())
          ? (supportLang === 'en' ? en : it)
          : value;
      };
      if(title) title.textContent=supportText('support.centerTitle','Centro assistenza','Support Center');
      if(desc) desc.textContent=supportText('support.userDesc','Apri un ticket e parla con il nostro team.','Open a ticket and talk to our team.');
      if(action){action.classList.remove('hidden');action.innerHTML='<svg class="ui-icon"><use href="#i-plus"></use></svg>'+supportText('support.openTicket','Apri un ticket','Open a ticket');}
      if(tableHead) tableHead.innerHTML='<tr><th>Ticket</th><th>Categoria</th><th>Stato</th><th>Ultimo aggiornamento</th><th></th></tr>';
      $('ticketsBody').innerHTML=list.length?list.map(t=>`<tr onclick="openTicket('${t.id}')" class="click-row"><td>#${t.number}</td><td>${esc(t.category)}</td><td><span class="badge ${t.status==='closed'?'bad':''}">${t.status==='open'?'Aperto':t.status==='pending'?'In attesa':'Chiuso'}</span></td><td>${fmtDate(t.updatedAt)}</td><td>→</td></tr>`).join(''):'<tr><td colspan="5"><div class="empty">Nessun ticket.</div></td></tr>';
    }
  }catch(e){toast2(e.message,'error')}
}
async function createTicket(){const subject=await qhPrompt({title:'Apri nuovo ticket',description:'Descrivi brevemente il problema o la richiesta.',label:'Oggetto',placeholder:'Oggetto del ticket',submit:'Continua',icon:'?'});if(!subject)return;const message=await qhPrompt({title:'Descrivi la richiesta',description:'Scrivi tutti i dettagli utili al team di supporto.',label:'Messaggio',value:'Ciao, ho bisogno di assistenza.',placeholder:'Descrivi il problema...',submit:'Apri ticket',icon:'✦'});if(!message)return;try{await api('/api/panel/tickets',{method:'POST',body:{subject,message,category:'Supporto Tecnico'}});toast2('Ticket aperto','success');loadTickets()}catch(e){toast2(e.message,'error')}}
async function openTicket(id){
  try{
    const r=await api(isStaff()?`/api/staff/tickets/${id}`:`/api/panel/tickets/${id}`).catch(async e=>{
      if(isStaff()){
        const all=await api('/api/staff/tickets');
        const ticket=(all.tickets||[]).find(x=>x.id===id);
        if(ticket)return {ticket};
      }
      throw e;
    });
    const tkt=r.ticket;
    $('ticketDetail').classList.remove('hidden');
    const messages=(tkt.messages||[]).map(m=>`<div class="ticket-msg"><small>${esc(m.author)} · ${fmtDate(m.createdAt)}</small><p>${esc(m.content)}</p></div>`).join('');
    if(isStaff()){
      $('ticketDetail').innerHTML=`<div class="panel-head"><div><h2>Ticket #${tkt.number||'—'} — ${esc(tkt.subject||'')}</h2><span>${esc(tkt.ownerUsername||'—')} · ${esc(tkt.ownerEmail||'—')} · ${esc(tkt.category||'')}</span></div><button class="btn btn-sm btn-outline" onclick="$('ticketDetail').classList.add('hidden')">Chiudi</button></div><div class="ticket-chat">${messages||'<div class="empty">Nessun messaggio.</div>'}</div><div class="field-row" style="margin-top:12px"><label>Stato<select id="ticketStatus"><option value="open" ${tkt.status==='open'?'selected':''}>Aperto</option><option value="pending" ${tkt.status==='pending'?'selected':''}>In attesa</option><option value="closed" ${tkt.status==='closed'?'selected':''}>Chiuso</option></select></label><label>Risposta<textarea id="ticketReply" rows="3" placeholder="Scrivi una risposta all'utente..."></textarea></label></div><div class="modal-actions"><button class="btn btn-gradient" onclick="replyTicket('${tkt.id}')">Salva / Rispondi</button></div>`;
    }else{
      $('ticketDetail').innerHTML=`<div class="panel-head"><div><h2>Ticket #${tkt.number}</h2><span>${esc(tkt.subject)}</span></div><button class="btn btn-sm btn-outline" onclick="$('ticketDetail').classList.add('hidden')">Chiudi</button></div><div class="ticket-chat">${messages}</div><div class="reply"><input id="ticketReply" placeholder="Scrivi un messaggio..."><button class="btn btn-gradient" onclick="replyTicket('${tkt.id}')">Invia</button></div>`;
    }
    $('ticketDetail').scrollIntoView({behavior:'smooth'});
  }catch(e){toast2(e.message,'error')}
}
async function replyTicket(id){const v=$('ticketReply').value.trim();if(!v)return;const body=isStaff()?{status:$('ticketStatus').value,message:v}:{message:v};await api(isStaff()?`/api/staff/tickets/${id}`:`/api/panel/tickets/${id}`,{method:isStaff()?'PATCH':'POST',body});await openTicket(id);loadTickets()}
function closeTicket(id){$('ticketDetail')?.classList.add('hidden');}
(async()=>{
  try{
    me=await requireAuth(['user','staff','tester']);
    if(!me)return;
    $('welcome').textContent=me.username;
    $('sideName').textContent=me.username;
    $('topName').textContent=me.username;
    $('sideRole').textContent=me.role==='staff'?'Staff':me.role==='tester'?'Tester':'Utente';
    const ini=initials(me.username);
    $('avatar').textContent=ini;
    $('topAvatar').textContent=ini;
    $('settingsAvatar').textContent=ini;
    updateToday();

    const saved=(location.hash||'').slice(1).toLowerCase() || (()=>{try{return localStorage.getItem('qh_user_view')||''}catch(_){return ''}})();
    const valid=['dashboard','servers','files','databases','backups','network','subusers','billing','settings','support'];
    const initialView=valid.includes(saved)?saved:'dashboard';
    try{localStorage.setItem('qh_user_view',initialView)}catch(_){}

    if(initialView==='dashboard'){
      
      void jump('dashboard');
      void loadServers({silent:true}).catch(()=>{});
    }else{
      if(initialView==='files')void loadServers({silent:true}).catch(()=>{});
      void jump(initialView);
    }

    loadUserPreferences().catch(e=>console.warn('[preferences] load failed:',e.message));
    if(typeof translateDashboardLiterals==='function')translateDashboardLiterals(document);
  }catch(e){
    toast2(e.message||'Impossibile caricare la sezione','error');
  }
})();
window.addEventListener('load',()=>{
  const active=(location.hash||'#dashboard').slice(1).toLowerCase();
  if(active==='dashboard'&&me)loadOverview({silent:true});
});
document.addEventListener('visibilitychange',()=>{
  if(!document.hidden&&(location.hash||'#dashboard').slice(1).toLowerCase()==='dashboard'&&me)loadOverview({silent:true});
});
document.addEventListener('qh:langchange',(event)=>{
  const code=event?.detail?.lang || (typeof getLang==='function'?getLang():'it');
  document.documentElement.setAttribute('lang', code);
  const languageSelect=$('language');
  if(languageSelect) languageSelect.value=languageName(code);
  updateToday();
  if(typeof translateDashboardLiterals==='function') translateDashboardLiterals(document);
  if(me && !savingLanguagePreference) persistLanguagePreference(code);
});
