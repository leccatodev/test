const QH_DEVICE_COOKIE = 'qh_device';

function ensureDeviceCookie() {
  const existing = document.cookie.split('; ').find(item => item.startsWith(`${QH_DEVICE_COOKIE}=`));
  const value = existing ? decodeURIComponent(existing.slice(QH_DEVICE_COOKIE.length + 1)) : '';
  if (/^[a-f0-9-]{24,80}$/i.test(value)) return value;

  const deviceId = globalThis.crypto?.randomUUID
    ? globalThis.crypto.randomUUID()
    : `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}`;
  const secure = location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${QH_DEVICE_COOKIE}=${encodeURIComponent(deviceId)}; Path=/; Max-Age=31536000; SameSite=Lax${secure}`;
  return deviceId;
}



ensureDeviceCookie();

async function api(path, opts = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(opts.timeoutMs) || 30000);
  let res;
  try {
    res = await fetch(path, {
      method: opts.method || 'GET',
      headers: opts.body instanceof FormData
        ? {}
        : (opts.body ? { 'Content-Type': 'application/json' } : {}),
      body: opts.body instanceof FormData
        ? opts.body
        : (opts.body ? JSON.stringify(opts.body) : undefined),
      credentials: 'same-origin',
      cache: opts.cache || 'no-store',
      signal: controller.signal,
    });
  } catch (err) {
    if (err.name === 'AbortError') throw new Error('Richiesta scaduta. Riprova tra poco.');
    throw err;
  } finally {
    clearTimeout(timeout);
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Errore sconosciuto');
  return data;
}

function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

function formatBytes(bytes, decimals = 2) {
  const value = Number(bytes);
  if (!Number.isFinite(value) || value <= 0) return '0 B';

  const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const k = 1024;
  const dm = Math.max(0, Number(decimals) || 0);
  const i = Math.min(
    units.length - 1,
    Math.floor(Math.log(value) / Math.log(k))
  );

  return `${parseFloat((value / Math.pow(k, i)).toFixed(dm))} ${units[i]}`;
}

function timeAgo(ts) {
  const s = Math.floor((Date.now() - Number(ts || Date.now())) / 1000);
  if (s < 60) return 'ora';
  if (s < 3600) return Math.floor(s / 60) + ' min fa';
  if (s < 86400) return Math.floor(s / 3600) + ' h fa';
  return Math.floor(s / 86400) + ' g fa';
}

function initials(name) {
  const value = String(name || '?').trim();
  return value.slice(0, 2).toUpperCase();
}

function toast(message, type = 'default') {
  let wrap = document.querySelector('.toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'toast-wrap';
    document.body.appendChild(wrap);
  }

  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  wrap.appendChild(el);

  requestAnimationFrame(() => {
    el.style.opacity = '1';
    el.style.transform = 'translateY(0) scale(1)';
  });

  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(8px) scale(.98)';
    setTimeout(() => el.remove(), 220);
  }, 3580);
}

async function requireAuth(role) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const { user } = await api('/api/me');
      const allowed = !role || (Array.isArray(role) ? role.includes(user.role) : user.role === role);
      if (!allowed) {
        window.location.href = user.role === 'admin' ? '/admin.html' : '/dashboard.html';
        return null;
      }
      return user;
    } catch (err) {
      if (attempt < 2) {
        await new Promise(resolve => setTimeout(resolve, 350));
        continue;
      }
      console.error('[auth] /api/me temporarily unavailable:', err);
      toast('Connessione temporaneamente non disponibile. Riprova tra poco.', 'error');
      return null;
    }
  }
  return null;
}

async function logout() {
  try {
    await api('/api/logout', { method:'POST' });
  } finally {
    window.location.href = '/index.html';
  }
}


function ensureGlobalModal() {
  let backdrop = document.getElementById('qhGlobalModalBackdrop');

  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.id = 'qhGlobalModalBackdrop';
    backdrop.className = 'modal-backdrop hidden';
    backdrop.innerHTML = '<div class="modal" id="qhGlobalModal"></div>';
    document.body.appendChild(backdrop);

    backdrop.addEventListener('click', e => {
      if (e.target === backdrop) closeGlobalModal();
    });
  }

  return {
    backdrop,
    modal: document.getElementById('qhGlobalModal')
  };
}

function closeGlobalModal() {
  const el = document.getElementById('qhGlobalModalBackdrop');
  if (!el) return;
  el.classList.add('hidden');
  document.body.classList.remove('modal-open');
  const modal = document.getElementById('qhGlobalModal');
  if (modal) modal.innerHTML = '';
}

function globalModal(html) {
  const { backdrop, modal } = ensureGlobalModal();
  modal.innerHTML = html;
  backdrop.classList.remove('hidden');
  document.body.classList.add('modal-open');

  setTimeout(() => {
    modal.querySelector('input,select,textarea,button')?.focus();
  }, 50);

  return modal;
}

function qhPrompt({
  title = 'Inserisci valore',
  description = '',
  label = 'Valore',
  value = '',
  placeholder = '',
  submit = 'Conferma',
  icon = '✦',
  type = 'text'
} = {}) {
  return new Promise(resolve => {
    globalModal(`
      <div class="modal-head">
        <div>
          <div class="modal-icon">${escapeHtml(icon)}</div>
          <div class="eyebrow">QubiqoHost</div>
          <h2>${escapeHtml(title)}</h2>
          ${description ? `<p class="modal-desc">${escapeHtml(description)}</p>` : ''}
        </div>
        <button class="icon-btn" type="button" data-qh-close>×</button>
      </div>

      <form class="modal-form" id="qhPromptForm">
        <label>
          ${escapeHtml(label)}
          <input id="qhPromptInput" type="${escapeHtml(type)}"
            value="${escapeHtml(value)}"
            placeholder="${escapeHtml(placeholder)}"
            autocomplete="off" required>
        </label>

        <div class="modal-actions">
          <button class="btn btn-outline" type="button" data-qh-cancel>Annulla</button>
          <button class="btn btn-gradient" type="submit">${escapeHtml(submit)}</button>
        </div>
      </form>
    `);

    const finish = value => {
      closeGlobalModal();
      resolve(value);
    };

    document.querySelector('#qhGlobalModal [data-qh-close]').onclick = () => finish(null);
    document.querySelector('#qhGlobalModal [data-qh-cancel]').onclick = () => finish(null);

    document.getElementById('qhPromptForm').onsubmit = e => {
      e.preventDefault();
      const input = document.getElementById('qhPromptInput');
      finish(input.value.trim());
    };
  });
}

function qhSelect({
  title = 'Seleziona',
  description = '',
  label = 'Selezione',
  options = [],
  value = '',
  submit = 'Conferma',
  icon = '✦'
} = {}) {
  return new Promise(resolve => {
    const normalized = Array.isArray(options) ? options : [];
    globalModal(`
      <div class="modal-head">
        <div>
          <div class="modal-icon">${escapeHtml(icon)}</div>
          <div class="eyebrow">QubiqoHost</div>
          <h2>${escapeHtml(title)}</h2>
          ${description ? `<p class="modal-desc">${escapeHtml(description)}</p>` : ''}
        </div>
        <button class="icon-btn" type="button" data-qh-close>×</button>
      </div>

      <form class="modal-form" id="qhSelectForm">
        <label>
          ${escapeHtml(label)}
          <select id="qhSelectInput">
            ${normalized.map(o => `
              <option value="${escapeHtml(o.value)}" ${String(o.value) === String(value) ? 'selected' : ''}>
                ${escapeHtml(o.label)}
              </option>
            `).join('')}
          </select>
        </label>

        <div class="modal-actions">
          <button class="btn btn-outline" type="button" data-qh-cancel>Annulla</button>
          <button class="btn btn-gradient" type="submit">${escapeHtml(submit)}</button>
        </div>
      </form>
    `);

    const finish = selected => {
      closeGlobalModal();
      resolve(selected);
    };

    document.querySelector('#qhGlobalModal [data-qh-close]').onclick = () => finish(null);
    document.querySelector('#qhGlobalModal [data-qh-cancel]').onclick = () => finish(null);

    document.getElementById('qhSelectForm').onsubmit = e => {
      e.preventDefault();
      finish(document.getElementById('qhSelectInput').value);
    };
  });
}

function qhConfirm({
  title = 'Confermare azione?',
  description = '',
  submit = 'Conferma',
  icon = '⚠',
  danger = true
} = {}) {
  return new Promise(resolve => {
    globalModal(`
      <div class="modal-head">
        <div>
          <div class="qh-confirm-icon">${escapeHtml(icon)}</div>
          <div class="eyebrow">QubiqoHost</div>
          <h2>${escapeHtml(title)}</h2>
          ${description ? `<p class="modal-desc">${escapeHtml(description)}</p>` : ''}
        </div>
        <button class="icon-btn" type="button" data-qh-close>×</button>
      </div>

      <div class="modal-actions">
        <button class="btn btn-outline" type="button" data-qh-cancel>Annulla</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-gradient'}" type="button" data-qh-ok>
          ${escapeHtml(submit)}
        </button>
      </div>
    `);

    const finish = value => {
      closeGlobalModal();
      resolve(value);
    };

    document.querySelector('#qhGlobalModal [data-qh-close]').onclick = () => finish(false);
    document.querySelector('#qhGlobalModal [data-qh-cancel]').onclick = () => finish(false);
    document.querySelector('#qhGlobalModal [data-qh-ok]').onclick = () => finish(true);
  });
}

function initMobileNav() {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar) return;

  let backdrop = document.getElementById('drawerBackdrop') || document.querySelector('.drawer-backdrop');

  if (!backdrop) {
    backdrop = document.createElement('button');
    backdrop.type = 'button';
    backdrop.id = 'drawerBackdrop';
    backdrop.className = 'drawer-backdrop';
    backdrop.setAttribute('aria-label', 'Chiudi menu');
    document.body.appendChild(backdrop);
  }

  const menuButtons = [
    document.getElementById('menuBtn'),
    document.getElementById('qhHamburger')
  ].filter(Boolean);

  if (!menuButtons.length) {
    const topbar = document.querySelector('.mobile-topbar');
    if (topbar) {
      const button = topbar.querySelector('.hamburger');
      if (button) menuButtons.push(button);
    }
  }

  const close = () => {
    sidebar.classList.remove('open');
    backdrop.classList.remove('open');
    backdrop.style.display = 'none';
    document.body.classList.remove('drawer-open');
    menuButtons.forEach(button => button.setAttribute('aria-expanded', 'false'));
  };

  window.qhCloseMobileNav = close;

  const open = () => {
    sidebar.classList.add('open');
    backdrop.style.display = 'block';
    requestAnimationFrame(() => backdrop.classList.add('open'));
    document.body.classList.add('drawer-open');
    menuButtons.forEach(button => button.setAttribute('aria-expanded', 'true'));
  };

  menuButtons.forEach(button => {
    button.onclick = event => {
      event.preventDefault();
      event.stopPropagation();
      sidebar.classList.contains('open') ? close() : open();
    };
  });

  backdrop.onclick = close;

  document.addEventListener('click', event => {
    if (!sidebar.classList.contains('open')) return;
    if (sidebar.contains(event.target)) return;
    if (menuButtons.some(button => button.contains(event.target))) return;
    close();
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') close();
  });

  sidebar.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', close);
  });

  const mobileLogout = document.getElementById('adminMobileLogout');
  if (mobileLogout) mobileLogout.onclick = logout;
}

document.addEventListener('DOMContentLoaded', initMobileNav);


window.formatBytes = formatBytes;
window.FormatBytes = formatBytes;

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js', { scope: '/' })
      .catch(err => console.warn('[pwa] Service Worker registration failed:', err));
  });
}
